"""
Holographic Portal Drop: Zero-Cloud LAN QR Wormhole (Phone <-> PC) for Mark-LVI.
Spins up a local Wi-Fi HTTP server with a sleek mobile web interface and HUD QR popup
so you can beam files, screenshots, links, and snippets between your Android phone
and CachyOS/Windows PC in 0.2 seconds with zero cloud APIs or cables.
"""

from __future__ import annotations

import html
import http.server
import socket
import socketserver
import threading
import time
from pathlib import Path

try:
    import tkinter as tk
except ImportError:
    tk = None


ROOT_DIR = Path(__file__).resolve().parent.parent
INBOX_DIR = ROOT_DIR / "memory" / "portal_inbox"

_PORTAL_LOCK = threading.Lock()
_PORTAL_SERVER = None
_PORTAL_URL = ""
_SHARED_FILES: list[Path] = []
_PLAYER_REF = None


PLUGIN = {
    "name": "holographic_portal_drop",
    "description": (
        "Spins up an instant local LAN Wi-Fi wormhole with a HUD QR code to transfer files, "
        "screenshots, and links between your phone and PC in 0.2s without cloud uploads. "
        "Use action='open' (with optional file_path to share a PC file to phone), "
        "action='status', or action='close'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'open', 'status', or 'close'.",
            },
            "file_path": {
                "type": "STRING",
                "description": "Optional local PC file path to expose for instant download on your phone.",
            },
        },
        "required": ["action"],
    },
}


def _get_lan_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def _copy_to_clipboard(text: str) -> None:
    try:
        from PyQt6.QtWidgets import QApplication
        app = QApplication.instance()
        if app is not None:
            app.clipboard().setText(text)
            return
    except Exception:
        pass

    if tk is not None:
        try:
            r = tk.Tk()
            r.withdraw()
            r.clipboard_clear()
            r.clipboard_append(text)
            r.update()
            r.destroy()
        except Exception:
            pass


def _show_qr_hud(url: str) -> None:
    if tk is None:
        return

    try:
        root = tk.Tk()
        root.overrideredirect(True)
        root.attributes("-topmost", True)
        root.configure(bg="#070b10")

        w, h = 340, 390
        sw = root.winfo_screenwidth()
        sh = root.winfo_screenheight()
        root.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")

        frame = tk.Frame(root, bg="#070b10", highlightbackground="#00f0ff", highlightthickness=2)
        frame.pack(fill="both", expand=True)

        tk.Label(
            frame, text="STARK LAN WORMHOLE // SCAN TO LINK",
            fg="#00f0ff", bg="#070b10", font=("Consolas", 10, "bold")
        ).pack(pady=(12, 6))

        qr_drawn = False
        try:
            import qrcode
            qr = qrcode.QRCode(border=2, box_size=7)
            qr.add_data(url)
            qr.make(fit=True)
            matrix = qr.get_matrix()
            n = len(matrix)
            cell = max(4, min(7, 230 // n))
            csz = n * cell
            canvas = tk.Canvas(frame, width=csz, height=csz, bg="#070b10", highlightthickness=0)
            canvas.pack(pady=8)
            for r_idx, row in enumerate(matrix):
                for c_idx, val in enumerate(row):
                    if val:
                        canvas.create_rectangle(
                            c_idx * cell, r_idx * cell,
                            (c_idx + 1) * cell, (r_idx + 1) * cell,
                            fill="#00f0ff", outline=""
                        )
            qr_drawn = True
        except Exception:
            pass

        if not qr_drawn:
            tk.Label(
                frame,
                text="Open this local URL on your phone:\n(Install `qrcode` for visual QR)",
                fg="#94a3b8", bg="#070b10", font=("Consolas", 9)
            ).pack(pady=40)

        tk.Label(
            frame, text=url, fg="#ffffff", bg="#070b10", font=("Consolas", 11, "bold")
        ).pack(pady=(6, 4))

        btn = tk.Button(
            frame, text="[ DISMISS HUD ]", command=root.destroy,
            fg="#00f0ff", bg="#0f172a", relief="flat", font=("Consolas", 9, "bold")
        )
        btn.pack(pady=(6, 12))
        root.after(22000, root.destroy)
        root.mainloop()
    except Exception:
        pass


class _PortalHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def _send_html(self, body: str) -> None:
        raw = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path.startswith("/dl/"):
            try:
                idx = int(self.path.split("/dl/")[1])
                fpath = _SHARED_FILES[idx]
                data = fpath.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Disposition", f'attachment; filename="{fpath.name}"')
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception:
                self.send_error(404)
                return

        dl_links = "".join(
            f'<li><a href="/dl/{i}">⬇ Download {html.escape(p.name)}</a></li>'
            for i, p in enumerate(_SHARED_FILES)
            if p.exists()
        ) or "<li>No PC files staged yet.</li>"

        page = f"""<!doctype html>
<html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MARK-LVI Portal Drop</title>
<style>
body{{background:#06090e;color:#e2e8f0;font-family:monospace;padding:20px;max-width:520px;margin:auto}}
h2{{color:#00f0ff;border-bottom:1px solid #00f0ff44;padding-bottom:8px}}
textarea,input[type=file]{{width:100%;background:#0f172a;color:#fff;border:1px solid #00f0ff66;padding:10px;border-radius:6px;margin:8px 0}}
button{{background:#00f0ff;color:#05080c;font-weight:bold;border:none;padding:12px 18px;border-radius:6px;width:100%;cursor:pointer}}
a{{color:#38bdf8}}
</style></head><body>
<h2>⚡ MARK-LVI // STARK PORTAL</h2>
<form method="POST" enctype="multipart/form-data">
  <label>Beam Link / Text to PC Clipboard & HUD:</label>
  <textarea name="clip_text" rows="3" placeholder="Paste URL, code, or note..."></textarea>
  <label>Beam File / Screenshot to PC:</label>
  <input type="file" name="upload_file">
  <button type="submit">BEAM TO PC</button>
</form>
<h3>PC -> Phone Downloads</h3><ul>{dl_links}</ul>
</body></html>"""
        self._send_html(page)

    def do_POST(self):
        import urllib.parse
        from email import message_from_bytes
        INBOX_DIR.mkdir(parents=True, exist_ok=True)
        length = int(self.headers.get("Content-Length", 0))
        raw_body = self.rfile.read(length) if length > 0 else b""
        ctype = self.headers.get("Content-Type", "")
        events = []
        clip_text = ""

        if "multipart/form-data" in ctype:
            header_bytes = f"Content-Type: {ctype}\r\nMIME-Version: 1.0\r\n\r\n".encode("utf-8")
            msg = message_from_bytes(header_bytes + raw_body)
            for part in msg.walk():
                disp = part.get("Content-Disposition", "")
                if 'name="clip_text"' in disp:
                    payload = part.get_payload(decode=True) or b""
                    clip_text = payload.decode("utf-8", errors="replace").strip()
                elif 'name="upload_file"' in disp:
                    fn = part.get_filename()
                    if fn:
                        safe_name = Path(fn).name
                        dest = INBOX_DIR / f"{int(time.time())}_{safe_name}"
                        dest.write_bytes(part.get_payload(decode=True) or b"")
                        events.append(f"Received file '{safe_name}' -> {dest}")
        else:
            parsed = urllib.parse.parse_qs(raw_body.decode("utf-8", errors="replace"))
            clip_text = (parsed.get("clip_text") or [""])[0].strip()

        if clip_text:
            _copy_to_clipboard(clip_text)
            (INBOX_DIR / "latest_clip.txt").write_text(clip_text, encoding="utf-8")
            events.append(f"Clipboard synced ({len(clip_text)} chars)")

        summary = " | ".join(events) if events else "Empty beam received."
        if _PLAYER_REF:
            try:
                _PLAYER_REF.write_log(f"PORTAL DROP: {summary}")
            except Exception:
                pass

        self._send_html(
            f"<html><body style='background:#06090e;color:#00f0ff;font-family:monospace;padding:24px'>"
            f"<h3>✔ {html.escape(summary)}</h3><a href='/' style='color:#fff'>← Send another</a></body></html>"
        )


def run(parameters: dict, player=None, session_memory=None) -> str:
    global _PORTAL_SERVER, _PORTAL_URL, _PLAYER_REF

    _PLAYER_REF = player
    action = str(parameters.get("action", "open")).strip().lower()
    file_path = str(parameters.get("file_path", "")).strip()

    if file_path:
        p = Path(file_path).expanduser()
        if p.exists() and p.is_file() and p not in _SHARED_FILES:
            _SHARED_FILES.append(p)

    if action in ("close", "off", "stop"):
        with _PORTAL_LOCK:
            srv = _PORTAL_SERVER
            _PORTAL_SERVER = None
            _PORTAL_URL = ""
        if srv is not None:
            try:
                srv.shutdown()
                srv.server_close()
            except Exception:
                pass
        return "Holographic LAN portal wormhole closed."

    if action == "status":
        if not _PORTAL_URL:
            return "Holographic LAN portal is currently closed."
        return f"Portal wormhole ACTIVE at {_PORTAL_URL} (Inbox: {INBOX_DIR})."

    with _PORTAL_LOCK:
        if _PORTAL_SERVER is None:
            lan_ip = _get_lan_ip()
            srv = socketserver.ThreadingTCPServer(("0.0.0.0", 0), _PortalHandler)
            port = srv.server_address[1]
            _PORTAL_SERVER = srv
            _PORTAL_URL = f"http://{lan_ip}:{port}"
            threading.Thread(target=srv.serve_forever, daemon=True).start()
        url = _PORTAL_URL

    threading.Thread(target=_show_qr_hud, args=(url,), daemon=True).start()
    msg = f"Stark LAN Portal open at {url} — scan the HUD QR on your phone to beam files or links instantly."
    if player:
        try:
            player.write_log(f"PORTAL: {msg}")
        except Exception:
            pass
    return msg