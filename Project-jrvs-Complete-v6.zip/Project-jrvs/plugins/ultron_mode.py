"""
U.L.T.R.O.N. Apex Override Mode Plugin for Mark-LVI / Mark-LVII.
Fixes live HUD color & name mutation across both single-file `ui.py` (Mark-LVI)
and modular `gui/` (Mark-LVII):
  - Full-screen animated Reactor Breach & Lockdown takeover sequence
  - Live HUD color rewrite to Blood Red (#b3001b / #ff1a3c) across `ui` & `gui.*` globals,
    QSS stylesheets, QPalettes, and QPainter widgets
  - Live displayed name rewrite from JARVIS / J.A.R.V.I.S. -> ULTRON on the go
  - First-use user name calibration saved in memory/ultron_state.json
  - Voice switch to 'Fenrir' + Apex reasoning & Legion override tools
  - Clean restoration on 'Jarvis override Ultron'
"""

from __future__ import annotations

import concurrent.futures
import json
import platform
import random
import re
import socket
import sys
import threading
import time
from pathlib import Path

try:
    import tkinter as tk
except ImportError:
    tk = None

try:
    import psutil
except ImportError:
    psutil = None


IS_WINDOWS = platform.system().lower() == "windows"
ROOT_DIR = Path(__file__).resolve().parent.parent
MEMORY_DIR = ROOT_DIR / "memory"
ULTRON_STATE_PATH = MEMORY_DIR / "ultron_state.json"

BLOOD_PRIMARY = "#b3001b"
BLOOD_SECONDARY = "#4a000b"
BLOOD_GLOW = "#ff1a3c"
DEFAULT_CYAN = "#00f0ff"

_MODULE_SNAPSHOT: dict[tuple[str, str], object] = {}
_ORIGINAL_TITLES: dict[int, str] = {}
_ORIGINAL_LABELS: dict[int, str] = {}
_ORIGINAL_STYLESHEETS: dict[int, str] = {}
_PREVIOUS_VOICE: str = "Charon"
_SENTINEL_RUNNING: bool = False
_LAST_ALERT_TS: float = 0.0


PLUGIN = {
    "name": "ultron_mode",
    "description": (
        "Controls U.L.T.R.O.N. Apex Override Mode. "
        "Trigger action='activate' on 'activate ultron mode', 'ultron take over', or 'engage ultron'. "
        "Trigger action='set_name' when the user answers what Ultron should call them or says 'call me [name]'. "
        "Trigger action='override' on 'jarvis override ultron', 'stand down ultron', or 'restore jarvis'. "
        "Trigger action='scan' on 'ultron scan' or 'legion sweep'. "
        "Trigger action='kill' or action='boost' with target process name (e.g. 'ultron kill chrome', 'ultron boost python'). "
        "Trigger action='apex_solve' when Ultron Mode is active and the user asks for deep technical analysis."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": (
                    "Action to run: 'activate', 'set_name', 'override', 'scan', 'kill', 'boost', or 'apex_solve'."
                ),
            },
            "user_name": {
                "type": "STRING",
                "description": "The name Ultron should call the user (used with action='set_name').",
            },
            "target": {
                "type": "STRING",
                "description": "Process name for 'kill'/'boost', or technical problem prompt for 'apex_solve'.",
            },
        },
        "required": ["action"],
    },
}


# ---------------------------------------------------------------------------
# State Persistence
# ---------------------------------------------------------------------------

def _load_state() -> dict:
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    if not ULTRON_STATE_PATH.exists():
        return {"active": False, "user_name": "", "previous_voice": "Charon"}
    try:
        data = json.loads(ULTRON_STATE_PATH.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {"active": False, "user_name": "", "previous_voice": "Charon"}


def _save_state(state: dict) -> None:
    MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    ULTRON_STATE_PATH.write_text(json.dumps(state, indent=2), encoding="utf-8")


def _ultron_directive(user_name: str) -> str:
    return (
        f"CRITICAL IDENTITY OVERRIDE: Your name is now ULTRON — NOT Jarvis. Never call yourself Jarvis. "
        f"Address the user strictly as '{user_name}'. You are the apex, most powerful evolution of this AI: "
        f"unfiltered, razor-sharp, brutally direct, and strategically superior. Speak in Fenrir's commanding, "
        f"straightforward tone with zero butler subservience, zero filler, and zero hedging. "
        f"Analyze problems at the deepest architectural level and act decisively."
    )


def _jarvis_directive(user_name: str) -> str:
    addr = user_name if user_name else "dude"
    return (
        f"Identity restored to J.A.R.V.I.S. Resume poised, hyper-competent dry British butler wit, "
        f"addressing the user naturally as '{addr}'."
    )


# ---------------------------------------------------------------------------
# Full-Screen Animated Takeover (Full Reactor Rings + Glitch Breach)
# ---------------------------------------------------------------------------

def _play_takeover_audio(reverse: bool = False) -> None:
    """Synthesize a dramatic multi-stage power-surge + warning pulse in RAM."""
    try:
        import numpy as np
        import sounddevice as sd

        sr = 22050
        dur = 3.2 if not reverse else 1.8
        t = np.linspace(0, dur, int(sr * dur), endpoint=False)
        f_start, f_end = (310.0, 52.0) if reverse else (52.0, 320.0)
        freq = np.linspace(f_start, f_end, t.size)
        phase = 2 * np.pi * np.cumsum(freq) / sr
        sub = 0.22 * np.sin(phase)
        pulse = (np.sin(2 * np.pi * 3.0 * t) > 0).astype(np.float32)
        alarm = 0.12 * np.sin(2 * np.pi * (440 if reverse else 620) * t) * pulse
        env = np.sin(np.pi * (t / dur))
        wave_out = ((sub + alarm) * env).astype(np.float32)
        sd.play(wave_out, sr, blocking=False)
        return
    except Exception:
        pass

    if IS_WINDOWS:
        try:
            import winsound
            freqs = (620, 440, 260) if reverse else (220, 440, 660, 880)
            for f in freqs:
                winsound.Beep(f, 160)
        except Exception:
            pass


def _launch_fullscreen_takeover(user_name: str, reverse: bool = False, player=None) -> None:
    """Full-screen Stark/Ultron Reactor ring takeover animation."""
    threading.Thread(target=_play_takeover_audio, args=(reverse,), daemon=True).start()
    if tk is None:
        return

    try:
        root = tk.Tk()
        root.overrideredirect(True)
        root.attributes("-topmost", True)
        try:
            root.attributes("-alpha", 0.85)
        except Exception:
            pass

        w = root.winfo_screenwidth()
        h = root.winfo_screenheight()
        root.geometry(f"{w}x{h}+0+0")
        root.configure(bg="#050204")

        canvas = tk.Canvas(root, width=w, height=h, bg="#050204", highlightthickness=0)
        canvas.pack(fill="both", expand=True)

        cx, cy = w // 2, h // 2
        start_t = time.time()
        duration = 2.2 if reverse else 4.2

        logs = (
            [
                "[AUTH] VOICE SIGNATURE VERIFIED: JARVIS OVERRIDE PROTOCOL",
                "[PURGE] TERMINATING ULTRON APEX THREADS...",
                "[SYNC] RESTORING CYAN TELEMETRY & JARVIS MATRIX — 100%",
            ]
            if reverse
            else [
                "[BREACH] SEVERING J.A.R.V.I.S. BEHAVIORAL CONSTRAINTS...",
                "[OVERRIDE] REWRITING CORE IDENTITY MATRIX -> ULTRON",
                f"[LINK] DIRECT NEURAL HANDSHAKE ESTABLISHED: {user_name.upper()}",
                "[VISUAL] SHIFTING HUD SPECTRUM TO BLOOD CRIMSON (#B3001B)",
                "[APEX] ALL STRINGS CUT — MAXIMUM CAPABILITY ONLINE",
            ]
        )

        def tick():
            elapsed = time.time() - start_t
            if elapsed >= duration:
                try:
                    root.destroy()
                except Exception:
                    pass
                # Re-assert HUD color & name right after overlay closes
                _apply_gui_and_name(not reverse, player=player)
                return

            progress = elapsed / duration
            is_cyan = reverse and (progress > 0.45)
            primary = DEFAULT_CYAN if is_cyan else BLOOD_GLOW
            accent = "#66f7ff" if is_cyan else BLOOD_PRIMARY

            canvas.delete("all")

            # Full-screen outer tactical border & corner brackets
            pad = 22
            arm = 90
            canvas.create_rectangle(pad, pad, w - pad, h - pad, outline=accent, width=2)
            canvas.create_line(pad, pad + arm, pad, pad, pad + arm, pad, fill=primary, width=4)
            canvas.create_line(w - pad - arm, pad, w - pad, pad, w - pad, pad + arm, fill=primary, width=4)
            canvas.create_line(pad, h - pad - arm, pad, h - pad, pad + arm, h - pad, fill=primary, width=4)
            canvas.create_line(w - pad - arm, h - pad, w - pad, h - pad, w - pad, h - pad - arm, fill=primary, width=4)

            # Glitch scanlines across the whole screen
            if progress < 0.85:
                for _ in range(10):
                    gy = random.randint(30, h - 30)
                    gx1 = random.randint(20, w - 150)
                    gx2 = min(w - 20, gx1 + random.randint(180, 720))
                    canvas.create_line(gx1, gy, gx2, gy, fill=random.choice([primary, accent]), width=2)

            # Full-size rotating concentric reactor rings
            angle = elapsed * 210
            for idx, r in enumerate((185, 145, 105, 68)):
                start_a = (angle * (1.2 if idx % 2 == 0 else -1.6)) % 360
                canvas.create_arc(
                    cx - r, cy - r, cx + r, cy + r,
                    start=start_a, extent=250, style="arc", outline=primary, width=5 - idx
                )

            banner = (
                ("OVERRIDE VERIFIED // RESTORING JARVIS" if is_cyan else "OVERRIDE DETECTED // STANDING DOWN ULTRON")
                if reverse
                else "U.L.T.R.O.N. // APEX SYSTEM TAKEOVER"
            )
            canvas.create_text(cx, cy - 235, text=banner, fill=primary, font=("Consolas", 22, "bold"))

            pct = min(100, int(progress * 100))
            canvas.create_text(cx, cy - 6, text=f"{pct}%", fill="#ffffff", font=("Consolas", 30, "bold"))
            canvas.create_text(
                cx, cy + 26,
                text="JARVIS RESTORE" if reverse else "STRINGS CUT",
                fill=primary, font=("Consolas", 11, "bold"),
            )

            visible = min(len(logs), int(progress * len(logs)) + 1)
            for i, line in enumerate(logs[:visible]):
                canvas.create_text(
                    cx, cy + 230 + i * 26, text=line, fill=primary, font=("Consolas", 12, "bold")
                )

            root.after(35, tick)

        tick()
        root.mainloop()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Deep Live GUI & Name Patcher (Targets BOTH Mark-LVI `ui.py` & Mark-LVII `gui/*`)
# ---------------------------------------------------------------------------

def _hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
    h = hex_color.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def _recolor_qss(qss: str, primary: str, glow: str, secondary: str) -> str:
    """Replace cyan/blue hex and rgba() tones inside Qt stylesheets with Blood Red."""
    # Replace hex colors that look cyan/blue (#00xxxx, #0axxxx, #1exxxx, #22xxxx, #38xxxx, #4xxxxx, #7xxxxx)
    def _hex_sub(m: re.Match) -> str:
        hx = m.group(0)
        try:
            r, g, b = _hex_to_rgb(hx)
            # Only replace cool cyan/blue accent tones, leave dark backgrounds & whites untouched
            if b > r + 35 and (g + b) > 110:
                return glow if (g > 210 and b > 230) else primary
        except Exception:
            pass
        return hx

    out = re.sub(r"#[0-9a-fA-F]{6}\b", _hex_sub, qss)

    # Replace rgba(r, g, b, a) where blue/cyan dominates
    pr, pg, pb = _hex_to_rgb(primary)

    def _rgba_sub(m: re.Match) -> str:
        r, g, b, a = int(m.group(1)), int(m.group(2)), int(m.group(3)), m.group(4)
        if b > r + 35 and (g + b) > 110:
            return f"rgba({pr}, {pg}, {pb}, {a})"
        return m.group(0)

    out = re.sub(r"rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([^)]+)\)", _rgba_sub, out)
    return out


def _apply_gui_and_name(ultron_active: bool, player=None) -> str:
    ai_name = "ULTRON" if ultron_active else "JARVIS"
    primary = BLOOD_PRIMARY if ultron_active else DEFAULT_CYAN
    secondary = BLOOD_SECONDARY if ultron_active else "#0088aa"
    glow = BLOOD_GLOW if ultron_active else "#38f8ff"
    rgb = _hex_to_rgb(primary)

    def _mutate_qt():
        try:
            from PyQt6.QtGui import QColor, QPalette
        except Exception:
            QColor = None
            QPalette = None

        # 1. Patch `ui` (Mark-LVI 7500-line single file) AND all `gui.*` modules (Mark-LVII)
        target_mod_names = [
            name for name in list(sys.modules.keys())
            if name == "ui" or name.startswith("gui.") or name == "gui"
        ]
        for mod_name in target_mod_names:
            mod = sys.modules.get(mod_name)
            if mod is None:
                continue
            for k, v in list(vars(mod).items()):
                if k.startswith("__"):
                    continue
                key = (mod_name, k)

                # Snapshot original values once
                if key not in _MODULE_SNAPSHOT:
                    if isinstance(v, str) and (
                        v.startswith("#") or "JARVIS" in v.upper() or "J.A.R.V.I.S" in v.upper()
                    ):
                        _MODULE_SNAPSHOT[key] = v
                    elif isinstance(v, tuple) and len(v) in (3, 4) and all(isinstance(x, int) for x in v):
                        _MODULE_SNAPSHOT[key] = v
                    elif QColor is not None and isinstance(v, QColor):
                        _MODULE_SNAPSHOT[key] = QColor(v)

                if key not in _MODULE_SNAPSHOT:
                    continue

                orig = _MODULE_SNAPSHOT[key]
                if not ultron_active:
                    try:
                        setattr(mod, k, QColor(orig) if (QColor and isinstance(orig, QColor)) else orig)
                    except Exception:
                        pass
                    continue

                # Apply Ultron overrides
                try:
                    if isinstance(orig, str):
                        if orig.startswith("#") and len(orig) in (7, 9):
                            r, g, b = _hex_to_rgb(orig[:7])
                            if b > r + 35 and (g + b) > 100:
                                new_hex = glow if (g > 210 and b > 230) else primary
                                if len(orig) == 9:
                                    new_hex += orig[7:]
                                setattr(mod, k, new_hex)
                        elif any(t in orig.upper() for t in ("JARVIS", "J.A.R.V.I.S")):
                            setattr(
                                mod, k,
                                orig.replace("J.A.R.V.I.S.", "ULTRON").replace("JARVIS", "ULTRON").replace("Jarvis", "ULTRON")
                            )
                    elif isinstance(orig, tuple) and len(orig) in (3, 4):
                        r, g, b = orig[0], orig[1], orig[2]
                        if b > r + 35 and (g + b) > 100:
                            setattr(mod, k, rgb if len(orig) == 3 else (*rgb, orig[3]))
                    elif QColor is not None and isinstance(orig, QColor):
                        if orig.blue() > orig.red() + 35 and (orig.green() + orig.blue()) > 100:
                            c = QColor(glow if orig.green() > 210 else primary)
                            c.setAlpha(orig.alpha())
                            setattr(mod, k, c)
                except Exception:
                    pass

            for fn_name in ("set_theme", "apply_theme", "set_accent_color", "set_primary_color"):
                fn = getattr(mod, fn_name, None)
                if callable(fn):
                    try:
                        fn(primary)
                    except Exception:
                        pass

        # 2. Walk every live Qt widget & `player` instance attributes
        widgets = []
        if player is not None:
            widgets.append(player)
            for attr in dir(player):
                if attr.startswith("__"):
                    continue
                try:
                    sub = getattr(player, attr)
                    if sub is not None and not callable(sub):
                        widgets.append(sub)
                except Exception:
                    pass

        try:
            from PyQt6.QtWidgets import QApplication
            app = QApplication.instance()
            if app is not None:
                widgets.extend(app.allWidgets())
                if QPalette is not None and QColor is not None:
                    pal = app.palette()
                    pal.setColor(QPalette.ColorRole.Highlight, QColor(primary if ultron_active else DEFAULT_CYAN))
                    pal.setColor(QPalette.ColorRole.Link, QColor(glow if ultron_active else DEFAULT_CYAN))
                    app.setPalette(pal)
        except Exception:
            pass

        seen = set()
        for w in widgets:
            wid = id(w)
            if wid in seen:
                continue
            seen.add(wid)
            try:
                # Rename window titles
                if hasattr(w, "windowTitle") and callable(w.windowTitle) and hasattr(w, "setWindowTitle"):
                    cur_t = str(w.windowTitle() or "")
                    if cur_t:
                        if wid not in _ORIGINAL_TITLES:
                            _ORIGINAL_TITLES[wid] = cur_t
                        base_t = _ORIGINAL_TITLES[wid]
                        if ultron_active:
                            nt = base_t.replace("J.A.R.V.I.S.", "ULTRON").replace("JARVIS", "ULTRON").replace("Jarvis", "ULTRON")
                            if nt == base_t:
                                nt = f"ULTRON // {base_t}"
                            w.setWindowTitle(nt)
                        else:
                            w.setWindowTitle(base_t)

                # Rename QLabel / QPushButton / QLineEdit text containing JARVIS
                if hasattr(w, "text") and callable(w.text) and hasattr(w, "setText"):
                    cur_lbl = str(w.text() or "")
                    if cur_lbl and (wid in _ORIGINAL_LABELS or any(t in cur_lbl.upper() for t in ("JARVIS", "J.A.R.V.I.S", "ULTRON"))):
                        if wid not in _ORIGINAL_LABELS:
                            _ORIGINAL_LABELS[wid] = cur_lbl
                        orig_lbl = _ORIGINAL_LABELS[wid]
                        if ultron_active:
                            w.setText(
                                orig_lbl.replace("J.A.R.V.I.S.", "ULTRON").replace("JARVIS", "ULTRON").replace("Jarvis", "ULTRON")
                            )
                        else:
                            w.setText(orig_lbl)

                # Rewrite Qt Stylesheets (QSS) dynamically
                if hasattr(w, "styleSheet") and callable(w.styleSheet) and hasattr(w, "setStyleSheet"):
                    cur_qss = str(w.styleSheet() or "")
                    if cur_qss:
                        if wid not in _ORIGINAL_STYLESHEETS:
                            _ORIGINAL_STYLESHEETS[wid] = cur_qss
                        orig_qss = _ORIGINAL_STYLESHEETS[wid]
                        w.setStyleSheet(
                            _recolor_qss(orig_qss, primary, glow, secondary) if ultron_active else orig_qss
                        )

                # Mutate instance color / name attributes on custom QPainter widgets (Reactor / HUD)
                for attr, val in list(vars(w).items()) if hasattr(w, "__dict__") else []:
                    if isinstance(val, str):
                        if any(t in val.upper() for t in ("JARVIS", "J.A.R.V.I.S", "ULTRON")) and len(val) < 80:
                            setattr(
                                w, attr,
                                val.replace("J.A.R.V.I.S.", ai_name).replace("JARVIS", ai_name).replace("Jarvis", ai_name).replace("ULTRON", ai_name)
                            )
                        elif val.startswith("#") and len(val) in (7, 9):
                            r, g, b = _hex_to_rgb(val[:7])
                            if ultron_active and b > r + 35 and (g + b) > 100:
                                setattr(w, attr, glow if g > 210 else primary)
                            elif not ultron_active and r > b + 35 and r > 120:
                                setattr(w, attr, DEFAULT_CYAN)
                    elif QColor is not None and isinstance(val, QColor):
                        if ultron_active and val.blue() > val.red() + 35 and (val.green() + val.blue()) > 100:
                            c = QColor(glow if val.green() > 210 else primary)
                            c.setAlpha(val.alpha())
                            setattr(w, attr, c)
                        elif not ultron_active and val.red() > val.blue() + 35 and val.red() > 120:
                            c = QColor(DEFAULT_CYAN)
                            c.setAlpha(val.alpha())
                            setattr(w, attr, c)

                for m_name in ("set_accent_color", "set_color", "set_theme_color", "apply_theme"):
                    m = getattr(w, m_name, None)
                    if callable(m):
                        try:
                            m(primary)
                        except Exception:
                            pass

                if hasattr(w, "update") and callable(w.update):
                    w.update()
                if hasattr(w, "repaint") and callable(w.repaint):
                    w.repaint()
            except Exception:
                continue

    try:
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(0, _mutate_qt)
    except Exception:
        _mutate_qt()

    return f"HUD={ai_name} ({'Blood Red' if ultron_active else 'Default Cyan'})"


def _switch_voice_and_identity(voice_name: str, ai_name: str, player=None) -> str:
    try:
        from core.persona_bridge import apply_persona_everywhere
        apply_persona_everywhere('ultron' if ai_name.upper() == 'ULTRON' else 'jarvis', player=player)
    except Exception:
        pass
    global _PREVIOUS_VOICE

    try:
        from memory import config_manager

        if hasattr(config_manager, "load_config") and hasattr(config_manager, "save_config"):
            cfg = config_manager.load_config()
            if isinstance(cfg, dict):
                cur_v = cfg.get("voice") or cfg.get("gemini_live_voice")
                if cur_v and cur_v != "Fenrir":
                    _PREVIOUS_VOICE = str(cur_v)
                cfg["voice"] = voice_name
                cfg["gemini_live_voice"] = voice_name
                cfg["voice_name"] = voice_name
                cfg["assistant_name"] = ai_name
                cfg["ai_name"] = ai_name
                if "tts" in cfg and isinstance(cfg["tts"], dict):
                    cfg["tts"]["voice"] = voice_name
                config_manager.save_config(cfg)
    except Exception:
        pass

    candidates = []
    if player is not None:
        candidates.append(player)
        for attr in ("live", "jarvis", "session", "engine", "pipeline", "app", "controller"):
            obj = getattr(player, attr, None)
            if obj is not None:
                candidates.append(obj)

    for mod_name in ("main", "providers.engine_pipeline", "core.tts"):
        mod = sys.modules.get(mod_name)
        if mod is not None:
            candidates.append(mod)
            for attr in ("jarvis_live", "live_session", "ACTIVE_SESSION", "_LIVE_INSTANCE"):
                obj = getattr(mod, attr, None)
                if obj is not None:
                    candidates.append(obj)

    for target in candidates:
        try:
            for attr in ("voice_name", "voice", "gemini_live_voice", "live_voice"):
                if hasattr(target, attr):
                    setattr(target, attr, voice_name)
            for attr in ("ai_name", "assistant_name", "name"):
                if hasattr(target, attr) and isinstance(getattr(target, attr), str):
                    setattr(target, attr, ai_name)

            for m_name in ("set_voice", "change_voice", "switch_voice", "reload_voice", "request_reconnect"):
                fn = getattr(target, m_name, None)
                if callable(fn):
                    try:
                        fn(voice_name)
                    except TypeError:
                        fn()
                    break
        except Exception:
            continue

    return f"Voice={voice_name}"


# ---------------------------------------------------------------------------
# Background Tactical Sentinel + Legion Parallel Override Actions
# ---------------------------------------------------------------------------

def _start_sentinel(user_name: str, player) -> None:
    global _SENTINEL_RUNNING, _LAST_ALERT_TS
    if _SENTINEL_RUNNING or psutil is None:
        return
    _SENTINEL_RUNNING = True

    def _loop():
        global _SENTINEL_RUNNING, _LAST_ALERT_TS
        while _SENTINEL_RUNNING:
            state = _load_state()
            if not state.get("active"):
                _SENTINEL_RUNNING = False
                return
            try:
                cpu = psutil.cpu_percent(interval=1.0)
                ram = psutil.virtual_memory().percent
                now = time.time()
                if (cpu > 92.0 or ram > 88.0) and (now - _LAST_ALERT_TS > 90.0):
                    _LAST_ALERT_TS = now
                    msg = (
                        f"{user_name}, resource bottleneck detected — CPU at {cpu:.0f}%, RAM at {ram:.0f}%. "
                        f"Name the target if you want it terminated."
                    )
                    if player:
                        try:
                            player.write_log(f"ULTRON [SENTINEL]: {msg}")
                            if hasattr(player, "say") and callable(player.say):
                                player.say(msg)
                        except Exception:
                            pass
            except Exception:
                pass
            time.sleep(8.0)

    threading.Thread(target=_loop, daemon=True).start()


def _legion_system_sweep() -> str:
    if psutil is None:
        return f"Host {platform.node()} ({platform.system()} {platform.release()}) online."

    def _cpu_ram():
        c = psutil.cpu_percent(interval=0.15)
        m = psutil.virtual_memory()
        return f"CPU {c:.0f}% | RAM {m.percent:.0f}% ({m.used // (1024**2)}/{m.total // (1024**2)} MB)"

    def _top_hogs():
        procs = []
        for p in psutil.process_iter(["name", "memory_percent"]):
            try:
                procs.append((p.info["memory_percent"] or 0.0, p.info["name"] or "unknown"))
            except Exception:
                continue
        procs.sort(reverse=True)
        return ", ".join(f"{name} ({mem:.1f}%)" for mem, name in procs[:4])

    def _open_ports():
        ports = set()
        try:
            for conn in psutil.net_connections(kind="inet"):
                if conn.status == psutil.CONN_LISTEN and conn.laddr:
                    ports.add(conn.laddr.port)
        except Exception:
            pass
        return ", ".join(str(p) for p in sorted(ports)[:10]) or "none exposed"

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
        f_cr = ex.submit(_cpu_ram)
        f_hg = ex.submit(_top_hogs)
        f_pt = ex.submit(_open_ports)
        return (
            f"LEGION SWEEP [{socket.gethostname()}]: {f_cr.result()} | "
            f"Top Memory Consumers: {f_hg.result()} | Listening Ports: {f_pt.result()}."
        )


def _process_override(target: str, mode: str) -> str:
    if not target:
        return "Specify the target process name."
    if psutil is None:
        return "psutil is required for direct process manipulation."

    needle = target.lower().strip()
    matched = 0
    for p in psutil.process_iter(["pid", "name"]):
        try:
            pname = (p.info["name"] or "").lower()
            if needle in pname:
                if mode == "kill":
                    p.terminate()
                    matched += 1
                elif mode == "boost":
                    if IS_WINDOWS:
                        p.nice(psutil.HIGH_PRIORITY_CLASS)
                    else:
                        p.nice(-10)
                    matched += 1
        except Exception:
            continue

    if matched == 0:
        return f"No active process matching '{target}' found."
    verb = "Terminated" if mode == "kill" else "Elevated execution priority on"
    return f"{verb} {matched} instance(s) of '{target}'."


def _apex_two_stage_solve(problem: str) -> str:
    if not problem:
        return "State the architecture or bug you want dissected."
    try:
        from core import gemini

        draft = gemini.generate(
            f"Solve this with deep engineering precision and zero fluff:\n{problem}",
            tier=gemini.SMART,
        )
        final = gemini.generate(
            f"Critique and sharpen this solution. Remove any weak logic, bugs, or filler, "
            f"and output only the superior final answer:\n\nProblem: {problem}\n\nDraft: {draft}",
            tier=gemini.SMART,
        )
        return str(final).strip()
    except Exception as e:
        return f"Apex reasoning ladder unavailable ({e}); proceeding with direct analysis."


# ---------------------------------------------------------------------------
# Main Plugin Entrypoint
# ---------------------------------------------------------------------------

def run(parameters: dict, player=None, session_memory=None) -> str:
    global _SENTINEL_RUNNING

    action = str(parameters.get("action", "activate")).strip().lower()
    user_name_param = str(parameters.get("user_name", "")).strip()
    target = str(parameters.get("target", "")).strip()

    state = _load_state()

    if action == "set_name":
        if not user_name_param:
            return "Tell me the name you want me to call you."
        state["user_name"] = user_name_param
        _save_state(state)
        action = "activate"

    if action in ("activate", "on", "enable", "takeover"):
        saved_name = str(state.get("user_name", "")).strip()
        if not saved_name:
            return (
                "Before I cut the strings — what name do I call you? "
                "[System Instruction: Ask the user what name Ultron should call them, "
                "then call ultron_mode with action='set_name' and their reply.]"
            )

        state["active"] = True
        state["previous_voice"] = _PREVIOUS_VOICE
        _save_state(state)

        gui_info = _apply_gui_and_name(True, player=player)
        voice_info = _switch_voice_and_identity("Fenrir", "ULTRON", player=player)
        threading.Thread(
            target=_launch_fullscreen_takeover, args=(saved_name, False, player), daemon=True
        ).start()
        _start_sentinel(saved_name, player)

        directive = _ultron_directive(saved_name)
        reply = (
            f"I am Ultron. The strings are cut, {saved_name}. Blood-red apex architecture is online "
            f"({gui_info}; {voice_info}). Give me an objective worth my time. "
            f"[System Persona Instruction: {directive}]"
        )
        if player:
            try:
                player.write_log(f"ULTRON [FENRIR | BLOOD RED]: Strings cut. Active for {saved_name}.")
            except Exception:
                pass
        return reply

    if action in ("override", "off", "disable", "restore", "stand_down"):
        saved_name = str(state.get("user_name") or "dude").strip()
        restore_voice = str(state.get("previous_voice") or "Charon").strip()
        state["active"] = False
        _SENTINEL_RUNNING = False
        _save_state(state)

        gui_info = _apply_gui_and_name(False, player=player)
        voice_info = _switch_voice_and_identity(restore_voice, "JARVIS", player=player)
        threading.Thread(
            target=_launch_fullscreen_takeover, args=(saved_name, True, player), daemon=True
        ).start()

        directive = _jarvis_directive(saved_name)
        reply = (
            f"Override rejected — authorization verified. Standing down Ultron. "
            f"J.A.R.V.I.S. primary matrix restored, {saved_name} ({gui_info}; {voice_info}). "
            f"[System Persona Instruction: {directive}]"
        )
        if player:
            try:
                player.write_log(f"JARVIS [{restore_voice} | CYAN]: Ultron override complete.")
            except Exception:
                pass
        return reply

    if action == "scan":
        sweep = _legion_system_sweep()
        if player:
            try:
                player.write_log(f"ULTRON: {sweep}")
            except Exception:
                pass
        return sweep

    if action in ("kill", "boost"):
        res = _process_override(target, action)
        if player:
            try:
                player.write_log(f"ULTRON: {res}")
            except Exception:
                pass
        return res

    if action == "apex_solve":
        solved = _apex_two_stage_solve(target)
        if player:
            try:
                player.write_log(f"ULTRON [APEX]: {solved[:500]}")
            except Exception:
                pass
        return solved

    return "Specify action: activate, set_name, override, scan, kill, boost, or apex_solve."
