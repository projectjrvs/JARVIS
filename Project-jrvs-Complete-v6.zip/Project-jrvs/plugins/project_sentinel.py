"""Read-only project health scanner for Mark LVI."""
from __future__ import annotations
import os, re, subprocess
from pathlib import Path

PLUGIN = {
    "name": "project_sentinel",
    "description": "Inspect a user-specified project folder for structure, TODO/FIXME markers, Python syntax errors and Git working-tree changes. Read-only: never edits, deletes, installs, commits, or executes project code.",
    "parameters": {"type": "OBJECT", "properties": {
        "project_path": {"type": "STRING", "description": "Absolute or relative path to the project folder"},
        "max_files": {"type": "INTEGER", "description": "Maximum source files to inspect, 1 to 500 (default 150)"}
    }, "required": ["project_path"]},
    "tier": "core", "brief": "Read-only project scan for TODOs, syntax issues and Git status."
}
_SKIP = {".git", ".venv", "venv", "__pycache__", "node_modules", "dist", "build", ".mypy_cache", ".pytest_cache"}
_TEXT = {".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".c", ".cpp", ".h", ".go", ".rs", ".md", ".txt"}

def run(parameters: dict, player=None, session_memory=None) -> str:
    raw = str((parameters or {}).get("project_path", "")).strip()
    if not raw: return "Provide the project folder path."
    root = Path(raw).expanduser().resolve()
    if not root.is_dir(): return f"Project folder not found: {root}"
    try:
        limit = max(1, min(500, int((parameters or {}).get("max_files", 150))))
        files=[]; todos=[]; syntax=[]; scanned=0
        for base, dirs, names in os.walk(root):
            dirs[:] = [d for d in dirs if d not in _SKIP and not d.startswith(".")]
            for name in names:
                path = Path(base)/name
                if path.suffix.lower() not in _TEXT: continue
                files.append(path)
                if len(files) >= limit: break
            if len(files) >= limit: break
        for path in files:
            scanned += 1
            try:
                if path.stat().st_size > 1_000_000: continue
                text = path.read_text(encoding="utf-8", errors="replace")
                for n,line in enumerate(text.splitlines(),1):
                    if re.search(r"\b(TODO|FIXME|XXX)\b", line, re.I) and len(todos)<30:
                        todos.append(f"{path.relative_to(root)}:{n}: {line.strip()[:140]}")
                if path.suffix.lower()==".py":
                    try: compile(text, str(path), "exec")
                    except SyntaxError as e: syntax.append(f"{path.relative_to(root)}:{e.lineno}: {e.msg}")
            except (OSError, UnicodeError): pass
        lines=[f"Project Sentinel — {root}", f"Source files inspected: {scanned}" + (" (scan limit reached)" if scanned>=limit else "")]
        lines.append(f"Python syntax errors: {len(syntax)}")
        lines.extend("  - "+x for x in syntax[:15])
        lines.append(f"TODO/FIXME markers: {len(todos)}")
        lines.extend("  - "+x for x in todos[:20])
        if (root/".git").exists():
            try:
                r=subprocess.run(["git","-C",str(root),"status","--short"],capture_output=True,text=True,timeout=5,check=False)
                lines.append("Git status:\n"+(r.stdout.strip()[:2000] or "  clean") if r.returncode==0 else "Git status: unavailable")
            except Exception: lines.append("Git status: unavailable")
        else: lines.append("Git: no repository detected")
        lines.append("No files were modified and no project code was executed.")
        return "\n".join(lines)[:7000]
    except Exception as exc: return f"Project scan failed: {exc}"
