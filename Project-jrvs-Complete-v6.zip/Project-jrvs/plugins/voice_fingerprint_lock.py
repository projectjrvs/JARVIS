"""
Biometric Acoustic Voiceprint Enrollment & Security Lock for Mark-LVI.
Requires the user to train their own vocal tract MFCC/spectral fingerprint first
(3-second live mic capture saved to memory/voiceprint_profile.json), then verifies
subsequent live voice samples against that enrolled voiceprint locally in <50ms.
Zero API calls.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

try:
    import numpy as np
except ImportError:
    np = None

try:
    import sounddevice as sd
except ImportError:
    sd = None


ROOT_DIR = Path(__file__).resolve().parent.parent
MEMORY_DIR = ROOT_DIR / "memory"
VOICEPRINT_PATH = MEMORY_DIR / "voiceprint_profile.json"

SAMPLE_RATE = 16000
SIMILARITY_THRESHOLD = 0.86


PLUGIN = {
    "name": "voice_fingerprint_lock",
    "description": (
        "Biometric acoustic voiceprint lock. Requires training on the user's real voice first "
        "via action='train' (records 3 seconds from microphone and saves their vocal fingerprint), "
        "then authenticates the speaker via action='verify'. Also supports action='status' and "
        "action='reset'. Trigger on phrases like 'train my voiceprint', 'enroll my voice', "
        "'verify my voice', 'check voice clearance', or 'voiceprint status'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'train' (or 'retrain'), 'verify', 'status', or 'reset'.",
            },
            "owner_name": {
                "type": "STRING",
                "description": "Optional owner label when training (default 'Authorized User').",
            },
        },
        "required": ["action"],
    },
}


def _extract_vocal_embedding(audio: "np.ndarray", sr: int = SAMPLE_RATE) -> list[float] | None:
    """Pure-NumPy 40-D MFCC vocal tract fingerprint extractor."""
    if np is None or audio.size < sr // 2:
        return None

    sig = audio.astype(np.float32).flatten()
    sig = sig - np.mean(sig)
    peak = float(np.max(np.abs(sig)))
    if peak < 1e-4:
        return None
    sig = sig / peak

    emphasized = np.append(sig[0], sig[1:] - 0.97 * sig[:-1])

    frame_len = int(0.025 * sr)
    hop_len = int(0.010 * sr)
    n_fft = 512
    n_mels = 26
    n_ceps = 20

    frames = []
    energies = []
    window = np.hamming(frame_len).astype(np.float32)
    for start in range(0, len(emphasized) - frame_len, hop_len):
        chunk = emphasized[start : start + frame_len]
        e = float(np.mean(chunk * chunk))
        frames.append(chunk * window)
        energies.append(e)

    if len(frames) < 10:
        return None

    frames_arr = np.stack(frames)
    energies_arr = np.array(energies)
    vad_thresh = max(float(np.percentile(energies_arr, 35)), 1e-5)
    voiced = frames_arr[energies_arr >= vad_thresh]
    if voiced.shape[0] < 8:
        return None

    mag = np.abs(np.fft.rfft(voiced, n=n_fft))
    pow_spec = (1.0 / n_fft) * (mag ** 2)

    low_mel = 2595.0 * np.log10(1.0 + 120.0 / 700.0)
    high_mel = 2595.0 * np.log10(1.0 + 7600.0 / 700.0)
    mel_pts = np.linspace(low_mel, high_mel, n_mels + 2)
    hz_pts = 700.0 * (10.0 ** (mel_pts / 2595.0) - 1.0)
    bins = np.floor((n_fft + 1) * hz_pts / sr).astype(int)

    fbank = np.zeros((n_mels, n_fft // 2 + 1), dtype=np.float32)
    for m in range(1, n_mels + 1):
        f_m_minus, f_m, f_m_plus = bins[m - 1], bins[m], bins[m + 1]
        for k in range(f_m_minus, f_m):
            if f_m != f_m_minus:
                fbank[m - 1, k] = (k - f_m_minus) / (f_m - f_m_minus)
        for k in range(f_m, f_m_plus):
            if f_m_plus != f_m:
                fbank[m - 1, k] = (f_m_plus - k) / (f_m_plus - f_m)

    mel_energies = np.dot(pow_spec, fbank.T)
    mel_energies = np.where(mel_energies <= 1e-10, 1e-10, mel_energies)
    log_mel = np.log(mel_energies)

    n = np.arange(n_mels, dtype=np.float32)
    k = np.arange(1, n_ceps + 1, dtype=np.float32)[:, None]
    dct_mat = np.cos(np.pi * k * (2.0 * n + 1.0) / (2.0 * n_mels))
    mfccs = np.dot(log_mel, dct_mat.T)

    vec = np.concatenate([np.mean(mfccs, axis=0), 0.5 * np.std(mfccs, axis=0)])
    norm = float(np.linalg.norm(vec))
    if norm < 1e-8:
        return None
    vec = vec / norm
    return [round(float(x), 6) for x in vec]


def _record_mic(seconds: float) -> "np.ndarray":
    assert sd is not None and np is not None
    frames = int(seconds * SAMPLE_RATE)
    rec = sd.rec(frames, samplerate=SAMPLE_RATE, channels=1, dtype="float32")
    sd.wait()
    return rec


def _load_profile() -> dict | None:
    if not VOICEPRINT_PATH.exists():
        return None
    try:
        data = json.loads(VOICEPRINT_PATH.read_text(encoding="utf-8"))
        if isinstance(data, dict) and isinstance(data.get("embedding"), list):
            return data
    except Exception:
        pass
    return None


def _cosine_sim(a: list[float], b: list[float]) -> float:
    va = np.array(a, dtype=np.float32)
    vb = np.array(b, dtype=np.float32)
    if va.shape != vb.shape:
        return 0.0
    denom = float(np.linalg.norm(va) * np.linalg.norm(vb))
    if denom < 1e-8:
        return 0.0
    return float(np.dot(va, vb) / denom)


def run(parameters: dict, player=None, session_memory=None) -> str:
    action = str(parameters.get("action", "status")).strip().lower()
    owner_name = str(parameters.get("owner_name", "Authorized User")).strip() or "Authorized User"

    if action == "reset":
        if VOICEPRINT_PATH.exists():
            VOICEPRINT_PATH.unlink()
        return "Biometric voiceprint wiped. Run 'train my voiceprint' to enroll a new voice."

    profile = _load_profile()

    if action == "status":
        if not profile:
            return "No voiceprint enrolled yet. Say 'train my voiceprint' first to calibrate security clearance."
        return f"Biometric voiceprint locked to '{profile.get('owner', 'Authorized User')}' (40-D MFCC profile active)."

    if np is None or sd is None:
        return "Install 'numpy' and 'sounddevice' (pip install numpy sounddevice) for biometric voiceprint capture."

    if action in ("train", "retrain", "enroll"):
        if player:
            try:
                player.write_log("SECURITY: Recording 3-second voiceprint sample — speak naturally now...")
            except Exception:
                pass
        try:
            audio = _record_mic(3.2)
        except Exception as e:
            return f"Microphone capture failed during voice training: {e}"

        emb = _extract_vocal_embedding(audio)
        if emb is None:
            return "Voice training failed — speech was too quiet or silent. Speak clearly for 3 seconds and try again."

        MEMORY_DIR.mkdir(parents=True, exist_ok=True)
        payload = {
            "owner": owner_name,
            "trained_at": time.time(),
            "embedding": emb,
        }
        VOICEPRINT_PATH.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        msg = f"Biometric voiceprint trained and locked to '{owner_name}'. Future verification will authenticate against this voice."
        if player:
            try:
                player.write_log(f"SECURITY: {msg}")
            except Exception:
                pass
        return msg

    if action == "verify":
        if not profile:
            return (
                "Access locked — no voiceprint trained yet. Say 'train my voiceprint' first and speak "
                "for 3 seconds so I can enroll your voice."
            )
        try:
            audio = _record_mic(2.3)
        except Exception as e:
            return f"Microphone capture failed during verification: {e}"

        probe = _extract_vocal_embedding(audio)
        if probe is None:
            return "Verification failed — no clear voice detected in microphone sample."

        score = _cosine_sim(profile["embedding"], probe)
        owner = profile.get("owner", "Authorized User")
        if score >= SIMILARITY_THRESHOLD:
            msg = f"CLEARANCE VERIFIED — Voiceprint matches '{owner}' ({score * 100:.1f}% match)."
        else:
            msg = f"SECURITY ALERT: VOICEPRINT MISMATCH ({score * 100:.1f}% similarity). Clearance denied."

        if player:
            try:
                player.write_log(f"SECURITY: {msg}")
            except Exception:
                pass
        return msg

    return "Specify action: train, verify, status, or reset."