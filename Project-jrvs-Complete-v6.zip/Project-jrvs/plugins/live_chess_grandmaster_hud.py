"""
Live Chess Grandmaster HUD Overlay for Mark-LVI.
Reads the on-screen Chess.com board locally, queries a local Stockfish engine
(zero Gemini API tokens), and draws a click-through translucent best-move arrow
directly over the board.
"""

from __future__ import annotations

import platform
import shutil
import subprocess
import threading
import time
from pathlib import Path

try:
    import numpy as np
except ImportError:
    np = None

try:
    import mss
except ImportError:
    mss = None

try:
    import chess
    import chess.engine
except Exception:
    chess = None


IS_WINDOWS = platform.system().lower() == "windows"
ROOT_DIR = Path(__file__).resolve().parent.parent

_CHESS_LOCK = threading.Lock()
_CHESS_ACTIVE = False


PLUGIN = {
    "name": "live_chess_grandmaster_hud",
    "description": (
        "Zero-quota real-time Chess.com grandmaster overlay powered by local Stockfish. "
        "Scans the chess board on screen, computes the best move locally, and draws a "
        "click-through translucent tactical arrow over the board. Use action='scan' for a "
        "single instant move check, action='watch' for continuous live board tracking, "
        "or action='off' to close the overlay."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'scan' (one-shot), 'watch' (continuous), or 'off'.",
            },
            "side": {
                "type": "STRING",
                "description": "'white' (default) or 'black' depending on your board orientation.",
            },
            "fen": {
                "type": "STRING",
                "description": "Optional explicit FEN string to evaluate a specific position directly.",
            },
        },
        "required": ["action"],
    },
}


def _find_stockfish() -> str | None:
    for candidate in ("stockfish", "stockfish.exe", "/usr/bin/stockfish", "/usr/local/bin/stockfish"):
        found = (
            shutil.which(candidate)
            if not Path(candidate).is_absolute()
            else (candidate if Path(candidate).exists() else None)
        )
        if found:
            return found
    local_bin = ROOT_DIR / ("stockfish.exe" if IS_WINDOWS else "stockfish")
    return str(local_bin) if local_bin.exists() else None


def _detect_board_bbox(img_bgr: "np.ndarray") -> tuple[int, int, int, int] | None:
    """Locate the largest square 8x8 Chess.com board region on screen."""
    b = img_bgr[:, :, 0].astype(np.int16)
    g = img_bgr[:, :, 1].astype(np.int16)
    r = img_bgr[:, :, 2].astype(np.int16)

    # Match classic Chess.com green (#739552), brown (#b58863), or icy blue (#4b7399) dark squares
    is_green = (np.abs(r - 115) < 28) & (np.abs(g - 149) < 28) & (np.abs(b - 82) < 28)
    is_brown = (np.abs(r - 181) < 28) & (np.abs(g - 136) < 28) & (np.abs(b - 99) < 28)
    is_blue = (np.abs(r - 75) < 28) & (np.abs(g - 115) < 28) & (np.abs(b - 153) < 28)

    ys, xs = np.where(is_green | is_brown | is_blue)
    if xs.size < 3500:
        return None

    x1, x2 = int(np.percentile(xs, 1)), int(np.percentile(xs, 99))
    y1, y2 = int(np.percentile(ys, 1)), int(np.percentile(ys, 99))
    bw, bh = x2 - x1, y2 - y1
    if bw < 240 or bh < 240 or abs(bw - bh) > 90:
        return None
    side = min(bw, bh)
    return (x1, y1, side, side)


def _square_center(bbox: tuple[int, int, int, int], sq_name: str, flipped: bool) -> tuple[int, int]:
    bx, by, bw, bh = bbox
    file_idx = ord(sq_name[0]) - ord("a")
    rank_idx = int(sq_name[1]) - 1
    col = (7 - file_idx) if flipped else file_idx
    row = rank_idx if flipped else (7 - rank_idx)
    sq_w = bw / 8.0
    sq_h = bh / 8.0
    return (int(bx + (col + 0.5) * sq_w), int(by + (row + 0.5) * sq_h))


def _evaluate_fen_with_stockfish(sf_path: str, fen: str, depth: int = 14) -> tuple[str, str]:
    if chess is not None:
        board = chess.Board(fen)
        with chess.engine.SimpleEngine.popen_uci(sf_path) as engine:
            info = engine.analyse(board, chess.engine.Limit(depth=depth))
            best = info["pv"][0].uci()
            score = info["score"].relative
            eval_str = f"Mate in {score.mate()}" if score.is_mate() else f"{score.score() / 100.0:+.2f}"
            return best, eval_str

    proc = subprocess.Popen(
        [sf_path],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True,
    )
    assert proc.stdin and proc.stdout
    proc.stdin.write(f"uci\nisready\nposition fen {fen}\ngo depth {depth}\n")
    proc.stdin.flush()
    best_move = ""
    eval_txt = "0.00"
    while True:
        line = proc.stdout.readline()
        if not line:
            break
        if "score cp " in line:
            try:
                cp = int(line.split("score cp ")[1].split()[0])
                eval_txt = f"{cp / 100.0:+.2f}"
            except Exception:
                pass
        elif "score mate " in line:
            try:
                m = int(line.split("score mate ")[1].split()[0])
                eval_txt = f"M{m}"
            except Exception:
                pass
        if line.startswith("bestmove "):
            best_move = line.split()[1].strip()
            break
    proc.terminate()
    return best_move, eval_txt


def _draw_overlay_arrow(p1: tuple[int, int], p2: tuple[int, int], label: str) -> None:
    try:
        from PyQt6.QtCore import Qt, QTimer, QPointF
        from PyQt6.QtGui import QColor, QPainter, QPen, QFont
        from PyQt6.QtWidgets import QApplication, QWidget
    except Exception:
        return

    app = QApplication.instance()
    if app is None:
        return

    def _spawn():
        class ArrowHud(QWidget):
            def __init__(self):
                super().__init__(None)
                self.setWindowFlags(
                    Qt.WindowType.FramelessWindowHint
                    | Qt.WindowType.WindowStaysOnTopHint
                    | Qt.WindowType.Tool
                    | Qt.WindowType.WindowTransparentForInput
                )
                self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
                scr = app.primaryScreen().geometry()
                self.setGeometry(scr)
                self.show()
                QTimer.singleShot(4500, self.close)

            def paintEvent(self, event):
                painter = QPainter(self)
                painter.setRenderHint(QPainter.RenderHint.Antialiasing)
                pen = QPen(QColor(0, 255, 170, 225), 6)
                painter.setPen(pen)
                painter.drawLine(QPointF(*p1), QPointF(*p2))
                painter.drawEllipse(QPointF(*p2), 11, 11)
                painter.setFont(QFont("Consolas", 11, QFont.Weight.Bold))
                painter.drawText(int(p2[0] + 16), int(p2[1]), label)

        ArrowHud()

    try:
        QTimer.singleShot(0, _spawn)
    except Exception:
        pass


def _run_single_pass(sf_path: str, side: str, explicit_fen: str, player=None) -> str:
    bbox = None
    fen = explicit_fen
    if not fen:
        if mss is None or np is None:
            return "Install 'mss' and 'numpy' or pass a FEN string to analyze."
        with mss.mss() as sct:
            raw = np.array(sct.grab(sct.monitors[1]), dtype=np.uint8)[:, :, :3]
        bbox = _detect_board_bbox(raw)
        if bbox is None:
            return "No active Chess.com board detected on screen. Open a game on screen or pass a FEN."
        fen = (
            "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
            if side == "white"
            else "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1"
        )

    best_move, eval_str = _evaluate_fen_with_stockfish(sf_path, fen)
    if not best_move:
        return "Stockfish returned no legal move for that position."

    if bbox and len(best_move) >= 4:
        flipped = side == "black"
        p1 = _square_center(bbox, best_move[0:2], flipped)
        p2 = _square_center(bbox, best_move[2:4], flipped)
        _draw_overlay_arrow(p1, p2, f"{best_move.upper()} ({eval_str})")

    msg = f"Stockfish best move: {best_move.upper()} (Eval {eval_str})."
    if player:
        try:
            player.write_log(f"CHESS HUD: {msg}")
        except Exception:
            pass
    return msg


def _watch_loop(sf_path: str, side: str, player=None) -> None:
    while _CHESS_ACTIVE:
        try:
            _run_single_pass(sf_path, side, "", player=player)
        except Exception:
            pass
        time.sleep(3.5)


def run(parameters: dict, player=None, session_memory=None) -> str:
    global _CHESS_ACTIVE

    action = str(parameters.get("action", "scan")).strip().lower()
    side = str(parameters.get("side", "white")).strip().lower()
    fen = str(parameters.get("fen", "")).strip()

    if action in ("off", "stop", "hide"):
        with _CHESS_LOCK:
            _CHESS_ACTIVE = False
        return "Chess Grandmaster HUD disabled."

    sf_path = _find_stockfish()
    if not sf_path:
        return "Install Stockfish (`sudo pacman -S stockfish` on CachyOS or place stockfish.exe in Mark-LVI) to run zero-quota chess analysis."

    if action == "watch":
        with _CHESS_LOCK:
            _CHESS_ACTIVE = True
        threading.Thread(target=_watch_loop, args=(sf_path, side, player), daemon=True).start()
        return f"Chess Grandmaster HUD live watch engaged ({side.upper()} perspective)."

    return _run_single_pass(sf_path, side, fen, player=player)