"""Read-only network diagnostics; no firewall or router changes."""
from __future__ import annotations
import socket, time, platform

PLUGIN = {
    "name": "network_intelligence",
    "description": "Diagnose basic internet and local network connectivity, DNS resolution, interface status and TCP reachability. Read-only: never changes Wi-Fi, firewall, router, DNS or network settings.",
    "parameters": {"type": "OBJECT", "properties": {
        "host": {"type": "STRING", "description": "Optional hostname to test, default example.com"}
    }, "required": []},
    "tier": "core", "brief": "Run safe read-only network and DNS diagnostics."
}

def run(parameters: dict, player=None, session_memory=None) -> str:
    host = str((parameters or {}).get("host", "example.com")).strip() or "example.com"
    if len(host) > 253 or any(c.isspace() for c in host): return "Please provide a valid hostname, not a URL or path."
    lines = ["Network Intelligence — read-only diagnostics", f"Platform: {platform.system()}", f"Test host: {host}"]
    try:
        start = time.perf_counter(); records = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
        elapsed = (time.perf_counter()-start)*1000
        addresses = sorted({r[4][0] for r in records})
        lines.append(f"DNS: OK ({elapsed:.0f} ms); {', '.join(addresses[:4])}")
    except Exception as exc:
        lines.append(f"DNS: FAILED — {type(exc).__name__}: {exc}"); return "\n".join(lines)
    try:
        start = time.perf_counter(); sock = socket.create_connection((host, 443), timeout=3.0)
        latency = (time.perf_counter()-start)*1000; sock.close()
        lines.append(f"TCP 443 reachability: OK ({latency:.0f} ms)")
    except Exception as exc: lines.append(f"TCP 443 reachability: FAILED — {type(exc).__name__}: {exc}")
    lines.append("Note: this is a quick connectivity check, not a full Wi-Fi signal or ISP speed test.")
    return "\n".join(lines)
