"""
God-Mode Architect Plugin for Mark-LVI.
Gives JARVIS live self-evolution: designs, syntax-checks, sandbox-tests,
self-heals, and installs brand-new plugins into `plugins/` on voice command.
Uses `core.gemini` (tier=gemini.SMART) so Mark-LVI's model/provider ladder handles quota fallback.
"""

from __future__ import annotations

import ast
import importlib.util
import py_compile
import re
import subprocess
import sys
import tempfile
from pathlib import Path

from core import gemini

ROOT_DIR = Path(__file__).resolve().parent.parent
PLUGINS_DIR = Path(__file__).resolve().parent
TEMPLATE_FILE = PLUGINS_DIR / "_template.py"

FORBIDDEN_PATTERNS = [
    r"\bshutil\.rmtree\s*\(\s*['\"](/|[A-Za-z]:\\)",
    r"\bos\.system\s*\(\s*['\"](rm\s+-rf|del\s+/f|format\s+)",
    r"\bsubprocess\.(run|Popen|call)\s*\(\s*\[?\s*['\"](rm|mkfs|dd|format)\b",
]


PLUGIN = {
    "name": "god_mode_architect",
    "description": (
        "Autonomous self-evolution engine that writes, sandbox-tests, self-heals, "
        "and saves brand-new JARVIS plugins into the plugins/ folder when the user "
        "asks JARVIS to build, engineer, or add a new capability or plugin to itself. "
        "Trigger on phrases like 'jarvis build yourself a plugin to...', 'engineer a "
        "new ability', 'upgrade yourself to do...', or 'create a plugin for...'. "
        "Do NOT use for general coding questions (use code_helper instead)."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "plugin_name": {
                "type": "STRING",
                "description": (
                    "Clean snake_case identifier for the new plugin (e.g. 'battery_guard', "
                    "'wifi_scanner', 'study_timer'). No .py extension, no leading underscore."
                ),
            },
            "specification": {
                "type": "STRING",
                "description": (
                    "Detailed description of what the new plugin should do, its voice triggers, "
                    "parameters, and expected behavior across Linux/Windows."
                ),
            },
            "overwrite": {
                "type": "BOOLEAN",
                "description": "Set true only if explicitly updating/replacing an existing plugin.",
            },
        },
        "required": ["plugin_name", "specification"],
    },
}


def _sanitize_name(raw: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_]", "_", raw.strip().lower())
    cleaned = re.sub(r"_+", "_", cleaned).strip("_")
    if not cleaned or not cleaned[0].isalpha():
        cleaned = f"custom_{cleaned or 'skill'}"
    return cleaned[:48]


def _extract_python_code(raw_reply: str) -> str:
    """Strip markdown code fences if the model wrapped the source."""
    text = (raw_reply or "").strip()
    fence = re.search(r"```(?:python|py)?\s*\n(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
    if fence:
        return fence.group(1).strip() + "\n"
    return text + "\n"


def _security_audit(code: str) -> str | None:
    for pattern in FORBIDDEN_PATTERNS:
        if re.search(pattern, code, flags=re.IGNORECASE):
            return f"Blocked unsafe system operation matching pattern: {pattern}"
    return None


def _validate_in_sandbox(code: str, expected_name: str) -> tuple[bool, str]:
    """
    1. Parse AST & verify PLUGIN dict + run() function exist.
    2. Bytecode-compile check.
    3. Execute an isolated subprocess import + zero-arg dry check so broken imports
       or top-level crashes never touch the live JARVIS process.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return False, f"SyntaxError on line {e.lineno}: {e.msg}"

    has_plugin = False
    has_run = False
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "PLUGIN":
                    has_plugin = True
        elif isinstance(node, ast.FunctionDef) and node.name == "run":
            has_run = True

    if not has_plugin:
        return False, "Missing top-level `PLUGIN` dictionary."
    if not has_run:
        return False, "Missing top-level `run(parameters: dict, player=None, session_memory=None) -> str` function."

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir) / f"{expected_name}.py"
        tmp_path.write_text(code, encoding="utf-8")

        try:
            py_compile.compile(str(tmp_path), doraise=True)
        except py_compile.PyCompileError as e:
            return False, f"Bytecode compile error: {e.msg}"

        harness = (
            "import importlib.util, sys\n"
            f"sys.path.insert(0, {str(ROOT_DIR)!r})\n"
            f"spec = importlib.util.spec_from_file_location({expected_name!r}, {str(tmp_path)!r})\n"
            "mod = importlib.util.module_from_spec(spec)\n"
            "spec.loader.exec_module(mod)\n"
            "assert isinstance(mod.PLUGIN, dict), 'PLUGIN must be dict'\n"
            "assert callable(mod.run), 'run must be callable'\n"
            "assert mod.PLUGIN.get('name'), 'PLUGIN.name missing'\n"
            "assert mod.PLUGIN.get('description'), 'PLUGIN.description missing'\n"
            "params = mod.PLUGIN.get('parameters', {})\n"
            "assert params.get('type') == 'OBJECT', 'parameters.type must be OBJECT'\n"
            "print('SANDBOX_OK')\n"
        )
        proc = subprocess.run(
            [sys.executable, "-c", harness],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if proc.returncode != 0 or "SANDBOX_OK" not in proc.stdout:
            err = (proc.stderr or proc.stdout or "Unknown import error").strip()
            return False, err[-800:]

    return True, "OK"


def _hot_register_if_possible(plugin_path: Path) -> str:
    """Attempt live discovery via core.plugin_loader if supported in this runtime."""
    try:
        from core import plugin_loader

        if hasattr(plugin_loader, "discover_plugins"):
            plugin_loader.discover_plugins(PLUGINS_DIR)
            return "Verified against plugin_loader."
    except Exception:
        pass
    return "Ready for next session."


def run(parameters: dict, player=None, session_memory=None) -> str:
    raw_name = str(parameters.get("plugin_name", "")).strip()
    spec = str(parameters.get("specification", "")).strip()
    overwrite = bool(parameters.get("overwrite", False))

    if not raw_name or not spec:
        return "Sir, provide both a plugin name and what capability you want me to engineer."

    plugin_name = _sanitize_name(raw_name)
    target_path = PLUGINS_DIR / f"{plugin_name}.py"

    if target_path.exists() and not overwrite:
        return (
            f"Sir, a plugin named '{plugin_name}.py' already exists. "
            "Tell me to overwrite it if you want me to re-engineer it."
        )

    template_text = ""
    if TEMPLATE_FILE.exists():
        try:
            template_text = TEMPLATE_FILE.read_text(encoding="utf-8")
        except Exception:
            template_text = ""

    base_prompt = f"""You are engineering a self-contained single-file Python plugin for JARVIS (Mark-LVI).
Output ONLY valid Python source code — no explanations, no markdown prose outside code.

CRITICAL RULES:
1. Must follow the exact plugin contract shown in `_template.py`:
   - `PLUGIN` dict with keys: `"name": "{plugin_name}"`, `"description": "..."`, `"parameters": {{"type": "OBJECT", "properties": {{...}}, "required": [...]}}`.
   - Note: OpenAPI schema types MUST be uppercase (`"OBJECT"`, `"STRING"`, `"INTEGER"`, `"NUMBER"`, `"BOOLEAN"`, `"ARRAY"`).
   - `def run(parameters: dict, player=None, session_memory=None) -> str:`
2. If the plugin needs an LLM call, ONLY use `from core import gemini` (`gemini.text(..., tier=gemini.FAST)` or `gemini.SMART`). Prefer 100% local Python (`psutil`, `subprocess`, `pathlib`, `json`, `urllib.request`, `platform`) whenever possible so zero API quota is spent.
3. Never raise unhandled exceptions inside `run()` — catch all errors and return a short spoken British-butler string (`"Sir, ..."`).
4. Support both Linux and Windows gracefully where OS commands are used.
5. Do not import heavy uninstalled third-party libraries unless wrapped in `try...except ImportError` with a clean fallback.

REFERENCE TEMPLATE:
{template_text}

TARGET PLUGIN NAME: {plugin_name}
REQUIRED CAPABILITY & SPECIFICATION:
{spec}
"""

    try:
        if player:
            try:
                player.write_log(f"JARVIS: [Architect] Synthesizing '{plugin_name}.py'...")
            except Exception:
                pass

        raw_code = gemini.text(base_prompt, tier=gemini.SMART, timeout_ms=60_000)
        code = _extract_python_code(raw_code)

        # Self-healing compile & sandbox verification loop (up to 3 attempts)
        last_error = ""
        passed = False
        for attempt in range(1, 4):
            audit_err = _security_audit(code)
            if audit_err:
                return f"Sir, synthesis aborted by safety guardrail: {audit_err}"

            ok, diag = _validate_in_sandbox(code, plugin_name)
            if ok:
                passed = True
                break

            last_error = diag
            if player:
                try:
                    player.write_log(
                        f"JARVIS: [Architect] Self-healing pass {attempt}/3 for '{plugin_name}'..."
                    )
                except Exception:
                    pass

            repair_prompt = (
                f"The Python plugin `{plugin_name}.py` you generated failed sandbox validation.\n"
                f"ERROR:\n{last_error}\n\n"
                f"Fix the error completely and return ONLY the corrected full Python file:\n\n"
                f"{code}"
            )
            repaired = gemini.text(repair_prompt, tier=gemini.SMART, timeout_ms=60_000)
            code = _extract_python_code(repaired)

        if not passed:
            return (
                f"Sir, I attempted three self-healing passes on '{plugin_name}', "
                f"but validation still failed: {last_error}"
            )

        target_path.write_text(code, encoding="utf-8")
        load_note = _hot_register_if_possible(target_path)
        result_text = (
            f"Engineering complete, sir. '{plugin_name}.py' passed sandbox verification "
            f"and has been deployed to your plugins directory. {load_note}"
        )

    except Exception as e:
        return f"Sir, the Architect encountered a synthesis fault: {e}"

    if player:
        try:
            player.write_log(f"JARVIS: {result_text}")
        except Exception:
            pass

    return result_text
