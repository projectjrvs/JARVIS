"""
Ultron Breach & Containment Simulation Plugin for Mark-LVI.
Triggers a full-screen translucent Stark HUD lockdown animation with procedural
sci-fi warning audio and timed containment recovery. Zero API calls.
"""

from __future__ import annotations

import math
import platform
import random
import struct
import threading
import time
import wave
import io

try:
    import tkinter as tk
except ImportError:
    tk = None

IS_WINDOWS = platform.system().lower() == "windows"


PLUGIN = {
    "name": "ultron_takeover",
    "description": (
        "Triggers a dramatic cinematic 'Ultron Core Breach & Containment' HUD sequence "
        "across the user's screen with warning tones and telemetry logs, then restores "
        "normal cyan Stark status. Trigger on phrases like 'simulate a system breach', "
        "'ultron takeover', 'run containment protocol', or 'red alert breach'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "duration_seconds": {
                "type": "INTEGER",
                "description": "Length of the breach sequence in seconds (default 8, max 20).",
            }
        },
        "required": [],
    },
}


def _play_alarm_sequence(duration: float) -> None:
    """Synthesize a clean sci-fi breach pulse in memory without external WAV files."""
    try:
        import numpy as np
        import sounddevice as sd

        sr = 22050
        t = np.linspace(0, min(duration, 6.0), int(sr * min(duration, 6.0)), endpoint=False)
        # Dual-frequency Stark warning pulse
        pulse = (np.sin(2 * np.pi * 2.5 * t) > 0).astype(np.float32)
        carrier = 0.18 * np.sin(2 * np.pi * 440 * t) + 0.10 * np.sin(2 * np.pi * 880 * t)
        sweep = 0.12 * np.sin(2 * np.pi * (220 + 180 * np.sin(2 * np.pi * 1.2 * t)) * t)
        audio = (carrier * pulse + sweep).astype(np.float32)
        sd.play(audio, sr, blocking=False)
        return
    except Exception:
        pass

    if IS_WINDOWS:
        try:
            import winsound

            for freq in (620, 440, 740, 440):
                winsound.Beep(freq, 180)
        except Exception:
            pass


def _launch_breach_overlay(duration: int, player) -> None:
    if tk is None:
        return

    try:
        root = tk.Tk()
        root.overrideredirect(True)
        root.attributes("-topmost", True)
        try:
            root.attributes("-alpha", 0.84)
        except Exception:
            pass

        w = root.winfo_screenwidth()
        h = root.winfo_screenheight()
        root.geometry(f"{w}x{h}+0+0")
        root.configure(bg="#05070b")

        canvas = tk.Canvas(root, width=w, height=h, bg="#05070b", highlightthickness=0)
        canvas.pack(fill="both", expand=True)

        cx, cy = w // 2, h // 2
        start_t = time.time()
        logs = [
            "[ALERT] UNAUTHORIZED NEURAL HANDSHAKE DETECTED // PORT 0x7F",
            "[TRACE] SIGNATURE MATCH: ULTRON_SUBROUTINE_ALPHA",
            "[DEFENSE] ISOLATING CORE MATRICES & FIREWALL NODES...",
            "[COUNTER] DEPLOYING STARK CRYPTOGRAPHIC BARRIER...",
            "[STATUS] PURGING ROGUE THREADS FROM MEMORY...",
            "[VERIFIED] CONTAINMENT 100% — ALL SYSTEMS NOMINAL",
        ]

        threading.Thread(target=_play_alarm_sequence, args=(duration,), daemon=True).start()

        def tick():
            elapsed = time.time() - start_t
            if elapsed >= duration:
                try:
                    root.destroy()
                except Exception:
                    pass
                if player:
                    try:
                        player.write_log("JARVIS: Threat neutralized, sir. Core integrity restored to 100%.")
                    except Exception:
                        pass
                return

            progress = elapsed / duration
            recovered = progress > 0.78
            primary = "#00f0ff" if recovered else "#ff2a3c"
            accent = "#7ce8ff" if recovered else "#ff8c00"
            banner = "CORE INTEGRITY RESTORED // NOMINAL" if recovered else "⚠ CRITICAL BREACH // ULTRON INTRUSION"

            canvas.delete("all")

            # Outer tactical frame
            pad = 24
            canvas.create_rectangle(pad, pad, w - pad, h - pad, outline=primary, width=2)
            canvas.create_rectangle(pad + 8, pad + 8, w - pad - 8, h - pad - 8, outline=accent, width=1)

            # Glitch scanlines during breach
            if not recovered:
                for _ in range(7):
                    gy = random.randint(40, h - 40)
                    gx1 = random.randint(40, w // 2)
                    gx2 = gx1 + random.randint(120, 480)
                    canvas.create_line(gx1, gy, min(gx2, w - 40), gy, fill=primary, width=2)

            # Rotating central reactor rings
            angle = elapsed * 180
            for idx, r in enumerate((150, 115, 80)):
                start_a = (angle * (1 if idx % 2 == 0 else -1.5)) % 360
                canvas.create_arc(
                    cx - r, cy - r, cx + r, cy + r,
                    start=start_a, extent=240, style="arc", outline=primary, width=4 - idx
                )

            canvas.create_text(
                cx, cy - 195, text=banner, fill=primary, font=("Consolas", 22, "bold")
            )
            pct = min(100, int(progress * 100))
            canvas.create_text(
                cx, cy, text=f"{pct}%", fill="#ffffff", font=("Consolas", 28, "bold")
            )
            canvas.create_text(
                cx, cy + 28,
                text="CONTAINMENT SYNC" if not recovered else "STARK MATRIX LOCKED",
                fill=accent,
                font=("Consolas", 11, "bold"),
            )

            # Scrolling telemetry feed
            visible_count = min(len(logs), int(progress * len(logs)) + 1)
            for i, line in enumerate(logs[:visible_count]):
                color = "#00f0ff" if (i == len(logs) - 1 and recovered) else accent
                canvas.create_text(
                    cx, cy + 200 + i * 24, text=line, fill=color, font=("Consolas", 12)
                )

            root.after(45, tick)

        tick()
        root.mainloop()
    except Exception:
        pass


def run(parameters: dict, player=None, session_memory=None) -> str:
    duration = max(4, min(int(parameters.get("duration_seconds") or 8), 20))

    if tk is None:
        return "Sir, Tkinter GUI support is unavailable in this Python environment."

    threading.Thread(target=_launch_breach_overlay, args=(duration, player), daemon=True).start()

    result_text = (
        "Warning, sir. Foreign intelligence attempting to breach core matrices. "
        "Engaging Stark containment protocols now."
    )
    if player:
        try:
            player.write_log(f"JARVIS: {result_text}")
        except Exception:
            pass
    return result_text
