"""Read-only performance snapshots for Mark LVI and the host machine."""
from __future__ import annotations
import os, time, platform

PLUGIN = {
    "name": "performance_intelligence",
    "description": "Report current CPU, RAM, disk and process metrics plus lightweight JARVIS plugin health information. Read-only and does not kill processes, change priorities, or tune system settings.",
    "parameters": {"type": "OBJECT", "properties": {
        "top_processes": {"type": "INTEGER", "description": "Number of top memory-consuming processes to show, 0 to 10 (default 5)"}
    }, "required": []},
    "tier": "core", "brief": "Take a read-only CPU, memory, disk and process performance snapshot."
}

def run(parameters: dict, player=None, session_memory=None) -> str:
    try:
        import psutil
    except Exception:
        return "Performance metrics need the existing psutil dependency. Install the project's requirements.txt and restart JARVIS."
    try:
        p=parameters or {}; top=max(0,min(10,int(p.get("top_processes",5))))
        cpu=psutil.cpu_percent(interval=0.4); mem=psutil.virtual_memory(); disk=psutil.disk_usage(os.path.abspath(os.sep))
        lines=["Performance Intelligence — current snapshot",f"OS: {platform.system()} {platform.release()}",f"CPU: {cpu:.1f}%",f"RAM: {mem.percent:.1f}% ({mem.used/1024**3:.1f} / {mem.total/1024**3:.1f} GB)",f"System disk: {disk.percent:.1f}% used ({disk.free/1024**3:.1f} GB free)"]
        if top:
            rows=[]
            for proc in psutil.process_iter(["name","memory_info"]):
                try:
                    info=proc.info; rss=(info.get("memory_info").rss if info.get("memory_info") else 0)
                    rows.append((rss,info.get("name") or "unknown"))
                except (psutil.NoSuchProcess,psutil.AccessDenied): pass
            rows.sort(reverse=True)
            lines.append("Top memory processes:")
            lines.extend(f"  - {name}: {rss/1024**2:.0f} MB" for rss,name in rows[:top])
        registry=getattr(player,"get_plugins",None)
        if callable(registry):
            try:
                records=registry(); valid=sum(1 for x in records if x.get("valid")); invalid=sum(1 for x in records if not x.get("valid"))
                lines.append(f"Plugin registry: {valid} valid, {invalid} rejected")
                lines.extend(f"  - {x.get('name')}: {x.get('error')}" for x in records if not x.get("valid"))
            except Exception: pass
        lines.append("Snapshot only: no processes or settings were changed.")
        return "\n".join(lines)
    except Exception as exc: return f"Performance snapshot failed: {exc}"
