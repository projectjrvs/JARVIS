"""
Kinetic Gesture Air-Mouse & HUD Controller ('Minority Report Mode') for Mark-LVI.
Uses lightweight CPU OpenCV optical flow & contour kinematics on your webcam
(zero ML model overhead, zero Gemini API calls) to trigger workspace swipes,
Boss-Key mute/minimize, and silent Ultron Mode toggles via hand gestures.
"""

from __future__ import annotations

import importlib
import platform
import subprocess
import sys
import threading
import time

try:
    import cv2
except ImportError:
    cv2 = None

try:
    import numpy as np
except ImportError:
    np = None

try:
    import pyautogui
    pyautogui.PAUSE = 0.0
except Exception:
    pyautogui = None


IS_WINDOWS = platform.system().lower() == "windows"

_GESTURE_LOCK = threading.Lock()
_GESTURE_ACTIVE = False
_GESTURE_STATS = {"active": False, "last_gesture": "none", "triggers": 0}


PLUGIN = {
    "name": "kinetic_gesture_airmouse",
    "description": (
        "Webcam air-gesture controller ('Minority Report Mode'). Uses zero-API OpenCV "
        "motion kinematics to switch virtual workspaces via air-swipes, trigger Boss-Key "
        "mute/minimize via held palm, or toggle Ultron Mode via rapid double-wave. "
        "Use action='on' (or 'start'), action='off' (or 'stop'), or action='status'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'on', 'off', or 'status'.",
            },
            "camera_index": {
                "type": "INTEGER",
                "description": "Webcam index (default 0).",
            },
        },
        "required": ["action"],
    },
}


def _switch_workspace(direction: str) -> None:
    if IS_WINDOWS:
        if pyautogui is not None:
            key = "left" if direction == "left" else "right"
            pyautogui.hotkey("ctrl", "win", key)
        return

    # CachyOS / KDE Plasma or standard X11/Wayland
    if pyautogui is not None:
        key = "left" if direction == "left" else "right"
        pyautogui.hotkey("ctrl", "alt", key)


def _trigger_boss_key() -> None:
    if IS_WINDOWS:
        if pyautogui is not None:
            pyautogui.press("volumemute")
            pyautogui.hotkey("win", "d")
        return

    try:
        subprocess.run(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "1"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass
    if pyautogui is not None:
        pyautogui.hotkey("ctrl", "alt", "d")


def _toggle_ultron_silently(player=None) -> None:
    try:
        mod = sys.modules.get("plugins.ultron_mode") or importlib.import_module("plugins.ultron_mode")
        if hasattr(mod, "run") and hasattr(mod, "_load_state"):
            st = mod._load_state()
            act = "override" if st.get("active") else "activate"
            mod.run({"action": act}, player=player)
    except Exception:
        pass


def _gesture_worker(cam_idx: int, player=None) -> None:
    global _GESTURE_ACTIVE, _GESTURE_STATS

    if cv2 is None or np is None:
        with _GESTURE_LOCK:
            _GESTURE_ACTIVE = False
        return

    cap = cv2.VideoCapture(cam_idx)
    if not cap.isOpened():
        with _GESTURE_LOCK:
            _GESTURE_ACTIVE = False
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)

    prev_gray = None
    last_trigger_ts = 0.0
    palm_hold_start = 0.0
    swipe_history: list[tuple[float, str]] = []

    with _GESTURE_LOCK:
        _GESTURE_STATS = {"active": True, "last_gesture": "ready", "triggers": 0}

    try:
        while _GESTURE_ACTIVE:
            ok, frame = cap.read()
            if not ok or frame is None:
                time.sleep(0.03)
                continue

            frame = cv2.flip(frame, 1)
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (15, 15), 0)

            if prev_gray is None:
                prev_gray = gray
                continue

            diff = cv2.absdiff(prev_gray, gray)
            prev_gray = gray
            _, thresh = cv2.threshold(diff, 28, 255, cv2.THRESH_BINARY)
            thresh = cv2.dilate(thresh, None, iterations=2)

            contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            now = time.time()

            if contours:
                largest = max(contours, key=cv2.contourArea)
                area = cv2.contourArea(largest)

                # Significant hand/arm motion region
                if 2800 < area < 48000:
                    x, y, w, h = cv2.boundingRect(largest)
                    cx = x + w / 2.0

                    # Detect rapid horizontal air-swipe across center third
                    if w > h * 1.15 and (now - last_trigger_ts > 1.1):
                        direction = "right" if cx > 195 else ("left" if cx < 125 else "")
                        if direction:
                            swipe_history.append((now, direction))
                            swipe_history = [s for s in swipe_history if now - s[0] < 1.3]

                            # Rapid double-wave -> silent Ultron toggle
                            if len(swipe_history) >= 2 and swipe_history[-1][1] != swipe_history[-2][1]:
                                swipe_history.clear()
                                last_trigger_ts = now
                                _toggle_ultron_silently(player)
                                with _GESTURE_LOCK:
                                    _GESTURE_STATS["last_gesture"] = "double_wave_ultron"
                                    _GESTURE_STATS["triggers"] += 1
                            else:
                                last_trigger_ts = now
                                _switch_workspace(direction)
                                with _GESTURE_LOCK:
                                    _GESTURE_STATS["last_gesture"] = f"swipe_{direction}"
                                    _GESTURE_STATS["triggers"] += 1
                                if player:
                                    try:
                                        player.write_log(f"GESTURE: Air-swipe {direction.upper()} -> switched workspace.")
                                    except Exception:
                                        pass

                    # Held steady open-hand presence in upper-center -> Boss Key
                    elif area > 12000 and (now - last_trigger_ts > 2.5):
                        if palm_hold_start == 0.0:
                            palm_hold_start = now
                        elif now - palm_hold_start >= 1.15:
                            palm_hold_start = 0.0
                            last_trigger_ts = now
                            _trigger_boss_key()
                            with _GESTURE_LOCK:
                                _GESTURE_STATS["last_gesture"] = "palm_boss_key"
                                _GESTURE_STATS["triggers"] += 1
                            if player:
                                try:
                                    player.write_log("GESTURE: Open-palm hold -> Boss Key mute/minimize engaged.")
                                except Exception:
                                    pass
                    else:
                        palm_hold_start = 0.0
                else:
                    palm_hold_start = 0.0
            else:
                palm_hold_start = 0.0

            time.sleep(0.025)
    finally:
        cap.release()
        with _GESTURE_LOCK:
            _GESTURE_ACTIVE = False
            _GESTURE_STATS["active"] = False


def run(parameters: dict, player=None, session_memory=None) -> str:
    global _GESTURE_ACTIVE

    action = str(parameters.get("action", "status")).strip().lower()
    cam_idx = int(parameters.get("camera_index") or 0)

    if action in ("off", "stop", "disable"):
        with _GESTURE_LOCK:
            _GESTURE_ACTIVE = False
        msg = "Kinetic air-gesture controller offline."
        if player:
            try:
                player.write_log(f"GESTURE: {msg}")
            except Exception:
                pass
        return msg

    if action == "status":
        with _GESTURE_LOCK:
            st = dict(_GESTURE_STATS)
        if not st.get("active"):
            return "Kinetic air-gesture controller is currently offline."
        return f"Air-gesture controller ACTIVE | Last gesture: {st.get('last_gesture')} | Triggers: {st.get('triggers')}."

    if cv2 is None or np is None:
        return "Install 'opencv-python' and 'numpy' (pip install opencv-python numpy) to enable air-gesture control."

    with _GESTURE_LOCK:
        if _GESTURE_ACTIVE:
            return "Kinetic air-gesture controller is already active."
        _GESTURE_ACTIVE = True

    threading.Thread(target=_gesture_worker, args=(cam_idx, player), daemon=True).start()
    msg = (
        "Minority Report air-gesture control online: swipe left/right to switch workspaces, "
        "hold palm 1.2s for Boss-Key mute/minimize, or double-wave for silent Ultron override."
    )
    if player:
        try:
            player.write_log(f"GESTURE: {msg}")
        except Exception:
            pass
    return msg