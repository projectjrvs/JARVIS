"""
Stark Suit Protocols Plugin for Mark-LVI.
Transforms your CachyOS / Windows workspace with one MCU-style voice protocol.
Zero external LLM API calls.
"""

import os
import platform
import shutil
import subprocess
import webbrowser

IS_WINDOWS = platform.system().lower() == "windows"
IS_LINUX = platform.system().lower() == "linux"


PLUGIN = {
    "name": "protocol_launcher",
    "description": (
        "Executes multi-step Stark 'Suit Protocols' to morph the user's computer "
        "workspace at once. Trigger when the user says phrases like 'initiate "
        "workshop protocol', 'activate study protocol', 'engage stealth mode', "
        "'gaming protocol', or 'clean slate protocol'. Do NOT use for opening "
        "a single normal app (use open_app instead)."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "protocol": {
                "type": "STRING",
                "description": (
                    "The protocol to engage: 'workshop' (coding/dev setup), "
                    "'study' (focus mode, closes games/distractions), "
                    "'stealth' (minimizes windows, mutes volume, dims screen), "
                    "'gaming' (launches gaming tools & closes heavy dev apps), "
                    "or 'clean_slate' (closes non-essential user apps & resets workspace)."
                ),
            }
        },
        "required": ["protocol"],
    },
}


def _spawn_detached(cmd: list[str]) -> bool:
    """Launch an application without blocking Mark-LVI."""
    try:
        if IS_WINDOWS:
            subprocess.Popen(
                cmd,
                creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        else:
            subprocess.Popen(
                cmd,
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        return True
    except Exception:
        return False


def _launch_first_available(candidates: list[list[str]]) -> str | None:
    for cmd in candidates:
        exe = cmd[0]
        if shutil.which(exe) or (IS_WINDOWS and os.path.exists(exe)):
            if _spawn_detached(cmd):
                return exe
    return None


def _kill_processes(names: list[str]) -> int:
    closed = 0
    for proc in names:
        try:
            if IS_WINDOWS:
                res = subprocess.run(
                    ["taskkill", "/F", "/IM", f"{proc}.exe"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            else:
                res = subprocess.run(
                    ["pkill", "-f", proc],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            if res.returncode == 0:
                closed += 1
        except Exception:
            pass
    return closed


def _set_stealth_system() -> list[str]:
    notes = []
    try:
        if IS_WINDOWS:
            # Mute audio via PowerShell WScript.Shell
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    "(New-Object -ComObject WScript.Shell).SendKeys([char]173)",
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            # Minimize all windows
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    "(New-Object -ComObject Shell.Application).MinimizeAll()",
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            notes.append("audio toggled and desktop minimized")
        elif IS_LINUX:
            if shutil.which("wpctl"):
                subprocess.run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "1"], check=False)
                notes.append("PipeWire audio muted")
            elif shutil.which("pactl"):
                subprocess.run(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "1"], check=False)
                notes.append("audio muted")
            if shutil.which("brightnessctl"):
                subprocess.run(["brightnessctl", "set", "15%"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                notes.append("display dimmed to 15%")
            if shutil.which("qdbus6"):
                subprocess.run(
                    ["qdbus6", "org.kde.kglobalaccel", "/component/kwin", "invokeShortcut", "Show Desktop"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                notes.append("windows minimized")
    except Exception:
        pass
    return notes


def _run_workshop() -> str:
    launched = []
    ide = _launch_first_available([["code"], ["code-oss"], ["codium"]])
    if ide:
        launched.append("Code editor")

    term = _launch_first_available([["konsole"], ["alacritty"], ["kitty"], ["wt.exe"], ["cmd.exe"]])
    if term:
        launched.append("terminal")

    _kill_processes(["steam", "discord", "hl2_linux", "java"])
    summary = ", ".join(launched) if launched else "local workspace environment"
    return f"Workshop Protocol engaged, sir. {summary} online and background distractions cleared."


def _run_study() -> str:
    killed = _kill_processes(["steam", "discord", "telegram-desktop", "sklauncher", "java"])
    if IS_LINUX and shutil.which("notify-send"):
        subprocess.run(
            ["notify-send", "J.A.R.V.I.S. — Study Protocol", "Distractions purged. Focus subroutine active."],
            check=False,
        )
    return (
        f"Study Protocol active, sir. Purged {killed} distracting process groups. "
        "All non-essential telemetry suppressed."
    )


def _run_stealth() -> str:
    actions = _set_stealth_system()
    detail = ", ".join(actions) if actions else "low-profile posture applied"
    return f"Stealth Protocol engaged, sir — {detail}. Running silent."


def _run_gaming() -> str:
    _kill_processes(["code", "code-oss"])
    launched = _launch_first_available([["sklauncher"], ["steam"], ["lutris"]])
    if IS_LINUX and shutil.which("powerprofilesctl"):
        subprocess.run(["powerprofilesctl", "set", "performance"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    target = f"{launched} initialized" if launched else "system tuned for maximum frame throughput"
    return f"Combat Gaming Protocol online, sir. {target} and power diverted to performance."


def _run_clean_slate() -> str:
    killed = _kill_processes(
        ["chrome", "chromium", "firefox", "brave", "code", "code-oss", "steam", "discord", "vlc"]
    )
    return (
        f"Clean Slate Protocol executed, sir. Terminated {killed} active application clusters. "
        "Workspace reset to baseline."
    )


def run(parameters: dict, player=None, session_memory=None) -> str:
    raw = str(parameters.get("protocol", "")).strip().lower().replace(" ", "_")

    aliases = {
        "dev": "workshop",
        "coding": "workshop",
        "focus": "study",
        "exam": "study",
        "panic": "stealth",
        "ghost": "stealth",
        "combat": "gaming",
        "game": "gaming",
        "house_party": "workshop",
        "reset": "clean_slate",
        "wipe": "clean_slate",
    }
    protocol = aliases.get(raw, raw)

    try:
        if protocol == "workshop":
            result_text = _run_workshop()
        elif protocol == "study":
            result_text = _run_study()
        elif protocol == "stealth":
            result_text = _run_stealth()
        elif protocol == "gaming":
            result_text = _run_gaming()
        elif protocol == "clean_slate":
            result_text = _run_clean_slate()
        else:
            result_text = (
                "Sir, specify a valid protocol: Workshop, Study, Stealth, Gaming, or Clean Slate."
            )
    except Exception as e:
        return f"Sir, protocol execution encountered a fault: {e}"

    if player:
        try:
            player.write_log(f"JARVIS: {result_text}")
        except Exception:
            pass

    return result_text
