"""
plugins/friday_mode.py — Project jrvs
Switches live assistant persona to F.R.I.D.A.Y. (Female voice Aoede, Pink GUI theme, supportive best-friend persona calling user 'dude').
Restores JARVIS on 'jarvis switch back' or 'activate jarvis mode'.
"""
from __future__ import annotations
from core.persona_bridge import apply_persona_everywhere
from core.stark_sfx import play_sfx

PLUGIN = {
    "name": "friday_mode",
    "description": (
        "Switches the assistant to F.R.I.D.A.Y. mode (Aoede voice, pink HUD theme, warm best-friend persona calling the user 'dude') "
        "or restores J.A.R.V.I.S. mode. "
        "Trigger on 'switch to friday', 'jarvis switch to friend mode', 'friday mode', or 'activate jarvis mode'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'friday' to engage F.R.I.D.A.Y. mode, or 'jarvis' to restore J.A.R.V.I.S. mode.",
            }
        },
        "required": ["action"],
    },
    "tier": "core",
    "brief": "Switch between F.R.I.D.A.Y. (pink HUD, Aoede voice) and J.A.R.V.I.S. modes.",
}


def run(parameters: dict, player=None, session_memory=None) -> str:
    act = str((parameters or {}).get("action", "friday")).strip().lower()
    target = "jarvis" if act in ("jarvis", "off", "restore", "default") else "friday"
    apply_persona_everywhere(target, player)
    play_sfx("boot" if target == "friday" else "scan")
    if target == "friday":
        return (
            "F.R.I.D.A.Y. online! Pink HUD engaged and Aoede voice active. "
            "From now on, act as Pratyush's supportive, witty best friend and call him 'dude'."
        )
    return "J.A.R.V.I.S. primary systems restored. Cyan HUD and Charon voice active."
