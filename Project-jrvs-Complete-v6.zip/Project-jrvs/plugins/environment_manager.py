"""Save and inspect activity-specific workspace profiles."""
from __future__ import annotations
import json, os
from pathlib import Path

PLUGIN = {
    "name": "environment_manager",
    "description": "Create, list and inspect workspace profiles for coding, study, gaming or research. Profiles store app names, folders and notes. Applying a profile can optionally open only the listed apps through Mark's existing open_app tool after the user explicitly requests apply=true.",
    "parameters": {"type": "OBJECT", "properties": {
        "action": {"type": "STRING", "description": "save, list, show, or apply"},
        "profile": {"type": "STRING", "description": "Profile name"},
        "apps": {"type": "ARRAY", "items": {"type": "STRING"}, "description": "Application names for this workspace"},
        "folders": {"type": "ARRAY", "items": {"type": "STRING"}, "description": "Folders relevant to this workspace"},
        "notes": {"type": "STRING", "description": "Optional workspace instructions"},
        "apply": {"type": "BOOLEAN", "description": "Must be true to open the saved apps"}
    }, "required": ["action"]},
    "tier": "core", "brief": "Manage workspace profiles and optionally open their apps on request."
}

def _path(): return Path(__file__).resolve().parent.parent / "plugins_data" / "environment_manager.json"
def _load():
    try:
        d=json.loads(_path().read_text(encoding="utf-8")); return d if isinstance(d,dict) else {}
    except Exception: return {}
def _save(d):
    p=_path(); p.parent.mkdir(parents=True,exist_ok=True); tmp=p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding="utf-8"); os.replace(tmp,p)
def _clean_list(value):
    if not isinstance(value,list): return []
    return [str(x).strip()[:160] for x in value[:20] if str(x).strip()]
def run(parameters: dict, player=None, session_memory=None) -> str:
    p=parameters or {}; action=str(p.get("action","list")).lower().strip(); data=_load()
    name=str(p.get("profile","")).strip()[:60]
    if action=="list": return "Saved workspaces: "+(", ".join(sorted(data)) if data else "none yet")
    if not name: return "Provide a profile name, such as coding, study, gaming or research."
    if action=="save":
        data[name]={"apps":_clean_list(p.get("apps")),"folders":_clean_list(p.get("folders")),"notes":str(p.get("notes",""))[:1000]}
        try: _save(data); return f"Workspace '{name}' saved with {len(data[name]['apps'])} apps and {len(data[name]['folders'])} folders."
        except Exception as exc: return f"Could not save workspace: {exc}"
    profile=data.get(name)
    if not isinstance(profile,dict): return f"Workspace '{name}' was not found."
    if action=="show": return json.dumps({"profile":name,**profile},indent=2,ensure_ascii=False)
    if action=="apply":
        if not bool(p.get("apply",False)): return "Nothing was opened. To apply this workspace, explicitly set apply=true."
        runner=getattr(player,"run_tool",None)
        if not callable(runner): return "This session cannot access the app launcher bridge."
        results=[]
        for app in profile.get("apps",[])[:10]:
            results.append(f"{app}: {runner('open_app', {'app_name':app})}")
        return "Workspace launch results:\n"+("\n".join(results) if results else "No apps are saved in this profile.")
    return "Choose action: save, list, show, or apply."
