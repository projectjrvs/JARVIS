"""
plugins/daily_tracker_plugin.py — Project jrvs
Opens the user's synced Protocol Daily Schedule web tracker.
"""
from __future__ import annotations
import webbrowser

TRACKER_URL = "https://daily-schedule-duo.netlify.app"

PLUGIN = {
    "name": "daily_tracker_plugin",
    "description": (
        "Opens the user's Protocol daily schedule and habit tracker web app in the browser. "
        "Trigger on 'open daily tracker', 'open my schedule', or 'launch protocol tracker'."
    ),
    "parameters": {"type": "OBJECT", "properties": {}, "required": []},
    "tier": "core",
    "brief": "Open the Protocol daily habit and schedule tracker.",
}


def run(parameters: dict, player=None, session_memory=None) -> str:
    webbrowser.open(TRACKER_URL, new=2)
    return "Opening your Protocol Daily Schedule tracker, dude."
