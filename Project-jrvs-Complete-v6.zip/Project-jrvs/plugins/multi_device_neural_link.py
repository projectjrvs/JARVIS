"""Companion for Mark LVI's existing authenticated phone dashboard."""
from __future__ import annotations
import socket
from pathlib import Path

PLUGIN = {
    "name": "multi_device_neural_link",
    "description": "Help connect the existing Mark LVI PC assistant to its phone dashboard. Reports local network addresses and explains the built-in pairing flow; does not create an exposed server, open firewall ports, or transmit data itself.",
    "parameters": {"type": "OBJECT", "properties": {
        "action": {"type": "STRING", "description": "status or instructions"}
    }, "required": []},
    "tier": "core", "brief": "Check the existing secure phone dashboard and show pairing guidance."
}

def _local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.settimeout(1.5); s.connect(("1.1.1.1", 80)); return s.getsockname()[0]
    except Exception: return "unavailable"
    finally: s.close()

def run(parameters: dict, player=None, session_memory=None) -> str:
    try:
        root = Path(__file__).resolve().parent.parent
        server_file = root / "dashboard" / "server.py"
        if not server_file.exists(): return "The built-in dashboard server was not found. Update this plugin for the current JARVIS folder."
        ip = _local_ip()
        action = str((parameters or {}).get("action", "status")).lower()
        lines = ["Multi-Device Neural Link", f"PC local address: {ip}", "Existing Mark LVI dashboard: detected", "Dashboard ports: HTTP 8000 (redirect) / dashboard 8001 (HTTPS when configured)."]
        if action in {"instructions", "pair", "connect"}:
            lines += ["Open JARVIS → Remote Control / phone dashboard.", "Generate a fresh pairing key in the dashboard UI and scan its QR code or open its displayed URL on your phone.", "Use the same trusted local Wi-Fi network. Pair only devices you control; revoke device sessions from the dashboard if a device is lost."]
        else:
            lines += ["To pair: open JARVIS → Remote Control. The app generates the pairing code and QR URL; this plugin deliberately does not expose ports or create a second server.", "A LAN address is reachable only from devices on a network that permits local-device connections."]
        return "\n".join(lines)
    except Exception as exc: return f"Neural Link status check failed: {exc}"
