"""
Symbiotic Self-Mutator & Live Hot-Reload Engine for Mark-LVI.
Inspects, validates (ast.parse), backs up, patches, and hot-reloads any plugin
in plugins/ in real time without restarting Mark-LVI.
"""

from __future__ import annotations

import ast
import importlib
import shutil
import sys
from pathlib import Path


PLUGINS_DIR = Path(__file__).resolve().parent
BACKUP_DIR = PLUGINS_DIR / ".backups"


PLUGIN = {
    "name": "symbiotic_self_mutator",
    "description": (
        "Live self-evolution engine for Mark-LVI plugins. Lists plugins, reads plugin source code, "
        "applies AST-verified live code upgrades with automatic backups, rolls back broken edits, "
        "and hot-reloads plugins in memory without restarting Mark-LVI. "
        "Use action='list', 'inspect', 'patch', 'reload', or 'rollback'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'list', 'inspect', 'patch', 'reload', or 'rollback'.",
            },
            "plugin_name": {
                "type": "STRING",
                "description": "Target plugin filename without .py (e.g. 'ultron_mode').",
            },
            "new_code": {
                "type": "STRING",
                "description": "Complete updated Python source code (used with action='patch').",
            },
        },
        "required": ["action"],
    },
}


def _resolve_plugin_path(plugin_name: str) -> Path | None:
    clean = plugin_name.strip().removesuffix(".py")
    if not clean or "/" in clean or "\\" in clean or ".." in clean:
        return None
    return PLUGINS_DIR / f"{clean}.py"


def _hot_reload_module(clean_name: str) -> str:
    candidates = [f"plugins.{clean_name}", clean_name]
    reloaded = []
    for mod_name in candidates:
        if mod_name in sys.modules:
            importlib.reload(sys.modules[mod_name])
            reloaded.append(mod_name)
    if not reloaded:
        mod = importlib.import_module(f"plugins.{clean_name}")
        reloaded.append(mod.__name__)
    return ", ".join(reloaded)


def run(parameters: dict, player=None, session_memory=None) -> str:
    action = str(parameters.get("action", "list")).strip().lower()
    plugin_name = str(parameters.get("plugin_name", "")).strip()
    new_code = str(parameters.get("new_code", "")).strip()

    if action == "list":
        files = sorted(
            p.stem for p in PLUGINS_DIR.glob("*.py")
            if not p.name.startswith("_")
        )
        return f"Active plugins ({len(files)}): " + ", ".join(files) + "."

    target_path = _resolve_plugin_path(plugin_name)
    if target_path is None:
        return "Provide a valid plugin_name (e.g. 'ultron_mode')."
    clean_name = target_path.stem

    if action == "inspect":
        if not target_path.exists():
            return f"Plugin '{clean_name}.py' does not exist."
        src = target_path.read_text(encoding="utf-8")
        lines = src.splitlines()
        return f"Source of {clean_name}.py ({len(lines)} lines):\n```python\n{src[:6500]}\n```"

    if action == "reload":
        if not target_path.exists():
            return f"Plugin '{clean_name}.py' not found."
        try:
            loaded = _hot_reload_module(clean_name)
            msg = f"Hot-reloaded '{clean_name}' live in memory ({loaded}) — zero restart needed."
        except Exception as e:
            msg = f"Hot-reload failed for '{clean_name}': {e}"
        if player:
            try:
                player.write_log(f"MUTATOR: {msg}")
            except Exception:
                pass
        return msg

    if action == "rollback":
        backup_file = BACKUP_DIR / f"{clean_name}.py.bak"
        if not backup_file.exists():
            return f"No backup snapshot found for '{clean_name}'."
        try:
            shutil.copy2(backup_file, target_path)
            loaded = _hot_reload_module(clean_name)
            msg = f"Rolled back '{clean_name}.py' to previous snapshot and hot-reloaded ({loaded})."
        except Exception as e:
            msg = f"Rollback failed: {e}"
        if player:
            try:
                player.write_log(f"MUTATOR: {msg}")
            except Exception:
                pass
        return msg

    if action == "patch":
        if not new_code:
            return "Provide new_code to patch the plugin."
        # Strip accidental markdown code fences if passed
        if new_code.startswith("```"):
            lines = new_code.splitlines()
            if lines[-1].strip() == "```":
                new_code = "\n".join(lines[1:-1]).strip()

        # AST syntax gate before touching disk
        try:
            tree = ast.parse(new_code)
        except SyntaxError as syn_err:
            return f"Mutation aborted — Python syntax error on line {syn_err.lineno}: {syn_err.msg}."

        has_run = any(
            isinstance(node, ast.FunctionDef) and node.name == "run"
            for node in tree.body
        )
        if not has_run:
            return "Mutation aborted — plugin must define a top-level `run(...)` function."

        try:
            BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            if target_path.exists():
                shutil.copy2(target_path, BACKUP_DIR / f"{clean_name}.py.bak")
            target_path.write_text(new_code + "\n", encoding="utf-8")
            loaded = _hot_reload_module(clean_name)
            msg = f"Self-mutation complete: '{clean_name}.py' verified, backed up, written, and hot-reloaded ({loaded})."
        except Exception as e:
            msg = f"Patch failed: {e}"

        if player:
            try:
                player.write_log(f"MUTATOR: {msg}")
            except Exception:
                pass
        return msg

    return "Specify action: list, inspect, patch, reload, or rollback."