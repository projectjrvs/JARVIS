"""
plugins/orb_mode.py — Project jrvs
Voice & command trigger for Exclusive Roamies-Style 3D LED Orb Mode.
  - 'orb mode' / 'minimize to orb'  -> Hides full HUD completely, shows ONLY floating 3D LED Orb.
  - 'orb mode off' / 'expand hud'    -> Hides floating Orb completely, restores ONLY full HUD.
"""
from __future__ import annotations

PLUGIN = {
    "name": "orb_mode",
    "description": (
        "Switches exclusively between Full HUD Mode and Floating 3D LED Orb Mode. "
        "When action='on', hides the main JARVIS window completely so ONLY the floating "
        "Roamies-style 3D LED sphere orb is visible on screen. "
        "When action='off', hides the orb completely and restores the full HUD. "
        "Trigger on 'orb mode', 'orb mode on', 'minimize to orb', 'orb mode off', or 'expand hud'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'on' (orb only, no HUD), 'off' (full HUD only, no orb), or 'toggle'.",
            }
        },
        "required": ["action"],
    },
    "tier": "core",
    "brief": "Switch exclusively between Full HUD Mode and Floating 3D LED Orb Mode.",
}


def run(parameters: dict, player=None, session_memory=None) -> str:
    action = str((parameters or {}).get("action", "toggle")).strip().lower()
    if action in ("enable", "activate", "minimize", "start", "true", "on"):
        action = "on"
    elif action in ("disable", "deactivate", "expand", "restore", "stop", "false", "off"):
        action = "off"
    else:
        action = "toggle"

    if player is None or not hasattr(player, "set_orb_mode"):
        return "Orb Mode controller is not attached to this UI session."

    is_orb = player.set_orb_mode(action)
    if is_orb:
        return "Orb Mode engaged, dude. Main HUD hidden — only the 3D LED core is active."
    return "Full HUD restored, dude. Floating orb dismissed."
