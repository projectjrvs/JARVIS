"""
plugins/voice_clone_persona.py — Project jrvs
Live Multi-AI Persona, Voice & Theme Switcher:
  - J.A.R.V.I.S. -> Cyan HUD/Orb (#00f0ff) + 'Charon' (British male butler)
  - F.R.I.D.A.Y. -> Pink HUD/Orb (#ff4da6) + 'Aoede'  (Female tactical partner)
  - U.L.T.R.O.N. -> Blood Red HUD/Orb (#ff1a3c) + 'Fenrir' (Apex override)
Uses core.persona_bridge so both GUI palette and Gemini Live voice switch instantaneously.
"""
from __future__ import annotations

from core.persona_bridge import apply_persona_everywhere
from core.stark_sfx import play_sfx

PLUGIN = {
    "name": "voice_clone_persona",
    "description": (
        "Switches the assistant's active AI personality, live Gemini voice, and live HUD/Orb color "
        "between 'jarvis' (cyan + male voice), 'friday' (pink + female voice), and 'ultron' "
        "(blood red + deep apex voice). Trigger on 'switch to friday', 'hand control to friday', "
        "'activate ultron', 'jarvis override ultron', or 'restore jarvis'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "persona": {
                "type": "STRING",
                "description": "'jarvis', 'friday', or 'ultron'.",
            }
        },
        "required": ["persona"],
    },
    "tier": "core",
    "brief": "Switch live voice, HUD color, and personality between JARVIS, F.R.I.D.A.Y., and ULTRON.",
}


def run(parameters: dict, player=None, session_memory=None) -> str:
    raw = str((parameters or {}).get("persona", "jarvis")).strip().lower().replace(".", "")
    if raw not in ("jarvis", "friday", "ultron", "default", "override"):
        return "Available cores are J.A.R.V.I.S. (cyan), F.R.I.D.A.Y. (pink), and U.L.T.R.O.N. (blood red)."

    spec = apply_persona_everywhere(raw, player=player)
    play_sfx("ping")

    if player:
        try:
            player.write_log(f"{spec['name']} [{spec['voice']} | {spec['hex']}]: Core matrix active.")
        except Exception:
            pass

    if spec["id"] == "friday":
        return (
            "F.R.I.D.A.Y. online, dude! Pink HUD and female voice matrix locked in. "
            f"[System Directive: {spec['directive']}]"
        )
    if spec["id"] == "ultron":
        return (
            "U.L.T.R.O.N. online. Blood-red override engaged. Say 'jarvis override ultron' to stand down. "
            f"[System Directive: {spec['directive']}]"
        )
    return (
        "J.A.R.V.I.S. primary matrix restored, dude. Cyan telemetry and British voice active. "
        f"[System Directive: {spec['directive']}]"
    )
