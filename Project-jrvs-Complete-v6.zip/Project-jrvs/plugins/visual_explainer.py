"""
plugins/visual_explainer.py — Project jrvs
Renders interactive flowcharts, timelines, worked math, and 3D wireframes directly inside the HUD.
"""
from __future__ import annotations
from core.stark_sfx import play_sfx

PLUGIN = {
    "name": "visual_explainer",
    "description": (
        "Explains any concept visually on the HUD using structured flowcharts, step-by-step math, "
        "timelines, or 3D wireframe diagrams instead of plain walls of text. "
        "Trigger on 'show me visually', 'draw a diagram of', 'explain visually', or 'visualize'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "title": {"type": "STRING", "description": "Title of the visual board."},
            "mode": {"type": "STRING", "description": "'flowchart', 'math', 'timeline', or '3d_diagram'."},
            "nodes": {
                "type": "ARRAY",
                "items": {"type": "STRING"},
                "description": "Ordered steps, equations, or components to render visually.",
            },
            "summary": {"type": "STRING", "description": "Concise caption below the diagram."},
        },
        "required": ["title", "mode", "nodes"],
    },
    "tier": "core",
    "brief": "Render visual flowcharts, worked math, timelines, and diagrams on the HUD.",
}


def run(parameters: dict, player=None, session_memory=None) -> str:
    p = parameters or {}
    title = str(p.get("title", "Visual Blueprint")).strip()
    mode = str(p.get("mode", "flowchart")).strip().lower()
    nodes = [str(x).strip() for x in (p.get("nodes") or []) if str(x).strip()]
    summary = str(p.get("summary", "")).strip()

    if not nodes:
        return "Provide at least two nodes or steps to render visually."

    lines = [f"◈ VISUAL EXPLAINER [{mode.upper()}] — {title}", "=" * 54]
    for idx, item in enumerate(nodes, 1):
        connector = "   │\n   ▼" if (mode in ("flowchart", "timeline") and idx < len(nodes)) else ""
        lines.append(f"[{idx:02d}] {item}")
        if connector:
            lines.append(connector)
    if summary:
        lines.extend(["", f"INSIGHT: {summary}"])

    board = "\n".join(lines)
    play_sfx("scan")
    if player and hasattr(player, "show_content"):
        player.show_content(f"VISUAL // {title}", board)
    return f"Visual diagram '{title}' rendered on your HUD, dude."
