"""
plugins/circle_to_ask.py — Project jrvs
Launches the interactive Circle-to-Ask screen selection overlay via voice or command.
"""
from __future__ import annotations

PLUGIN = {
    "name": "circle_to_ask",
    "description": (
        "Opens the interactive Circle-to-Ask screen overlay so the user can circle or drag "
        "around anything on their screen and ask a question about it. "
        "Trigger on 'circle to ask', 'circle this', 'select on screen', or 'scan screen region'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {},
    },
    "tier": "core",
    "brief": "Launch interactive Circle-to-Ask screen selection overlay.",
}


def run(parameters: dict, player=None, session_memory=None) -> str:
    if player is None or not hasattr(player, "open_circle_to_ask"):
        return "Circle-to-Ask overlay is not attached to this UI session."
    player.open_circle_to_ask()
    return "Circle-to-Ask overlay active. Drag across anything on screen and press Enter."
