"""
Autonomous Process & Screen Watcher Plugin for Mark-LVI.
Monitors background tasks, builds, downloads, or screen changes locally
and announces completion via JARVIS's thread-safe speech channel.
Zero Gemini API calls.
"""

import hashlib
import os
import platform
import subprocess
import threading
import time
import uuid

try:
    import psutil
except ImportError:
    psutil = None

try:
    import mss
except ImportError:
    mss = None

try:
    from PIL import ImageGrab
except ImportError:
    ImageGrab = None


IS_WINDOWS = platform.system().lower() == "windows"
_ACTIVE_WATCHES: dict[str, dict] = {}
_WATCH_LOCK = threading.Lock()


PLUGIN = {
    "name": "auto_pilot_watch",
    "description": (
        "Starts a silent background watcher to monitor a running process/download/build "
        "until it finishes, OR monitors the screen for visual changes, and speaks an alert "
        "when done. Trigger on phrases like 'watch [process] and tell me when it finishes', "
        "'ping me when the update/download is done', 'watch the screen for changes', "
        "'check active watches', or 'cancel watches'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": (
                    "Action to perform: 'watch_process' (monitor a named app/command until exit), "
                    "'watch_screen' (alert when screen content changes), "
                    "'status' (list active watches), or 'cancel' (stop all active watches)."
                ),
            },
            "target": {
                "type": "STRING",
                "description": (
                    "Process or keyword to watch when action is 'watch_process' "
                    "(e.g. 'paru', 'pacman', 'python', 'ffmpeg', 'steam', 'chrome')."
                ),
            },
            "timeout_minutes": {
                "type": "INTEGER",
                "description": "Maximum minutes to keep watching before auto-stopping (default 30).",
            },
        },
        "required": ["action"],
    },
}


def _notify_user(player, message: str) -> None:
    """Speak and log asynchronously via Mark-LVI's UI hooks."""
    if not player:
        return
    try:
        player.write_log(f"JARVIS: {message}")
    except Exception:
        pass
    try:
        if hasattr(player, "say") and callable(player.say):
            player.say(message)
        elif hasattr(player, "speak") and callable(player.speak):
            player.speak(message)
    except Exception:
        pass


def _is_process_running(keyword: str) -> bool:
    kw = keyword.lower().strip()
    if not kw:
        return False

    if psutil is not None:
        for proc in psutil.process_iter(["name", "cmdline"]):
            try:
                name = (proc.info.get("name") or "").lower()
                cmdline = " ".join(proc.info.get("cmdline") or []).lower()
                if kw in name or kw in cmdline:
                    return True
            except Exception:
                continue
        return False

    # Fallback if psutil is not installed
    try:
        if IS_WINDOWS:
            out = subprocess.check_output(["tasklist"], text=True, stderr=subprocess.DEVNULL).lower()
            return kw in out
        else:
            res = subprocess.run(["pgrep", "-f", kw], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return res.returncode == 0
    except Exception:
        return False


def _grab_screen_digest() -> str | None:
    """Return a fast MD5 digest of a downsampled primary-screen capture."""
    try:
        if mss is not None:
            with mss.mss() as sct:
                monitor = sct.monitors[1] if len(sct.monitors) > 1 else sct.monitors[0]
                raw = sct.grab(monitor)
                # Subsample every 16th byte for ultra-fast, low-CPU hashing
                return hashlib.md5(raw.rgb[::16]).hexdigest()
        if ImageGrab is not None:
            img = ImageGrab.grab().resize((160, 90))
            return hashlib.md5(img.tobytes()).hexdigest()
    except Exception:
        return None
    return None


def _process_watch_worker(watch_id: str, target: str, timeout_sec: int, player) -> None:
    deadline = time.time() + timeout_sec
    saw_running = _is_process_running(target)

    # Give the user up to 15s if they just started the command right after speaking
    grace_until = time.time() + 15
    while not saw_running and time.time() < grace_until:
        with _WATCH_LOCK:
            if watch_id not in _ACTIVE_WATCHES:
                return
        time.sleep(1.5)
        saw_running = _is_process_running(target)

    if not saw_running:
        with _WATCH_LOCK:
            _ACTIVE_WATCHES.pop(watch_id, None)
        _notify_user(player, f"Sir, I could not detect an active '{target}' process to monitor.")
        return

    while time.time() < deadline:
        with _WATCH_LOCK:
            if watch_id not in _ACTIVE_WATCHES:
                return
        if not _is_process_running(target):
            with _WATCH_LOCK:
                _ACTIVE_WATCHES.pop(watch_id, None)
            _notify_user(player, f"Sir, the '{target}' process has finished execution.")
            return
        time.sleep(2.5)

    with _WATCH_LOCK:
        _ACTIVE_WATCHES.pop(watch_id, None)
    _notify_user(player, f"Sir, watch timeout reached for '{target}'. It is still running.")


def _screen_watch_worker(watch_id: str, timeout_sec: int, player) -> None:
    baseline = _grab_screen_digest()
    if baseline is None:
        with _WATCH_LOCK:
            _ACTIVE_WATCHES.pop(watch_id, None)
        _notify_user(player, "Sir, screen capture libraries are unavailable for visual watch.")
        return

    deadline = time.time() + timeout_sec
    # 3-second settle delay so HUD log updates don't immediately self-trigger
    time.sleep(3.0)
    baseline = _grab_screen_digest() or baseline

    while time.time() < deadline:
        with _WATCH_LOCK:
            if watch_id not in _ACTIVE_WATCHES:
                return
        current = _grab_screen_digest()
        if current and current != baseline:
            with _WATCH_LOCK:
                _ACTIVE_WATCHES.pop(watch_id, None)
            _notify_user(player, "Sir, visual activity detected on your primary display.")
            return
        time.sleep(2.0)

    with _WATCH_LOCK:
        _ACTIVE_WATCHES.pop(watch_id, None)
    _notify_user(player, "Sir, screen watch window expired with no significant changes.")


def run(parameters: dict, player=None, session_memory=None) -> str:
    action = str(parameters.get("action", "")).strip().lower()
    target = str(parameters.get("target", "")).strip()
    timeout_min = int(parameters.get("timeout_minutes") or 30)
    timeout_sec = max(60, min(timeout_min * 60, 4 * 3600))

    try:
        if action == "watch_process":
            if not target:
                return "Sir, specify which process or task you would like me to monitor."
            watch_id = str(uuid.uuid4())[:8]
            with _WATCH_LOCK:
                _ACTIVE_WATCHES[watch_id] = {"type": "process", "target": target}
            t = threading.Thread(
                target=_process_watch_worker,
                args=(watch_id, target, timeout_sec, player),
                daemon=True,
            )
            t.start()
            result_text = f"Understood, sir. Silently monitoring '{target}' — I will notify you the moment it concludes."

        elif action == "watch_screen":
            watch_id = str(uuid.uuid4())[:8]
            with _WATCH_LOCK:
                _ACTIVE_WATCHES[watch_id] = {"type": "screen", "target": "primary_display"}
            t = threading.Thread(
                target=_screen_watch_worker,
                args=(watch_id, timeout_sec, player),
                daemon=True,
            )
            t.start()
            result_text = "Visual telemetry locked on your primary display, sir. I will alert you upon any state change."

        elif action == "status":
            with _WATCH_LOCK:
                items = list(_ACTIVE_WATCHES.values())
            if not items:
                result_text = "No active background watches running at the moment, sir."
            else:
                desc = ", ".join(f"{w['type']} ({w['target']})" for w in items)
                result_text = f"Currently tracking {len(items)} watch thread(s), sir: {desc}."

        elif action == "cancel":
            with _WATCH_LOCK:
                count = len(_ACTIVE_WATCHES)
                _ACTIVE_WATCHES.clear()
            result_text = f"Cleared {count} active background watch subroutine(s), sir."

        else:
            result_text = "Sir, specify whether to watch a process, watch the screen, check status, or cancel watches."

    except Exception as e:
        return f"Sir, auto_pilot_watch encountered a fault: {e}"

    if player:
        try:
            player.write_log(f"JARVIS: {result_text}")
        except Exception:
            pass

    return result_text
