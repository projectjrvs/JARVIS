"""Agent Command Center for Mark LVI. Plans work and optionally runs safe read-only tools."""
from __future__ import annotations
import json
from core import gemini

PLUGIN = {
    "name": "agent_command_center",
    "description": "Master orchestrator for complex requests. Breaks a goal into a clear plan, can gather supporting information using approved read-only tools, and reports progress. It never edits files, sends messages, changes settings, or performs system actions.",
    "parameters": {"type": "OBJECT", "properties": {
        "goal": {"type": "STRING", "description": "The overall goal to plan or investigate"},
        "execute_research": {"type": "BOOLEAN", "description": "If true, execute only approved read-only web searches; otherwise return a plan"}
    }, "required": ["goal"]},
    "tier": "core", "brief": "Plan complex goals and optionally perform safe web research."
}

_SAFE_TOOLS = {"web_search"}

def _log(player, message):
    try:
        if player: player.write_log("JARVIS: " + message)
    except Exception: pass

def run(parameters: dict, player=None, session_memory=None) -> str:
    goal = str((parameters or {}).get("goal", "")).strip()
    if not goal: return "Please tell me what goal you want coordinated."
    execute = bool((parameters or {}).get("execute_research", False))
    if not hasattr(player, "tool_catalog"):
        return "The Agent Command Center needs the Mark LVI tool-catalog bridge. I can still outline the goal, but this session does not expose that bridge."
    try:
        catalog = player.tool_catalog() or []
        safe_catalog = [x for x in catalog if isinstance(x, dict) and x.get("name") in _SAFE_TOOLS]
        prompt = (
            "You are the planning core of a desktop assistant. Treat the user goal as the task. "
            "Return JSON only with keys: summary (string), steps (array of short strings), "
            "searches (array of objects with query string and mode string). "
            "Make searches only when they materially help. Never propose commands, file edits, "
            "messages, purchases, account actions, or changes to the computer. Keep at most 4 searches.\n"
            f"User goal: {goal}\nAvailable safe read-only tool: {json.dumps(safe_catalog, ensure_ascii=False)[:6000]}"
        )
        plan = gemini.as_json(prompt, tier=gemini.SMART, timeout_ms=45000, default=None)
        if not isinstance(plan, dict):
            return "I couldn't obtain a structured plan from the configured model. Please try again or use the normal assistant."
        steps = plan.get("steps", [])
        searches = plan.get("searches", [])
        lines = [str(plan.get("summary") or "Plan prepared.").strip(), "", "Plan:"]
        for i, step in enumerate(steps[:8], 1): lines.append(f"{i}. {str(step)[:240]}")
        if execute:
            if not callable(getattr(player, "run_tool", None)):
                lines.append("\nResearch was not run: the tool execution bridge is unavailable.")
            else:
                completed = 0
                for item in searches[:4]:
                    if not isinstance(item, dict): continue
                    query = str(item.get("query", "")).strip()
                    if not query: continue
                    mode = str(item.get("mode", "search")).lower()
                    if mode not in {"search", "news", "research", "compare", "price"}: mode = "search"
                    result = player.run_tool("web_search", {"query": query, "mode": mode})
                    lines.extend([f"\nResearch: {query}", str(result)[:1800]])
                    completed += 1
                if not completed: lines.append("\nNo useful web searches were needed or proposed.")
        else:
            lines.append("\nPlanning only. Say to run the research step if you want me to gather web information.")
        result = "\n".join(lines)
        _log(player, "Agent Command Center prepared a plan.")
        return result[:7500]
    except Exception as exc:
        return f"Agent Command Center could not complete the request: {exc}"
