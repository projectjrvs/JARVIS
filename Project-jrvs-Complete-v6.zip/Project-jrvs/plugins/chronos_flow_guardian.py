"""
Chronos Flow Guardian: Deep-Work Context-Switch & Distraction Interceptor for Mark-LVI.
Monitors active window focus during timed study/coding sprints (zero Gemini API calls).
If distraction drift exceeds 12 seconds, summons the Tactical Mini-Drone, flashes a
crimson HUD warning banner, and calls the user back into flow state.
"""

from __future__ import annotations

import ctypes
import importlib
import platform
import shutil
import subprocess
import sys
import threading
import time

try:
    import tkinter as tk
except ImportError:
    tk = None


IS_WINDOWS = platform.system().lower() == "windows"

DEFAULT_DISTRACTIONS = (
    "youtube", "instagram", "reddit", "twitter", "x.com", "netflix",
    "prime video", "discord", "steam", "free fire", "minecraft", "sklauncher",
    "twitch", "facebook", "shorts", "reels",
)

_GUARD_LOCK = threading.Lock()
_GUARD_ACTIVE = False
_GUARD_STATE = {
    "active": False,
    "ends_at": 0.0,
    "goal": "Deep Focus",
    "drift_strikes": 0,
}


PLUGIN = {
    "name": "chronos_flow_guardian",
    "description": (
        "Deep-work focus shield and distraction interceptor. Tracks active window titles "
        "during a timed study or coding session (zero API calls) and intervenes with a "
        "crimson HUD banner, Mini-Drone patrol, and voice callout if you drift onto YouTube, "
        "social media, or games for >12 seconds. Use action='start' (with minutes and goal), "
        "action='status', or action='stop'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'start', 'status', or 'stop'.",
            },
            "minutes": {
                "type": "INTEGER",
                "description": "Duration of the focus lock in minutes (default 45).",
            },
            "goal": {
                "type": "STRING",
                "description": "What you are locking in on (e.g. 'Class 12 Integration' or 'GI-Orchestrator').",
            },
        },
        "required": ["action"],
    },
}


def _get_active_window_title() -> str:
    if IS_WINDOWS:
        try:
            user32 = ctypes.windll.user32
            hwnd = user32.GetForegroundWindow()
            length = user32.GetWindowTextLengthW(hwnd)
            if length > 0:
                buf = ctypes.create_unicode_buffer(length + 1)
                user32.GetWindowTextW(hwnd, buf, length + 1)
                return buf.value
        except Exception:
            return ""
        return ""

    # CachyOS / Linux (KDE Wayland kdotool -> X11 xdotool -> xprop)
    if shutil.which("kdotool"):
        try:
            wid = subprocess.check_output(["kdotool", "getactivewindow"], text=True, stderr=subprocess.DEVNULL).strip()
            if wid:
                return subprocess.check_output(["kdotool", "getwindowname", wid], text=True, stderr=subprocess.DEVNULL).strip()
        except Exception:
            pass

    if shutil.which("xdotool"):
        try:
            return subprocess.check_output(["xdotool", "getactivewindow", "getwindowname"], text=True, stderr=subprocess.DEVNULL).strip()
        except Exception:
            pass

    return ""


def _flash_crimson_callout(goal: str, bad_title: str) -> None:
    # Summon Mini-Drone into patrol if available
    try:
        drone_mod = sys.modules.get("plugins.holographic_mini_drone") or importlib.import_module("plugins.holographic_mini_drone")
        if hasattr(drone_mod, "run"):
            drone_mod.run({"action": "patrol"})
    except Exception:
        pass

    if tk is None:
        return

    try:
        root = tk.Tk()
        root.overrideredirect(True)
        root.attributes("-topmost", True)
        try:
            root.attributes("-alpha", 0.90)
        except Exception:
            pass

        sw = root.winfo_screenwidth()
        w, h = 680, 96
        x = (sw - w) // 2
        root.geometry(f"{w}x{h}+{x}+28")
        root.configure(bg="#140306")

        canvas = tk.Canvas(root, width=w, height=h, bg="#140306", highlightthickness=2, highlightbackground="#ff1a3c")
        canvas.pack(fill="both", expand=True)
        canvas.create_text(
            w // 2, 32,
            text="CHRONOS FLOW BREACH // RETURN TO OBJECTIVE",
            fill="#ff1a3c",
            font=("Consolas", 13, "bold"),
        )
        short_bad = (bad_title[:52] + "...") if len(bad_title) > 55 else bad_title
        canvas.create_text(
            w // 2, 66,
            text=f"LOCKED OBJECTIVE: {goal.upper()}  |  DRIFT DETECTED: {short_bad}",
            fill="#f1d5da",
            font=("Consolas", 9, "bold"),
        )
        root.after(3200, root.destroy)
        root.mainloop()
    except Exception:
        pass


def _guardian_worker(duration_min: int, goal: str, player=None) -> None:
    global _GUARD_ACTIVE, _GUARD_STATE

    ends_at = time.time() + duration_min * 60
    with _GUARD_LOCK:
        _GUARD_STATE = {
            "active": True,
            "ends_at": ends_at,
            "goal": goal,
            "drift_strikes": 0,
        }

    drift_started = 0.0
    last_callout = 0.0

    while _GUARD_ACTIVE and time.time() < ends_at:
        title = _get_active_window_title().lower()
        is_distracted = any(tag in title for tag in DEFAULT_DISTRACTIONS)

        if is_distracted:
            if drift_started == 0.0:
                drift_started = time.time()
            elif (time.time() - drift_started >= 12.0) and (time.time() - last_callout >= 25.0):
                last_callout = time.time()
                with _GUARD_LOCK:
                    _GUARD_STATE["drift_strikes"] += 1
                    strikes = _GUARD_STATE["drift_strikes"]

                threading.Thread(target=_flash_crimson_callout, args=(goal, title), daemon=True).start()
                msg = f"Focus breach #{strikes}, dude — get off '{title[:32]}' and lock back onto {goal}."
                if player:
                    try:
                        player.write_log(f"CHRONOS: {msg}")
                        if hasattr(player, "say") and callable(player.say):
                            player.say(msg)
                    except Exception:
                        pass
        else:
            drift_started = 0.0

        time.sleep(2.0)

    was_active = _GUARD_ACTIVE
    with _GUARD_LOCK:
        _GUARD_ACTIVE = False
        _GUARD_STATE["active"] = False
        strikes = _GUARD_STATE["drift_strikes"]

    if was_active and player:
        try:
            player.write_log(f"CHRONOS: Focus block complete for '{goal}' ({strikes} drift interception(s)).")
        except Exception:
            pass


def run(parameters: dict, player=None, session_memory=None) -> str:
    global _GUARD_ACTIVE

    action = str(parameters.get("action", "status")).strip().lower()
    minutes = max(5, min(int(parameters.get("minutes") or 45), 240))
    goal = str(parameters.get("goal") or "Deep Work").strip()

    if action in ("stop", "off", "cancel"):
        with _GUARD_LOCK:
            _GUARD_ACTIVE = False
            strikes = _GUARD_STATE.get("drift_strikes", 0)
        msg = f"Chronos Flow Guardian deactivated ({strikes} distraction interception(s) logged)."
        if player:
            try:
                player.write_log(f"CHRONOS: {msg}")
            except Exception:
                pass
        return msg

    if action == "status":
        with _GUARD_LOCK:
            st = dict(_GUARD_STATE)
        if not st.get("active"):
            return "Chronos Flow Guardian is currently standby."
        rem = max(0, int((st["ends_at"] - time.time()) // 60))
        return f"Focus Guard ACTIVE on '{st['goal']}' — {rem} min remaining | Drift strikes: {st['drift_strikes']}."

    with _GUARD_LOCK:
        _GUARD_ACTIVE = False
    time.sleep(0.05)

    with _GUARD_LOCK:
        _GUARD_ACTIVE = True

    threading.Thread(target=_guardian_worker, args=(minutes, goal, player), daemon=True).start()
    msg = f"Chronos Flow Guardian locked for {minutes} minutes on '{goal}'. Drift >12s triggers immediate interception."
    if player:
        try:
            player.write_log(f"CHRONOS: {msg}")
        except Exception:
            pass
    return msg