"""Natural-language access to Mark LVI's existing long-term memory store."""
from __future__ import annotations
import re
from memory import memory_manager as mm

PLUGIN = {
    "name": "memory_palace",
    "description": "Search and manage JARVIS long-term memory using the existing memory manager. Use to recall stored facts, save a project note, or remove a specific stored note. Never infer facts or silently overwrite unrelated memory.",
    "parameters": {"type": "OBJECT", "properties": {
        "action": {"type": "STRING", "description": "search, remember, or forget"},
        "query": {"type": "STRING", "description": "Search terms or the memory key"},
        "value": {"type": "STRING", "description": "Value to remember"},
        "category": {"type": "STRING", "description": "identity, preferences, projects, relationships, wishes, or notes"}
    }, "required": ["action"]},
    "tier": "core", "brief": "Search, save, or remove facts in JARVIS's existing long-term memory."
}

_VALID = {"identity", "preferences", "projects", "relationships", "wishes", "notes"}
def _key(text):
    text = re.sub(r"[^a-zA-Z0-9_ -]", "", str(text or "")).strip().lower()
    return re.sub(r"[\s-]+", "_", text)[:64]

def run(parameters: dict, player=None, session_memory=None) -> str:
    p = parameters or {}; action = str(p.get("action", "search")).lower().strip()
    query = str(p.get("query", "")).strip(); category = str(p.get("category", "notes")).lower().strip()
    if action == "search":
        return mm.search_memory(query, limit=12)
    if category not in _VALID: category = "notes"
    if action == "remember":
        key = _key(query); value = str(p.get("value", "")).strip()
        if not key or not value: return "To save a memory, provide both a short key in query and its value."
        if len(value) > 380: value = value[:379] + "…"
        return mm.remember(key, value, category)
    if action == "forget":
        key = _key(query)
        if not key: return "Provide the exact memory key to remove."
        # Deletion is deliberately explicit: require a clear exact key and category.
        return mm.forget(key, category)
    return "Choose action: search, remember, or forget."
