"""
Holographic Stark / Ultron Mini-Drone Companion (Swarm + Radial HUD Edition) for Mark-LVI.
Features:
  - Articulated 4-thruster tactical mini-drone with spinning rotors & sweeping laser optic
  - Orbiting telemetry swarm nodes reflecting live background plugin states (Ultron, Kernel Freeze, Reflex)
  - Right-click Stark Radial Command Ring (Ultron Override, Legion Sweep, Freeze Heavy Apps, Flight Modes)
  - Live microphone audio-reactive core + Drag-and-drop file ingestion into Mark-LVI
  - Zero Gemini API calls
"""

from __future__ import annotations

import importlib
import json
import math
import sys
import threading
import time
from pathlib import Path

try:
    import numpy as np
except ImportError:
    np = None

try:
    import sounddevice as sd
except ImportError:
    sd = None

try:
    import pyautogui
except Exception:
    pyautogui = None


ROOT_DIR = Path(__file__).resolve().parent.parent
MEMORY_DIR = ROOT_DIR / "memory"
ULTRON_STATE_PATH = MEMORY_DIR / "ultron_state.json"

_DRONE_LOCK = threading.Lock()
_DRONE_ACTIVE = False
_DRONE_WIDGET = None
_FLIGHT_MODE = "hover"  # 'hover', 'patrol', 'follow'
_AUDIO_LEVEL = 0.08


PLUGIN = {
    "name": "holographic_mini_drone",
    "description": (
        "Spawns or controls the floating Stark/Ultron tactical mini-drone companion with "
        "orbiting status swarm nodes, right-click Stark radial quick-action menu, audio-reactive "
        "optic core, drag-and-drop file ingestion, and automatic Ultron blood-red sync. "
        "Use action='spawn' (or 'on'), action='dismiss' (or 'off'), action='patrol', "
        "action='follow', or action='hover'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "'spawn', 'dismiss', 'patrol', 'follow', or 'hover'.",
            }
        },
        "required": [],
    },
}


def _is_ultron_active() -> bool:
    try:
        if ULTRON_STATE_PATH.exists():
            data = json.loads(ULTRON_STATE_PATH.read_text(encoding="utf-8"))
            return bool(data.get("active", False))
    except Exception:
        pass
    return False


def _get_swarm_telemetry() -> list[tuple[str, str]]:
    """Inspect live sibling plugins in memory to render orbiting status swarm nodes."""
    nodes: list[tuple[str, str]] = []
    if _is_ultron_active():
        nodes.append(("ULT", "#ff1a3c"))

    kernel_mod = sys.modules.get("plugins.ghost_in_the_kernel") or sys.modules.get("ghost_in_the_kernel")
    if kernel_mod is not None and getattr(kernel_mod, "_FROZEN_REGISTRY", None):
        nodes.append(("FRZ", "#38bdf8"))

    reflex_mod = sys.modules.get("plugins.neural_reflex_autoclicker") or sys.modules.get("neural_reflex_autoclicker")
    if reflex_mod is not None and getattr(reflex_mod, "_REFLEX_ACTIVE", False):
        nodes.append(("RFX", "#f59e0b"))

    chess_mod = sys.modules.get("plugins.live_chess_grandmaster_hud") or sys.modules.get("live_chess_grandmaster_hud")
    if chess_mod is not None and getattr(chess_mod, "_CHESS_ACTIVE", False):
        nodes.append(("GM", "#10b981"))

    return nodes


def _trigger_plugin_action(plugin_mod_name: str, params: dict, player=None) -> str:
    try:
        mod = sys.modules.get(f"plugins.{plugin_mod_name}") or importlib.import_module(f"plugins.{plugin_mod_name}")
        if hasattr(mod, "run"):
            return str(mod.run(params, player=player))
    except Exception as e:
        return f"Plugin '{plugin_mod_name}' unavailable: {e}"
    return "Executed."


def _audio_sampler_loop() -> None:
    global _AUDIO_LEVEL
    if sd is None or np is None:
        return

    def _cb(indata, frames, time_info, status):
        global _AUDIO_LEVEL
        try:
            rms = float(np.sqrt(np.mean(np.square(indata))))
            boosted = min(1.0, rms * 15.0)
            _AUDIO_LEVEL = 0.70 * _AUDIO_LEVEL + 0.30 * max(0.06, boosted)
        except Exception:
            pass

    try:
        with sd.InputStream(channels=1, samplerate=16000, blocksize=512, callback=_cb):
            while _DRONE_ACTIVE:
                time.sleep(0.08)
    except Exception:
        t0 = time.time()
        while _DRONE_ACTIVE:
            _AUDIO_LEVEL = 0.16 + 0.14 * math.sin((time.time() - t0) * 3.5)
            time.sleep(0.05)


def _launch_qt_drone(player=None) -> bool:
    global _DRONE_WIDGET

    try:
        from PyQt6.QtCore import Qt, QTimer, QPoint, QPointF, QRectF
        from PyQt6.QtGui import (
            QColor,
            QPainter,
            QPen,
            QBrush,
            QFont,
            QPolygonF,
            QRadialGradient,
            QLinearGradient,
        )
        from PyQt6.QtWidgets import QApplication, QWidget
    except Exception:
        return False

    app = QApplication.instance()
    if app is None:
        return False

    def _create():
        global _DRONE_WIDGET, _DRONE_ACTIVE

        if _DRONE_WIDGET is not None:
            try:
                _DRONE_WIDGET.show()
                _DRONE_WIDGET.raise_()
                return
            except Exception:
                _DRONE_WIDGET = None

        class TacticalMiniDrone(QWidget):
            def __init__(self):
                super().__init__(None)
                self.setWindowFlags(
                    Qt.WindowType.FramelessWindowHint
                    | Qt.WindowType.WindowStaysOnTopHint
                    | Qt.WindowType.Tool
                )
                self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
                self.setAcceptDrops(True)
                self.resize(250, 220)

                scr = app.primaryScreen()
                self._geo = scr.availableGeometry() if scr is not None else QRectF(0, 0, 1920, 1080).toRect()
                self._anchor_x = float(self._geo.right() - 275)
                self._anchor_y = float(self._geo.top() + 75)
                self.move(int(self._anchor_x), int(self._anchor_y))

                self._drag_offset: QPoint | None = None
                self._t0 = time.time()
                self._rotor_angle = 0.0
                self._orbit_angle = 0.0
                self._drop_flash = 0.0
                self._radial_open = False
                self._radial_buttons: list[tuple[QRectF, str, str]] = []

                self._timer = QTimer(self)
                self._timer.timeout.connect(self._step)
                self._timer.start(30)

            def _step(self):
                if not _DRONE_ACTIVE:
                    self._timer.stop()
                    self.close()
                    return

                now = time.time() - self._t0
                self._rotor_angle = (self._rotor_angle + 28.0 + _AUDIO_LEVEL * 25.0) % 360.0
                self._orbit_angle = (self._orbit_angle + 2.2) % 360.0
                if self._drop_flash > 0:
                    self._drop_flash = max(0.0, self._drop_flash - 0.06)

                if self._drag_offset is None and not self._radial_open:
                    mode = _FLIGHT_MODE
                    bob_y = math.sin(now * 3.1) * 7.0
                    bob_x = math.cos(now * 1.9) * 4.0

                    if mode == "patrol":
                        cx = self._geo.center().x() - self.width() / 2.0
                        cy = self._geo.top() + 95.0
                        rx = max(180.0, self._geo.width() * 0.35)
                        ry = max(70.0, self._geo.height() * 0.14)
                        tx = cx + math.sin(now * 0.55) * rx
                        ty = cy + math.sin(now * 1.10) * ry + bob_y
                        self._anchor_x += (tx - self._anchor_x) * 0.08
                        self._anchor_y += (ty - self._anchor_y) * 0.08
                    elif mode == "follow" and pyautogui is not None:
                        try:
                            mx, my = pyautogui.position()
                            tx = max(self._geo.left(), min(self._geo.right() - self.width(), mx + 36.0 + math.cos(now * 2.2) * 24.0))
                            ty = max(self._geo.top(), min(self._geo.bottom() - self.height(), my - 115.0 + bob_y))
                            self._anchor_x += (tx - self._anchor_x) * 0.10
                            self._anchor_y += (ty - self._anchor_y) * 0.10
                        except Exception:
                            pass
                    else:
                        self.move(int(self._anchor_x + bob_x), int(self._anchor_y + bob_y))
                        self.update()
                        return

                    self.move(int(self._anchor_x), int(self._anchor_y))

                self.update()

            def _handle_radial_click(self, pos_f: QPointF) -> bool:
                global _FLIGHT_MODE
                for rect, cmd_id, _label in self._radial_buttons:
                    if rect.contains(pos_f):
                        self._radial_open = False
                        self._drop_flash = 0.85
                        if cmd_id == "ultron":
                            act = "override" if _is_ultron_active() else "activate"
                            res = _trigger_plugin_action("ultron_mode", {"action": act}, player)
                        elif cmd_id == "sweep":
                            res = _trigger_plugin_action("ultron_mode", {"action": "scan"}, player)
                        elif cmd_id == "freeze":
                            res = _trigger_plugin_action("ghost_in_the_kernel", {"action": "freeze_except", "target": "python"}, player)
                        elif cmd_id == "flight":
                            order = ["hover", "patrol", "follow"]
                            _FLIGHT_MODE = order[(order.index(_FLIGHT_MODE) + 1) % len(order)]
                            res = f"Drone flight mode switched to {_FLIGHT_MODE.upper()}."
                        else:
                            res = ""
                        if player and res:
                            try:
                                player.write_log(f"DRONE RADIAL: {res}")
                            except Exception:
                                pass
                        return True
                return False

            def mousePressEvent(self, event):
                if event.button() == Qt.MouseButton.RightButton:
                    self._radial_open = not self._radial_open
                    self.update()
                    event.accept()
                    return

                if event.button() == Qt.MouseButton.LeftButton:
                    if self._radial_open and self._handle_radial_click(event.position()):
                        event.accept()
                        return
                    self._radial_open = False
                    self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                    event.accept()

            def mouseMoveEvent(self, event):
                if self._drag_offset is not None and (event.buttons() & Qt.MouseButton.LeftButton):
                    pos = event.globalPosition().toPoint() - self._drag_offset
                    self._anchor_x = float(pos.x())
                    self._anchor_y = float(pos.y())
                    self.move(pos)
                    event.accept()

            def mouseReleaseEvent(self, event):
                self._drag_offset = None

            def mouseDoubleClickEvent(self, event):
                self._drop_flash = 1.0
                res = _trigger_plugin_action("ultron_mode", {"action": "scan"}, player)
                if player:
                    try:
                        player.write_log(f"DRONE [RECON]: {res}")
                    except Exception:
                        pass

            def dragEnterEvent(self, event):
                if event.mimeData().hasUrls():
                    event.acceptProposedAction()

            def dropEvent(self, event):
                urls = event.mimeData().urls()
                paths = [u.toLocalFile() for u in urls if u.toLocalFile()]
                if paths:
                    self._drop_flash = 1.0
                    names = ", ".join(Path(p).name for p in paths)
                    if player:
                        try:
                            player.write_log(f"DRONE [PAYLOAD INGEST]: {names} -> {paths[0]}")
                        except Exception:
                            pass

            def paintEvent(self, event):
                p = QPainter(self)
                p.setRenderHint(QPainter.RenderHint.Antialiasing)

                ultron = _is_ultron_active()
                primary = QColor("#ff1a3c" if ultron else "#00f0ff")
                secondary = QColor("#8f0016" if ultron else "#007799")
                hull_dark = QColor("#16080b" if ultron else "#09131a")
                hull_mid = QColor("#2a0e14" if ultron else "#122633")
                if self._drop_flash > 0.15:
                    primary = QColor("#ffffff")

                cx, cy = self.width() / 2.0, self.height() / 2.0 - 6.0
                pulse = _AUDIO_LEVEL
                t = time.time() - self._t0

                # 1. Sweeping tactical scanner cone beneath drone
                scan_angle = math.sin(t * 2.4) * 26.0
                cone = QPolygonF([
                    QPointF(cx, cy + 16),
                    QPointF(cx - 42 + scan_angle, cy + 72),
                    QPointF(cx + 42 + scan_angle, cy + 72),
                ])
                cone_grad = QLinearGradient(cx, cy + 16, cx, cy + 72)
                c_top = QColor(primary)
                c_top.setAlpha(int(85 + 70 * pulse))
                c_bot = QColor(primary)
                c_bot.setAlpha(0)
                cone_grad.setColorAt(0.0, c_top)
                cone_grad.setColorAt(1.0, c_bot)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(cone_grad))
                p.drawPolygon(cone)

                # 2. Quad thruster struts + spinning rotor discs
                thrusters = [
                    (cx - 58, cy - 16),
                    (cx + 58, cy - 16),
                    (cx - 46, cy + 14),
                    (cx + 46, cy + 14),
                ]
                p.setPen(QPen(secondary, 2.2))
                for tx, ty in thrusters:
                    p.drawLine(QPointF(cx, cy), QPointF(tx, ty))
                    p.setBrush(QBrush(hull_dark))
                    p.setPen(QPen(primary, 1.5))
                    p.drawEllipse(QRectF(tx - 16, ty - 6, 32, 12))
                    p.setPen(QPen(QColor(255, 255, 255, 190), 1.8))
                    p.drawArc(
                        QRectF(tx - 15, ty - 5, 30, 10),
                        int(self._rotor_angle * 16),
                        120 * 16,
                    )
                    p.setPen(QPen(secondary, 2.2))

                # 3. Armored hexagonal drone fuselage
                body = QPolygonF([
                    QPointF(cx - 22, cy - 20),
                    QPointF(cx + 22, cy - 20),
                    QPointF(cx + 32, cy),
                    QPointF(cx + 20, cy + 20),
                    QPointF(cx - 20, cy + 20),
                    QPointF(cx - 32, cy),
                ])
                p.setPen(QPen(primary, 2.0))
                p.setBrush(QBrush(hull_mid))
                p.drawPolygon(body)

                inner = QPolygonF([
                    QPointF(cx - 15, cy - 13),
                    QPointF(cx + 15, cy - 13),
                    QPointF(cx + 21, cy),
                    QPointF(cx + 14, cy + 13),
                    QPointF(cx - 14, cy + 13),
                    QPointF(cx - 21, cy),
                ])
                p.setPen(QPen(secondary, 1.3))
                p.setBrush(QBrush(hull_dark))
                p.drawPolygon(inner)

                # 4. Audio-reactive central optic eye
                eye_r = 8.5 + pulse * 5.0
                eye_glow = QRadialGradient(cx, cy, eye_r * 2.1)
                eg1 = QColor(primary)
                eg1.setAlpha(220)
                eg2 = QColor(primary)
                eg2.setAlpha(0)
                eye_glow.setColorAt(0.0, eg1)
                eye_glow.setColorAt(1.0, eg2)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(eye_glow))
                p.drawEllipse(QRectF(cx - eye_r * 2.1, cy - eye_r * 2.1, eye_r * 4.2, eye_r * 4.2))
                p.setBrush(QBrush(primary))
                p.drawEllipse(QRectF(cx - eye_r * 0.65, cy - eye_r * 0.65, eye_r * 1.3, eye_r * 1.3))

                # 5. Orbiting Swarm Telemetry Nodes (live status of active background plugins)
                swarm = _get_swarm_telemetry()
                if swarm:
                    orbit_r = 74.0
                    p.setPen(QPen(QColor(primary.red(), primary.green(), primary.blue(), 65), 1.0, Qt.PenStyle.DashLine))
                    p.setBrush(Qt.BrushStyle.NoBrush)
                    p.drawEllipse(QRectF(cx - orbit_r, cy - orbit_r * 0.62, orbit_r * 2, orbit_r * 1.24))

                    for idx, (tag, hex_col) in enumerate(swarm):
                        ang = math.radians(self._orbit_angle + idx * (360.0 / len(swarm)))
                        nx = cx + math.cos(ang) * orbit_r
                        ny = cy + math.sin(ang) * (orbit_r * 0.62)
                        ncol = QColor(hex_col)
                        p.setPen(QPen(ncol, 1.4))
                        p.setBrush(QBrush(QColor("#0a0c10")))
                        p.drawEllipse(QRectF(nx - 12, ny - 9, 24, 18))
                        p.setFont(QFont("Consolas", 6, QFont.Weight.Bold))
                        p.drawText(QRectF(nx - 12, ny - 9, 24, 18), Qt.AlignmentFlag.AlignCenter, tag)

                # 6. Right-Click Stark Radial Quick-Action Ring
                self._radial_buttons.clear()
                if self._radial_open:
                    actions = [
                        ("ultron", "JARVIS" if ultron else "ULTRON", -90),
                        ("sweep", "SWEEP", 0),
                        ("freeze", "FREEZE", 90),
                        ("flight", _FLIGHT_MODE.upper(), 180),
                    ]
                    rad_dist = 82.0
                    for cmd_id, label, deg in actions:
                        rad = math.radians(deg)
                        bx = cx + math.cos(rad) * rad_dist
                        by = cy + math.sin(rad) * rad_dist
                        btn_rect = QRectF(bx - 28, by - 12, 56, 24)
                        self._radial_buttons.append((btn_rect, cmd_id, label))
                        p.setPen(QPen(primary, 1.6))
                        p.setBrush(QBrush(QColor(12, 14, 18, 235)))
                        p.drawRoundedRect(btn_rect, 6, 6)
                        p.setFont(QFont("Consolas", 7, QFont.Weight.Bold))
                        p.drawText(btn_rect, Qt.AlignmentFlag.AlignCenter, label)
                else:
                    p.setPen(primary)
                    p.setFont(QFont("Consolas", 7, QFont.Weight.Bold))
                    tag = f"{'ULTRON' if ultron else 'MK-LVI'} // {_FLIGHT_MODE.upper()}"
                    p.drawText(QRectF(cx - 65, cy + 23, 130, 14), Qt.AlignmentFlag.AlignCenter, tag)

        _DRONE_WIDGET = TacticalMiniDrone()
        _DRONE_WIDGET.show()

    try:
        QTimer.singleShot(0, _create)
        return True
    except Exception:
        return False


def run(parameters: dict, player=None, session_memory=None) -> str:
    global _DRONE_ACTIVE, _DRONE_WIDGET, _FLIGHT_MODE

    action = str(parameters.get("action", "spawn")).strip().lower()

    if action in ("dismiss", "off", "hide", "close", "recall"):
        with _DRONE_LOCK:
            _DRONE_ACTIVE = False
            w = _DRONE_WIDGET
            _DRONE_WIDGET = None
        if w is not None:
            try:
                from PyQt6.QtCore import QTimer
                QTimer.singleShot(0, w.close)
            except Exception:
                pass
        msg = "Tactical mini-drone recalled to dock."
        if player:
            try:
                player.write_log(f"DRONE: {msg}")
            except Exception:
                pass
        return msg

    if action in ("patrol", "follow", "hover"):
        _FLIGHT_MODE = action
    elif action in ("spawn", "on", "launch", "show"):
        _FLIGHT_MODE = "hover"

    with _DRONE_LOCK:
        already_on = _DRONE_ACTIVE
        _DRONE_ACTIVE = True

    if not already_on:
        threading.Thread(target=_audio_sampler_loop, daemon=True).start()

    launched = _launch_qt_drone(player=player)
    msg = (
        f"Tactical mini-drone online ({_FLIGHT_MODE.upper()} mode) — right-click for Stark radial menu, "
        f"double-click for instant recon sweep, or drop files onto it."
        if launched
        else "PyQt6 desktop context unavailable; drone in standby."
    )
    if player:
        try:
            player.write_log(f"DRONE: {msg}")
        except Exception:
            pass
    return msg