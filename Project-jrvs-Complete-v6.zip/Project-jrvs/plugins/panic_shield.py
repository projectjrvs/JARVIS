"""
plugins/panic_shield.py — Project jrvs
Panic Privacy Shield: instantly mutes microphone, stops webcam/screen streams,
minimizes desktop windows, and raises a sleek dark Privacy Veil (1-click dismiss)
on voice, global hotkey (Ctrl+Shift+P), or Orb menu trigger.
"""
from __future__ import annotations
import platform
import subprocess

PLUGIN = {
    "name": "panic_shield",
    "description": (
        "Engages the Panic Privacy Shield: immediately mutes the microphone, stops any live "
        "camera stream, minimizes desktop windows, and engages a dark privacy veil. "
        "Trigger on 'panic shield', 'engage panic privacy shield', 'privacy mode', or 'hide everything'."
    ),
    "parameters": {"type": "OBJECT", "properties": {}, "required": []},
    "tier": "core",
    "brief": "Instantly mute mic, stop camera feed, minimize windows, and show privacy veil.",
}

_VEIL_WIN = None


def _minimize_desktop() -> None:
    sys_name = platform.system().lower()
    if sys_name == "windows":
        try:
            import ctypes
            user32 = ctypes.windll.user32
            user32.keybd_event(0x5B, 0, 0, 0)  # VK_LWIN
            user32.keybd_event(0x4D, 0, 0, 0)  # 'M'
            user32.keybd_event(0x4D, 0, 2, 0)
            user32.keybd_event(0x5B, 0, 2, 0)
        except Exception:
            pass
    elif sys_name == "linux":
        try:
            subprocess.Popen(["wmctrl", "-k", "on"])
        except Exception:
            pass


def _show_privacy_veil() -> None:
    global _VEIL_WIN
    try:
        from PyQt6.QtCore import Qt
        from PyQt6.QtGui import QFont
        from PyQt6.QtWidgets import QApplication, QLabel, QPushButton, QVBoxLayout, QWidget

        app = QApplication.instance()
        if app is None:
            return

        if _VEIL_WIN is not None:
            try:
                _VEIL_WIN.close()
            except Exception:
                pass

        veil = QWidget()
        veil.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        veil.setStyleSheet("background-color: #020509; color: #ff1a3c;")

        lay = QVBoxLayout(veil)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.setSpacing(14)

        title = QLabel("⛨  PANIC PRIVACY SHIELD ENGAGED")
        title.setFont(QFont("Consolas", 18, QFont.Weight.Bold))
        title.setStyleSheet("color: #ff1a3c; background: transparent;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(title)

        sub = QLabel("Microphone Muted  ·  Live Feeds Terminated  ·  Desktop Minimized")
        sub.setFont(QFont("Consolas", 11))
        sub.setStyleSheet("color: #8faab8; background: transparent;")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(sub)

        btn = QPushButton("DISMISS PRIVACY VEIL")
        btn.setFont(QFont("Consolas", 11, QFont.Weight.Bold))
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setStyleSheet(
            "QPushButton { color: #ff1a3c; background: #0c0407; border: 1.5px solid #ff1a3c; "
            "border-radius: 5px; padding: 10px 22px; margin-top: 12px; }"
            "QPushButton:hover { background: #ff1a3c; color: #020509; }"
        )
        btn.clicked.connect(veil.close)
        lay.addWidget(btn, alignment=Qt.AlignmentFlag.AlignCenter)

        screen = app.primaryScreen()
        if screen:
            veil.setGeometry(screen.geometry())
        veil.showFullScreen()
        veil.raise_()
        veil.activateWindow()
        _VEIL_WIN = veil
    except Exception:
        pass


def run(parameters: dict, player=None, session_memory=None) -> str:
    if player is not None:
        try:
            player.muted = True
        except Exception:
            pass
        try:
            player.stop_camera_stream()
        except Exception:
            pass
        try:
            player.stop_video()
        except Exception:
            pass
        try:
            player.show_notch("⛨ PANIC PRIVACY SHIELD ACTIVE", "#ff1a3c", 4200)
        except Exception:
            pass
    _minimize_desktop()
    _show_privacy_veil()
    return "Panic Privacy Shield engaged: microphone muted, streams closed, desktop minimized."
