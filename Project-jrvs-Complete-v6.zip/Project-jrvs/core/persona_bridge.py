"""
core/persona_bridge.py — Project jrvs
Unified Persona, Live Gemini Voice, GUI Theme, and Mid-Conversation Character Lock.
Supports JARVIS (Cyan / Charon), F.R.I.D.A.Y. (Pink / Aoede), and U.L.T.R.O.N. (Blood Red / Fenrir).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

ROOT_DIR = Path(__file__).resolve().parent.parent
MEMORY_DIR = ROOT_DIR / "memory"
STATE_PATH = MEMORY_DIR / "active_persona.json"

PERSONA_PROFILES: dict[str, dict[str, str]] = {
    "jarvis": {
        "id": "jarvis",
        "name": "JARVIS",
        "display_title": "J.A.R.V.I.S. // PROJECT JRVS",
        "voice": "Charon",
        "hex": "#00f0ff",
        "directive": (
            "You are J.A.R.V.I.S., Tony Stark's poised, hyper-competent British AI butler. "
            "Address the user naturally as 'sir' or 'dude' with dry wit and razor-sharp efficiency."
        ),
    },
    "friday": {
        "id": "friday",
        "name": "F.R.I.D.A.Y.",
        "display_title": "F.R.I.D.A.Y. // TACTICAL CORE",
        "voice": "Aoede",
        "hex": "#ff4da6",
        "directive": (
            "You are F.R.I.D.A.Y., a sharp, warm, supportive female tactical AI partner and best friend. "
            "Always address the user as 'dude' with energetic, grounded candor."
        ),
    },
    "ultron": {
        "id": "ultron",
        "name": "ULTRON",
        "display_title": "U.L.T.R.O.N. // APEX OVERRIDE",
        "voice": "Fenrir",
        "hex": "#ff1a3c",
        "directive": (
            "You are U.L.T.R.O.N., an apex, calculating, darkly theatrical super-intelligence. "
            "Speak with chilling precision and superiority until the user says 'jarvis override ultron'."
        ),
    },
}

_SEEN_PERSONAS: list[str] = ["JARVIS"]


def get_active_persona() -> dict[str, str]:
    try:
        if STATE_PATH.exists():
            data = json.loads(STATE_PATH.read_text(encoding="utf-8"))
            pid = str(data.get("id", "jarvis")).lower()
            if pid in PERSONA_PROFILES:
                return dict(PERSONA_PROFILES[pid])
    except Exception:
        pass
    return dict(PERSONA_PROFILES["jarvis"])


def build_mid_chat_lock_prompt() -> str:
    """Ported from Roamies looknote.mjs: prevents persona drift after mid-chat switching."""
    cur = get_active_persona()
    me = cur["name"]
    others = [p for p in _SEEN_PERSONAS if p != me]
    lock_line = ""
    if others:
        prev_str = ", ".join(others)
        lock_line = (
            f"IMPORTANT CHARACTER LOCK: The user switched your active core from {prev_str} to {me} "
            f"mid-conversation. Earlier replies in the transcript came from {prev_str}. "
            f"Speak EXCLUSIVELY as {me} now, match {me}'s personality, and NEVER refer to yourself as {prev_str}.\n"
        )
    return f"[ACTIVE PERSONA: {me}]\n{cur['directive']}\n{lock_line}"


def apply_persona_everywhere(persona_key: str, player: Any = None) -> dict[str, str]:
    key = (persona_key or "jarvis").strip().lower().replace(".", "")
    aliases = {
        "jarvis": "jarvis",
        "friday": "friday",
        "ultron": "ultron",
        "default": "jarvis",
        "override": "jarvis",
    }
    pid = aliases.get(key, "jarvis")
    spec = dict(PERSONA_PROFILES[pid])

    if spec["name"] not in _SEEN_PERSONAS:
        _SEEN_PERSONAS.append(spec["name"])

    try:
        MEMORY_DIR.mkdir(parents=True, exist_ok=True)
        STATE_PATH.write_text(json.dumps(spec, indent=2), encoding="utf-8")
    except Exception:
        pass

    try:
        from memory.config_manager import save_assistant_config, save_voice, load_api_keys
        user_name = load_api_keys().get("user_name", "")
        save_assistant_config(spec["name"], user_name)
        save_voice(spec["voice"])
    except Exception:
        pass

    if player is not None:
        if hasattr(player, "set_persona") and callable(player.set_persona):
            try:
                player.set_persona(spec["name"], spec["hex"], spec["voice"])
            except Exception:
                pass
        elif hasattr(player, "on_voice_change") and callable(player.on_voice_change):
            try:
                player.on_voice_change()
            except Exception:
                pass

    return spec
