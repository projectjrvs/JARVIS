"""
core/global_shortcuts.py — Project jrvs
System-wide global hotkeys (works even when the HUD is hidden in Orb Mode or unfocused):
  - Ctrl + Shift + Space -> Cursor Ask Bar
  - Ctrl + Shift + C     -> Circle-to-Ask Screen Overlay
  - Ctrl + Shift + P     -> Panic Privacy Shield
Zero extra dependencies on Windows via ctypes GetAsyncKeyState; falls back to pynput on Linux/macOS if installed.
"""
from __future__ import annotations

import platform
import threading
import time
from typing import Callable, Optional

_OS = platform.system()


class GlobalShortcutListener:
    def __init__(
        self,
        on_ask_bar: Callable[[], None],
        on_circle_ask: Callable[[], None],
        on_panic_shield: Callable[[], None],
    ):
        self._on_ask = on_ask_bar
        self._on_circle = on_circle_ask
        self._on_panic = on_panic_shield
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._pynput_listener = None

    def start(self) -> str:
        if self._thread and self._thread.is_alive():
            return "global"
        self._stop.clear()

        if _OS == "Windows":
            self._thread = threading.Thread(
                target=self._win_poll_loop,
                daemon=True,
                name="jrvs-global-hotkeys",
            )
            self._thread.start()
            return "global"

        try:
            from pynput import keyboard  # type: ignore

            hotkeys = keyboard.GlobalHotKeys({
                "<ctrl>+<shift>+<space>": self._on_ask,
                "<ctrl>+<shift>+c": self._on_circle,
                "<ctrl>+<shift>+p": self._on_panic,
            })
            hotkeys.start()
            self._pynput_listener = hotkeys
            return "global"
        except Exception:
            return "window"

    def stop(self) -> None:
        self._stop.set()
        if self._pynput_listener is not None:
            try:
                self._pynput_listener.stop()
            except Exception:
                pass
            self._pynput_listener = None

    def _win_poll_loop(self) -> None:
        try:
            import ctypes
            user32 = ctypes.windll.user32
        except Exception:
            return

        VK_CONTROL = 0x11
        VK_SHIFT = 0x10
        VK_SPACE = 0x20
        VK_C = 0x43
        VK_P = 0x50

        prev_ask = False
        prev_circle = False
        prev_panic = False

        while not self._stop.wait(0.03):
            try:
                ctrl = bool(user32.GetAsyncKeyState(VK_CONTROL) & 0x8000)
                shift = bool(user32.GetAsyncKeyState(VK_SHIFT) & 0x8000)
                if not (ctrl and shift):
                    prev_ask = False
                    prev_circle = False
                    prev_panic = False
                    continue

                ask_now = bool(user32.GetAsyncKeyState(VK_SPACE) & 0x8000)
                circle_now = bool(user32.GetAsyncKeyState(VK_C) & 0x8000)
                panic_now = bool(user32.GetAsyncKeyState(VK_P) & 0x8000)

                if ask_now and not prev_ask:
                    self._on_ask()
                if circle_now and not prev_circle:
                    self._on_circle()
                if panic_now and not prev_panic:
                    self._on_panic()

                prev_ask = ask_now
                prev_circle = circle_now
                prev_panic = panic_now
            except Exception:
                time.sleep(0.1)
