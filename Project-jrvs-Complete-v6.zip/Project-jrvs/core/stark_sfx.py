"""
core/stark_sfx.py — Project jrvs
In-memory procedural Stark HUD micro-sound effects (ported from Roamies sfx.js).
Zero external WAV/MP3 files; uses numpy + sounddevice if available, else silent fallback.
"""
from __future__ import annotations

import threading


def play_sfx(kind: str = "ping") -> None:
    def _worker():
        try:
            import numpy as np
            import sounddevice as sd

            sr = 22050
            tones = {
                "ping": (880.0, 1320.0, 0.08),
                "blip": (660.0, 990.0, 0.06),
                "scan": (440.0, 880.0, 0.14),
                "done": (523.25, 1046.5, 0.16),
                "alert": (740.0, 420.0, 0.22),
            }
            f0, f1, dur = tones.get(kind, tones["ping"])
            n = int(sr * dur)
            t = np.linspace(0, dur, n, endpoint=False)
            freq = np.linspace(f0, f1, n)
            env = np.exp(-t * 18.0)
            wave = (0.12 * np.sin(2.0 * np.pi * freq * t) * env).astype(np.float32)
            sd.play(wave, sr, blocking=False)
        except Exception:
            pass

    threading.Thread(target=_worker, daemon=True).start()
