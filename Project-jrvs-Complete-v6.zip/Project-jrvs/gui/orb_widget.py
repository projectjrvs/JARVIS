"""
gui/orb_widget.py — Project jrvs
Zero-glitch Roamies-style 3D LED Dot Sphere Orb + Exclusive Orb/HUD Mode Controller.
Mutually exclusive:
  - Orb Mode ON  -> Main HUD window is completely hidden; ONLY the floating 3D LED Orb is visible.
  - Orb Mode OFF -> Floating Orb is completely hidden; ONLY the full HUD window is visible.
"""
from __future__ import annotations

import math
import time
from typing import Callable, Optional

from PyQt6.QtCore import QPoint, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QMouseEvent, QPainter, QPaintEvent, QPen, QRadialGradient
from PyQt6.QtWidgets import QMenu, QWidget


def _generate_golden_sphere(n: int = 420) -> list[tuple[float, float, float]]:
    pts: list[tuple[float, float, float]] = []
    golden_angle = 2.399963229728653
    for i in range(n):
        y = 1.0 - (2.0 * (i + 0.5)) / n
        r = math.sqrt(max(0.0, 1.0 - y * y))
        a = i * golden_angle
        pts.append((math.cos(a) * r, y, math.sin(a) * r))
    return pts


class FloatingOrbWidget(QWidget):
    """Frameless, always-on-top, draggable 3D LED Particle Orb."""

    expand_requested = pyqtSignal()
    persona_requested = pyqtSignal(str)
    command_requested = pyqtSignal(str)

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        self.setFixedSize(128, 128)
        self.setCursor(Qt.CursorShape.OpenHandCursor)

        self._dots = _generate_golden_sphere(420)
        self._spin = 0.0
        self._last_ts = time.perf_counter()
        self._audio_level = 0.12
        self._state = "idle"
        self._persona_name = "JARVIS"
        self._primary = QColor("#00f0ff")
        self._glow = QColor("#66f7ff")
        self._core = QColor("#ffffff")

        self._drag_offset: Optional[QPoint] = None
        self._positioned = False

        self._timer = QTimer(self)
        self._timer.setTimerType(Qt.TimerType.PreciseTimer)
        self._timer.timeout.connect(self._tick)

    def showEvent(self, event):
        super().showEvent(event)
        if not self._positioned:
            screen = self.screen()
            if screen:
                geo = screen.availableGeometry()
                self.move(geo.right() - self.width() - 28, geo.bottom() - self.height() - 28)
            self._positioned = True
        self._last_ts = time.perf_counter()
        if not self._timer.isActive():
            self._timer.start(16)

    def hideEvent(self, event):
        super().hideEvent(event)
        if self._timer.isActive():
            self._timer.stop()

    def set_theme(self, hex_color: str, persona_name: str = "JARVIS") -> None:
        self._persona_name = persona_name.upper()
        c = QColor(hex_color)
        if c.isValid():
            self._primary = c
            self._glow = c.lighter(135)
        self.update()

    def set_audio_level(self, level: float) -> None:
        self._audio_level = max(0.0, min(1.0, float(level)))

    def set_state(self, state: str) -> None:
        s = (state or "idle").lower()
        if "listen" in s:
            self._state = "listen"
        elif "think" in s or "work" in s or "tool" in s:
            self._state = "think"
        elif "speak" in s or "talk" in s:
            self._state = "talk"
        else:
            self._state = "idle"

    def _tick(self) -> None:
        now = time.perf_counter()
        dt = min(0.05, max(0.001, now - self._last_ts))
        self._last_ts = now

        rate = 1.9 if self._state == "think" else (0.85 if self._state == "talk" else 0.36)
        self._spin = (self._spin + rate * dt) % (math.pi * 2.0)
        if self._state == "idle":
            self._audio_level = max(0.10, self._audio_level * 0.92)
        self.update()

    def paintEvent(self, event: QPaintEvent) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        w, h = self.width(), self.height()
        cx, cy = w * 0.5, h * 0.5 - 4.0
        t = time.perf_counter()

        v = self._audio_level
        if self._state == "talk":
            v = max(v, 0.38 + 0.32 * abs(math.sin(t * 10.5)))
        elif self._state == "listen":
            v = max(v, 0.28 + 0.18 * abs(math.sin(t * 4.2)))

        base_rad = 39.0 * (1.0 + 0.04 * math.sin(t * 1.6) + v * 0.10)

        bg_grad = QRadialGradient(cx, cy, base_rad + 14.0)
        bg_grad.setColorAt(0.0, QColor(2, 8, 14, 238))
        bg_grad.setColorAt(0.72, QColor(2, 8, 14, 198))
        bg_grad.setColorAt(1.0, QColor(2, 8, 14, 0))
        painter.setBrush(bg_grad)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QRectF(cx - base_rad - 14, cy - base_rad - 14, (base_rad + 14) * 2, (base_rad + 14) * 2))

        ring_col = QColor(self._primary)
        ring_col.setAlpha(75)
        painter.setPen(QPen(ring_col, 1.2))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(QRectF(cx - base_rad - 5, cy - base_rad - 5, (base_rad + 5) * 2, (base_rad + 5) * 2))

        if self._state == "think":
            painter.setPen(QPen(self._glow, 2.2))
            start_deg = int((t * 240) % 360) * 16
            painter.drawArc(
                QRectF(cx - base_rad - 5, cy - base_rad - 5, (base_rad + 5) * 2, (base_rad + 5) * 2),
                start_deg,
                75 * 16,
            )

        cyw, syw = math.cos(self._spin), math.sin(self._spin)
        pitch = -0.38
        cp, sp = math.cos(pitch), math.sin(pitch)
        wavy = v if self._state in ("talk", "listen") else 0.12

        painter.setPen(Qt.PenStyle.NoPen)
        for px0, py0, pz0 in self._dots:
            band = (
                0.5 * math.sin(py0 * 7.0 - t * (9.0 if self._state == "talk" else 3.0))
                + 0.5 * math.sin(math.atan2(pz0, px0) * 5.0 + t * 4.0)
            )
            r = base_rad * (1.0 + wavy * 0.16 * band)

            x1 = px0 * cyw + pz0 * syw
            z1 = -px0 * syw + pz0 * cyw
            y2 = py0 * cp - z1 * sp
            z2 = py0 * sp + z1 * cp

            sx = cx + x1 * r
            sy = cy + y2 * r

            if z2 < -0.15:
                dot_col = QColor(self._primary)
                dot_col.setAlpha(48)
                dot_size = 1.4
            else:
                lam = max(0.0, min(1.0, -x1 * 0.45 - y2 * 0.6 + z2 * 0.66))
                alpha = int(min(255, 95 + lam * 135 + max(0.0, band) * wavy * 90))
                dot_col = QColor(self._glow if z2 > 0.65 else self._primary)
                dot_col.setAlpha(alpha)
                dot_size = 2.2 if z2 > 0.55 else 1.7

            painter.setBrush(dot_col)
            painter.drawEllipse(QRectF(sx - dot_size * 0.5, sy - dot_size * 0.5, dot_size, dot_size))

        core_r = 5.5 + v * 5.0
        core_grad = QRadialGradient(cx, cy, core_r * 2.2)
        c_inner = QColor(self._core)
        c_inner.setAlpha(235)
        c_mid = QColor(self._glow)
        c_mid.setAlpha(150)
        c_outer = QColor(self._primary)
        c_outer.setAlpha(0)
        core_grad.setColorAt(0.0, c_inner)
        core_grad.setColorAt(0.45, c_mid)
        core_grad.setColorAt(1.0, c_outer)
        painter.setBrush(core_grad)
        painter.drawEllipse(QRectF(cx - core_r * 2.2, cy - core_r * 2.2, core_r * 4.4, core_r * 4.4))

        tag_col = QColor(self._primary)
        tag_col.setAlpha(190)
        painter.setPen(tag_col)
        painter.setFont(QFont("Consolas", 7, QFont.Weight.Bold))
        painter.drawText(QRectF(0, h - 18, w, 16), Qt.AlignmentFlag.AlignCenter, f"{self._persona_name} · jrvs")

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            event.accept()
        elif event.button() == Qt.MouseButton.RightButton:
            self._open_context_menu(event.globalPosition().toPoint())
            event.accept()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        if self._drag_offset is not None and (event.buttons() & Qt.MouseButton.LeftButton):
            self.move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_offset = None
            self.setCursor(Qt.CursorShape.OpenHandCursor)
            event.accept()

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self.expand_requested.emit()
            event.accept()

    def _open_context_menu(self, global_pos: QPoint) -> None:
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu { background-color: #050a10; color: #dff8ff; border: 1px solid #00f0ff; "
            "font-family: Consolas; font-size: 11px; padding: 4px; }"
            "QMenu::item:selected { background-color: #0b2636; color: #00f0ff; }"
        )
        act_expand = menu.addAction("◈ Expand Full HUD (Orb Mode OFF)")
        menu.addSeparator()
        act_jarvis = menu.addAction("● Switch to J.A.R.V.I.S. (Cyan)")
        act_friday = menu.addAction("● Switch to F.R.I.D.A.Y. (Pink)")
        act_ultron = menu.addAction("● Engage U.L.T.R.O.N. (Blood Red)")
        menu.addSeparator()
        act_circle = menu.addAction("◎ Circle-to-Ask Screen")
        act_panic = menu.addAction("⛨ Panic Privacy Shield")

        chosen = menu.exec(global_pos)
        if chosen == act_expand:
            self.expand_requested.emit()
        elif chosen == act_jarvis:
            self.persona_requested.emit("jarvis")
        elif chosen == act_friday:
            self.persona_requested.emit("friday")
        elif chosen == act_ultron:
            self.persona_requested.emit("ultron")
        elif chosen == act_circle:
            self.command_requested.emit("circle_to_ask")
        elif chosen == act_panic:
            self.command_requested.emit("panic_shield")


class OrbModeController:
    """Strict mutual exclusion between Full HUD and Orb Mode."""

    def __init__(
        self,
        main_window: QWidget,
        on_persona: Optional[Callable[[str], None]] = None,
        on_command: Optional[Callable[[str], None]] = None,
    ):
        self.main_window = main_window
        self.orb = FloatingOrbWidget()
        self.orb_active = False
        self.orb.expand_requested.connect(self.disable_orb_mode)
        if on_persona:
            self.orb.persona_requested.connect(on_persona)
        if on_command:
            self.orb.command_requested.connect(on_command)

    def set_orb_mode(self, enabled: bool) -> bool:
        if enabled:
            self.enable_orb_mode()
        else:
            self.disable_orb_mode()
        return self.orb_active

    def enable_orb_mode(self) -> None:
        self.orb_active = True
        try:
            self.main_window.hide()
        except Exception:
            pass
        self.orb.show()
        self.orb.raise_()

    def disable_orb_mode(self) -> None:
        self.orb_active = False
        try:
            self.orb.hide()
        except Exception:
            pass
        self.main_window.showNormal()
        self.main_window.raise_()
        self.main_window.activateWindow()

    def sync_theme(self, hex_color: str, persona_name: str) -> None:
        self.orb.set_theme(hex_color, persona_name)

    def sync_audio(self, level: float) -> None:
        if self.orb_active:
            self.orb.set_audio_level(level)

    def sync_state(self, state: str) -> None:
        self.orb.set_state(state)
