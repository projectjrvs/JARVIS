"""
gui/circle_to_ask.py — Project jrvs
Full-screen translucent Circle-to-Ask / Region-Snipping overlay.
Lets the user drag a selection circle or box anywhere on screen, enter a question
(or leave blank for instant visual analysis), saves the cropped region to memory/circle_capture.png,
and sends it straight into the active assistant session.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from PyQt6.QtCore import QPoint, QRect, Qt, pyqtSignal
from PyQt6.QtGui import (
    QColor,
    QFont,
    QGuiApplication,
    QKeyEvent,
    QMouseEvent,
    QPainter,
    QPaintEvent,
    QPen,
    QPixmap,
)
from PyQt6.QtWidgets import QHBoxLayout, QLabel, QLineEdit, QPushButton, QWidget

ROOT_DIR = Path(__file__).resolve().parent.parent
CAPTURE_PATH = ROOT_DIR / "memory" / "circle_capture.png"


class CircleToAskOverlay(QWidget):
    """Frameless fullscreen screen-grabber + floating prompt bar."""

    captured = pyqtSignal(str, str)  # (saved_image_path, user_question)

    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)
        self.setCursor(Qt.CursorShape.CrossCursor)

        self._screen_pm: Optional[QPixmap] = None
        self._start: Optional[QPoint] = None
        self._end: Optional[QPoint] = None
        self._dragging = False
        self._accent = QColor("#00f0ff")

        # Floating mini prompt bar shown after drag finishes
        self._bar = QWidget(self)
        self._bar.setStyleSheet(
            "QWidget { background: rgba(5, 13, 21, 245); border: 1px solid #00f0ff; border-radius: 6px; }"
        )
        self._bar.hide()

        h = QHBoxLayout(self._bar)
        h.setContentsMargins(10, 6, 8, 6)
        h.setSpacing(6)

        lbl = QLabel("◎ ASK:")
        lbl.setFont(QFont("Consolas", 10, QFont.Weight.Bold))
        lbl.setStyleSheet("color: #00f0ff; border: none; background: transparent;")
        h.addWidget(lbl)

        self._input = QLineEdit()
        self._input.setPlaceholderText("Ask about selected area (Enter for instant analysis)...")
        self._input.setFont(QFont("Consolas", 10))
        self._input.setMinimumWidth(310)
        self._input.setStyleSheet(
            "QLineEdit { color: #e8fbff; background: transparent; border: none; }"
        )
        self._input.returnPressed.connect(self._submit)
        h.addWidget(self._input)

        go_btn = QPushButton("ANALYZE")
        go_btn.setFont(QFont("Consolas", 9, QFont.Weight.Bold))
        go_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        go_btn.setStyleSheet(
            "QPushButton { color: #02080d; background: #00f0ff; border: none; "
            "border-radius: 4px; padding: 5px 10px; }"
            "QPushButton:hover { background: #66f7ff; }"
        )
        go_btn.clicked.connect(self._submit)
        h.addWidget(go_btn)

        esc_btn = QPushButton("✕")
        esc_btn.setFont(QFont("Consolas", 10, QFont.Weight.Bold))
        esc_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        esc_btn.setStyleSheet(
            "QPushButton { color: #9bc4d4; background: transparent; border: none; padding: 4px 6px; }"
            "QPushButton:hover { color: #ff4da6; }"
        )
        esc_btn.clicked.connect(self.close)
        h.addWidget(esc_btn)

    def launch(self, accent_hex: str = "#00f0ff") -> None:
        c = QColor(accent_hex)
        if c.isValid():
            self._accent = c
        self._start = None
        self._end = None
        self._dragging = False
        self._bar.hide()
        self._input.clear()

        screen = QGuiApplication.primaryScreen()
        if screen:
            self._screen_pm = screen.grabWindow(0)
            self.setGeometry(screen.geometry())
        self.showFullScreen()
        self.raise_()
        self.activateWindow()
        self.update()

    def _selection_rect(self) -> QRect:
        if not self._start or not self._end:
            return QRect()
        return QRect(self._start, self._end).normalized()

    def paintEvent(self, event: QPaintEvent) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        if self._screen_pm and not self._screen_pm.isNull():
            p.drawPixmap(0, 0, self._screen_pm)

        # Dark translucent veil
        p.fillRect(self.rect(), QColor(2, 8, 14, 155))

        # Top instruction banner
        p.setPen(self._accent)
        p.setFont(QFont("Consolas", 11, QFont.Weight.Bold))
        p.drawText(
            QRect(0, 18, self.width(), 28),
            Qt.AlignmentFlag.AlignCenter,
            "◎ CIRCLE-TO-ASK  ·  Drag across anything on screen  ·  ESC to cancel",
        )

        rect = self._selection_rect()
        if rect.width() > 6 and rect.height() > 6 and self._screen_pm:
            # Reveal crisp un-dimmed region inside selection
            p.drawPixmap(rect, self._screen_pm, rect)
            pen = QPen(self._accent, 2.2)
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(rect, 10, 10)
            # Also draw subtle inscribed circle guide
            dash_pen = QPen(self._accent, 1.1, Qt.PenStyle.DashLine)
            p.setPen(dash_pen)
            p.drawEllipse(rect)

    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._start = event.pos()
            self._end = event.pos()
            self._dragging = True
            self._bar.hide()
            self.update()
        elif event.button() == Qt.MouseButton.RightButton:
            self.close()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        if self._dragging:
            self._end = event.pos()
            self.update()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton and self._dragging:
            self._end = event.pos()
            self._dragging = False
            rect = self._selection_rect()
            if rect.width() < 12 or rect.height() < 12:
                # Single click -> capture a 420x420 region around cursor
                cx, cy = event.pos().x(), event.pos().y()
                self._start = QPoint(max(0, cx - 210), max(0, cy - 210))
                self._end = QPoint(min(self.width(), cx + 210), min(self.height(), cy + 210))
                rect = self._selection_rect()
            self.update()
            self._bar.adjustSize()
            bx = max(16, min(self.width() - self._bar.width() - 16, rect.center().x() - self._bar.width() // 2))
            by = rect.bottom() + 12
            if by + self._bar.height() > self.height() - 16:
                by = max(16, rect.top() - self._bar.height() - 12)
            self._bar.move(bx, by)
            self._bar.show()
            self._input.setFocus()

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() == Qt.Key.Key_Escape:
            self.close()
        else:
            super().keyPressEvent(event)

    def _submit(self) -> None:
        rect = self._selection_rect()
        if not self._screen_pm or rect.width() < 4 or rect.height() < 4:
            self.close()
            return
        CAPTURE_PATH.parent.mkdir(parents=True, exist_ok=True)
        cropped = self._screen_pm.copy(rect)
        cropped.save(str(CAPTURE_PATH), "PNG")
        question = self._input.text().strip() or "Analyze what is inside this circled screen region in detail."
        self.close()
        self.captured.emit(str(CAPTURE_PATH), question)
