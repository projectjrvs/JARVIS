"""
gui/cursor_ask_bar.py — Project jrvs
Cursor-side quick-type command pill (ported from Roamies ask-bar.js).
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QCursor
from PyQt6.QtWidgets import QApplication, QHBoxLayout, QLineEdit, QWidget


class CursorAskBar(QWidget):
    submitted = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setFixedSize(340, 42)
        self.setStyleSheet(
            "background-color: #050b12; border: 1.5px solid #00f0ff; border-radius: 10px;"
        )
        lay = QHBoxLayout(self)
        lay.setContentsMargins(10, 4, 10, 4)
        self._input = QLineEdit(self)
        self._input.setPlaceholderText("Ask Project jrvs anything... (Enter to send, Esc to close)")
        self._input.setStyleSheet(
            "border: none; background: transparent; color: #e8fbff; font-family: Consolas; font-size: 11px;"
        )
        self._input.returnPressed.connect(self._on_submit)
        lay.addWidget(self._input)

    def popup_at_cursor(self) -> None:
        pos = QCursor.pos()
        x, y = pos.x() + 18, pos.y() + 12
        screen = QApplication.primaryScreen()
        if screen:
            geo = screen.availableGeometry()
            if x + self.width() > geo.right():
                x = pos.x() - self.width() - 10
            if y + self.height() > geo.bottom():
                y = pos.y() - self.height() - 10
        self.move(max(0, x), max(0, y))
        self.show()
        self.raise_()
        self.activateWindow()
        self._input.setFocus()
        self._input.selectAll()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.hide()
            return
        super().keyPressEvent(event)

    def _on_submit(self) -> None:
        txt = self._input.text().strip()
        self._input.clear()
        self.hide()
        if txt:
            self.submitted.emit(txt)
