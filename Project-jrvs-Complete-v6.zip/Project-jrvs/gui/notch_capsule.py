"""
gui/notch_capsule.py — Project jrvs
Top-edge Liquid Dynamic Island capsule (ported from Roamies notch.js).
Displays a compact glowing capsule with mini LED sphere & live audio bars when active.
"""
from __future__ import annotations

import math
import time
from PyQt6.QtCore import QRectF, Qt, QTimer
from PyQt6.QtGui import QColor, QFont, QPainter, QPaintEvent, QPen
from PyQt6.QtWidgets import QApplication, QWidget


class LiquidNotchCapsule(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
            | Qt.WindowType.WindowTransparentForInput
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self._accent = QColor("#00f0ff")
        self._text = "PROJECT JRVS // STANDBY"
        self._active = False
        self._level = 0.15
        self._w = 240
        self._h = 34
        self.resize(self._w, self._h)

        self._tmr = QTimer(self)
        self._tmr.timeout.connect(self._tick)

    def show_status(self, text: str, hex_color: str = "", auto_hide_ms: int = 3800) -> None:
        if hex_color:
            c = QColor(hex_color)
            if c.isValid():
                self._accent = c
        self._text = (text or "PROJECT JRVS")[:46]
        self._active = True
        screen = QApplication.primaryScreen()
        if screen:
            geo = screen.availableGeometry()
            self.move(geo.center().x() - self._w // 2, geo.top() + 4)
        self.show()
        self.raise_()
        if not self._tmr.isActive():
            self._tmr.start(30)
        if auto_hide_ms > 0:
            QTimer.singleShot(auto_hide_ms, self.dismiss)

    def dismiss(self) -> None:
        self._active = False
        self._tmr.stop()
        self.hide()

    def _tick(self) -> None:
        self._level = 0.25 + 0.65 * abs(math.sin(time.perf_counter() * 9.0))
        self.update()

    def paintEvent(self, event: QPaintEvent) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(1, 1, self.width() - 2, self.height() - 2)
        p.setBrush(QColor(3, 9, 15, 238))
        p.setPen(QPen(self._accent, 1.3))
        p.drawRoundedRect(rect, 16, 16)

        # Mini animated waveform bars on left
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(self._accent)
        t = time.perf_counter()
        for i in range(5):
            bh = 5.0 + 13.0 * abs(math.sin(t * 8.5 + i * 0.9)) * self._level
            bx = 16 + i * 5
            by = (self.height() - bh) * 0.5
            p.drawRoundedRect(QRectF(bx, by, 2.8, bh), 1.4, 1.4)

        p.setPen(QColor("#e6fbff"))
        p.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
        p.drawText(QRectF(48, 0, self.width() - 56, self.height()), Qt.AlignmentFlag.AlignVCenter, self._text)
