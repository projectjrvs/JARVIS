# ⚙️ Project-jrvs (Mark LVII+ Extended Edition)
### Cross-Platform Autonomous AI Command Center — Built on Mark LVII by FatihMakes

> **Forked & Extended from [FatihMakes/Mark-LVII](https://github.com/FatihMakes/Mark-LVII)** — combining Mark LVII's background task engine, routine scheduler, 3-D reactor core, holographic avatar, and local/hybrid LLM pipeline with **Project-jrvs** custom HUD overlays, multi-persona voice/theme switching, Circle-to-Ask screen intelligence, and 27 autonomous plugins.

A real-time voice & vision AI assistant that can hear, see, speak, and control your computer across **Windows**, **macOS**, and **Linux** — powered by the **Gemini Live API** for native low-latency audio streaming or your own local **Ollama / Whisper / Piper** stack.

---

## ✨ What's New in Project-jrvs

Built directly on top of the **Mark LVII** architecture with zero external server dependencies:

### ◉ Exclusive Floating 3-D LED Orb Mode
* **Mutual-Exclusion Display:** Switch between the full Command-Center HUD and a frameless, always-on-top, draggable **420-particle 3D LED Sphere Orb** (`gui/orb_widget.py` + `plugins/orb_mode.py`).
* **Audio & State Reactive:** Pulses in real time to your voice and assistant state (`IDLE`, `LISTENING`, `THINKING`, `SPEAKING`), syncing color themes dynamically.
* **Quick Controls:** Click **`◉ ORB`** in the top bar, say *"orb mode"*, or double-click / right-click the floating orb to restore the full HUD.

### 🎭 Live Multi-Persona Cores (Voice + Theme + Character Lock)
Switch active AI identity, HUD/Orb palette, Gemini Live voice, and system prompt character lock mid-session (`core/persona_bridge.py` + `plugins/friday_mode.py` + `plugins/ultron_mode.py`):
* **J.A.R.V.I.S.** — Cyan HUD (`#00f0ff`) · `Charon` voice · British tactical butler.
* **F.R.I.D.A.Y.** — Pink HUD (`#ff4da6`) · `Aoede` voice · Supportive, witty partner persona.
* **U.L.T.R.O.N.** — Blood Red HUD (`#ff1a3c`) · `Fenrir` voice · Apex override mode with reactor lockdown sequence (`ultron_takeover.py`) and clean reversion via *"Jarvis override Ultron"*.

### ◎ Circle-to-Ask & Cursor Ask Bar (System-Wide Global Hotkeys)
Powered by `core/global_shortcuts.py`, working system-wide even when minimized to Orb Mode or inside another full-screen application:
* **`Ctrl + Shift + C` — Circle-to-Ask (`gui/circle_to_ask.py`):** Freezes and dims the screen so you can drag a selection box/circle around any code error, chart, text, or chess position and ask a question inline.
* **`Ctrl + Shift + Space` — Cursor Ask Bar (`gui/cursor_ask_bar.py`):** Pops up a sleek command input pill right next to your mouse cursor.
* **`Ctrl + Shift + P` — Panic Privacy Shield (`plugins/panic_shield.py`):** Instantly mutes the microphone, kills live webcam/video feeds, minimizes desktop windows, flashes a crimson Liquid Notch alert, and locks the display behind a dismissible dark privacy veil.

### 💊 Top-Edge Liquid Notch Capsule & Custom Arsenal
* **Liquid Notch (`gui/notch_capsule.py`):** Dynamic Island-style top-edge capsule displaying live waveform bars and status pulses during `PROCESSING`, `SPEAKING`, persona switches, and security alerts.
* **27 Plug-and-Play Skills (`plugins/`):** Includes Arkham Detective Vision visor, Tactical Mini-Drone companion, Holographic LAN QR Portal Drop, Live Chess Grandmaster HUD (local Stockfish), Kinetic Gesture Air-Mouse, Chronos Flow Guardian focus lock, God-Mode Architect self-plugin builder, Symbiotic Self-Mutator live hot-reloader, Visual Explainer HUD diagrams, and Biometric Voiceprint Lock.

---

## 🚀 Capabilities

### Project-jrvs & Mark LVII Core Features
| Feature | Description |
|---|---|
| ◉ **Floating 3D LED Orb Mode** | Exclusive minimized 420-dot 3D sphere mode (`Ctrl` / Header **`◉ ORB`** / *"orb mode"*) with right-click quick actions |
| 🎭 **Multi-Persona Cores** | Instant live switch between **J.A.R.V.I.S.** (Cyan / Charon), **F.R.I.D.A.Y.** (Pink / Aoede), and **U.L.T.R.O.N.** (Red / Fenrir) |
| ◎ **Circle-to-Ask Overlay** | Drag across anything on screen (**`Ctrl + Shift + C`**) to crop, preview, and analyze immediately |
| ⌘ **Global Cursor Ask Bar** | Summon a cursor-side command pill anywhere on your OS (**`Ctrl + Shift + Space`**) |
| ⛨ **Panic Privacy Shield** | One-key (**`Ctrl + Shift + P`**) instant mic mute, camera kill, desktop minimize, and dark privacy veil |
| 💊 **Liquid Notch Capsule** | Top-edge status pill with real-time animated audio bars |
| 🧵 **Background Tasks** | Long work runs beside the conversation — checkpointed every step, resumed after a restart, stopped, finished early or re-steered by voice |
| 🔬 **Deep Research** | Plans the questions, reads sources in full, checks every quote against the saved page in code, and writes a cited report in your language |
| 🧑‍🔬 **Agents as Files** | An agent is a Markdown file in `agents/` — its tools, time budget and instructions. Adding one is one file |
| 🗓️ **Routines & Quiet Hours** | One engine for everything done unasked: once, weekly, monthly, every N minutes, at start-up or after a quiet spell |
| 🛰️ **Command-Center HUD** | Glass panels, ring gauges, network sparkline, a transcript-style log, and one TASKS / ROUTINES panel |
| ⚛️ **3-D Reactor Core & Avatar** | Depth-cued 3D reactor core or animated holographic head with ~50 fps formant + transcript lip-sync |
| 🎚️ **Push-to-Talk & Wake Word** | Hold **Ctrl+Space** or use offline **"Hey Jarvis"** detection with automatic self-echo cancellation |
| 🔌 **Hybrid & Local Engines** | Run on **Gemini 3.1 Flash Live** or switch in ⚙ → **ENGINE & PROVIDERS** to Ollama, LM Studio, OpenAI, Groq, Whisper, and Piper (~50 languages) |
| 📱 **Phone Remote Control** | Pair your phone over local Wi-Fi via QR code (`⚙ → REMOTE CONTROL`) for live phone mic streaming, commands, and file drops |
| ↩️ **Undo & Real Confirmation** | Reverse file operations and system setting changes by voice; irreversible actions require clicking CONFIRM on the HUD |

---

## ⚡ Quick Start

```bash
git clone https://github.com/<your-username>/Project-jrvs.git
cd Project-jrvs
python setup.py        # installs dependencies for your OS
python main.py
```

1. **First Launch:** Paste your free [Google AI Studio Gemini API key](https://aistudio.google.com/app/apikey) in the setup overlay (or pick **Local Only** to configure Ollama / Whisper / Piper in **⚙ → ENGINE & PROVIDERS**).
2. **Explore All Features:** Click the **Controls (`🎛`)** icon in the top header → **`✦ PROJECT JRVS ARSENAL`** to view all 16 custom modules and their voice/hotkey triggers right inside the HUD.

---

## ⌨️ Hotkeys & Quick Triggers

| Shortcut / Trigger | Action |
|---|---|
| **`Ctrl + Shift + Space`** (Global) | Open Cursor-Side Quick Ask Bar |
| **`Ctrl + Shift + C`** (Global) | Launch Circle-to-Ask Screen Selection |
| **`Ctrl + Shift + P`** (Global) | Engage Panic Privacy Shield |
| **`F4`** | Mute / Unmute Microphone |
| **`F11`** | Toggle Fullscreen HUD |
| **`ESC`** | Interrupt Assistant Mid-Speech |
| **`Ctrl + Space`** | Push-to-Talk (when enabled in Controls) |
| **`◉ ORB`** / *"orb mode"* | Minimize HUD to Floating 3D LED Orb (double-click orb to expand) |
| **`JARVIS`** / **`FRIDAY`** / **`ULTRON`** | Switch Live Persona, Voice & HUD Color Theme |

---

## 🗂️ Project Structure

```
Project-jrvs/
├── main.py                       # Core loop — Gemini Live session, audio I/O, viseme extraction, tool dispatch
├── ui.py                         # JarvisUI bridge — exposes thread-safe HUD, Orb, Notch, Circle-to-Ask & speech hooks
├── setup.py                      # OS-aware dependency installer
├── requirements.txt              # Python package requirements
├── AGENTS.md                     # Repository architecture & engineering conventions
├── LICENSE                       # Creative Commons Attribution-NonCommercial 4.0 (CC BY-NC 4.0)
├── .gitignore                    # Excludes API keys, TLS certs, personal memories, caches & local captures
├── gui/                          # Modular PyQt6 Command-Center HUD
│   ├── window.py                 # MainWindow — header quick-pills, drawers, splitters, global shortcut hooks
│   ├── orb_widget.py             # Floating 420-particle 3D LED Sphere Orb + exclusive HUD/Orb controller
│   ├── circle_to_ask.py          # Full-screen translucent Circle-to-Ask region snipping & prompt overlay
│   ├── cursor_ask_bar.py         # Floating cursor-side quick command pill
│   ├── notch_capsule.py          # Top-edge Liquid Dynamic Island status capsule
│   ├── hud.py                    # Center HUD canvas — animated avatar, reactor core, live audio waveform
│   ├── reactor.py                # 3-D software-rendered Arc Reactor projection
│   ├── overlays.py               # Setup, Customize, Memory, Plugins, Remote QR & Audio Device overlays
│   ├── providers_panel.py        # Engine & Providers configuration UI
│   ├── widgets.py                # HoloPanels, RingGauges, Sparklines, LogWidget, Task & Routine rows
│   ├── metrics.py                # Live CPU / RAM / GPU / Temperature / Network telemetry
│   ├── theme.py                  # Dynamic runtime color palette & live widget re-theming
│   └── style.py                  # Custom fonts, gradients, chamfers & button styles
├── plugins/                      # 27 Auto-Discovered Modular Skills & Overlays
│   ├── _template.py              # Single-file plugin template
│   ├── orb_mode.py               # Voice/command controller for Floating 3D Orb Mode
│   ├── friday_mode.py            # F.R.I.D.A.Y. persona, Aoede voice & Pink HUD switcher
│   ├── ultron_mode.py            # U.L.T.R.O.N. Apex Override, Fenrir voice & Blood Red HUD mutation
│   ├── ultron_takeover.py        # Animated Reactor Breach & Lockdown takeover sequence
│   ├── voice_clone_persona.py    # Multi-core persona & voice router
│   ├── circle_to_ask.py          # Voice trigger for Circle-to-Ask overlay
│   ├── panic_shield.py           # Instant privacy mute, stream kill, minimize & dark veil
│   ├── visual_explainer.py       # Interactive HUD flowcharts, timelines & math blueprints
│   ├── arkham_detective_vision.py# Click-through tactical visor reticle & hover telemetry
│   ├── holographic_mini_drone.py # Floating Stark/Ultron tactical mini-drone companion
│   ├── holographic_portal_drop.py# Zero-cloud LAN QR wormhole for Phone <-> PC file transfer
│   ├── live_chess_grandmaster_hud.py # Local Stockfish Chess.com best-move arrow overlay
│   ├── kinetic_gesture_airmouse.py   # Webcam OpenCV air-gesture workspace & boss-key controller
│   ├── chronos_flow_guardian.py  # Deep-work focus lock & distraction interceptor
│   ├── auto_pilot_watch.py       # Background process & screen change watcher
│   ├── protocol_launcher.py      # Multi-step Stark Suit workspace protocols
│   ├── god_mode_architect.py     # Autonomous self-plugin generator & sandbox tester
│   ├── symbiotic_self_mutator.py # Live AST-verified plugin inspector, patcher & hot-reloader
│   ├── voice_fingerprint_lock.py # Local MFCC/spectral biometric voiceprint authentication
│   ├── agent_command_center.py   # Multi-tool orchestrator
│   ├── environment_manager.py    # Saved activity workspace profiles
│   ├── memory_palace.py          # Natural-language long-term memory manager
│   ├── multi_device_neural_link.py # Phone dashboard LAN pairing diagnostics
│   ├── network_intelligence.py   # Read-only DNS & TCP reachability diagnostics
│   ├── performance_intelligence.py # Read-only system & plugin health snapshot
│   ├── project_sentinel.py       # Read-only project structure, TODO & syntax scanner
│   └── daily_tracker_plugin.py   # Daily habit & schedule tracker launcher
├── actions/                      # 18 Core OS & Computer Control Skills
├── core/                         # Core Engines (Global Shortcuts, Persona Bridge, Tasks, Routines, Avatar, EchoGuard)
├── providers/                    # Optional Local & Third-Party STT / LLM / TTS Pipeline
├── dashboard/                    # Local LAN FastAPI Phone Remote Control Server
├── agents/                       # Markdown Agent Definitions (`general.md`, `researcher.md`)
└── memory/                       # Local JSON Memory & Config Storage (user data git-ignored)
```

---

## 🔒 Privacy & Repository Safety

The included `.gitignore` automatically prevents secrets and personal data from being committed to GitHub:
* `config/api_keys.json`, `config/certs/`, `.env` — API keys and TLS certificates stay strictly local.
* `memory/long_term.json`, `memory/routines.json`, `memory/tasks/`, `memory/circle_capture.png`, `memory/voiceprint_profile.json` — personal memories, voiceprints, and screen snips are excluded from Git tracking.

---

## ⚠️ Attribution & License

Built upon **[Mark LVII](https://github.com/FatihMakes/Mark-LVII)** by **FatihMakes**.
Licensed under **[Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)](https://creativecommons.org/licenses/by-nc/4.0/)**. Personal and non-commercial use only.
